# Retail Promotion Intelligence Platform — Architecture

**Thesis:** Claude is the decision layer. Eight specialist agents reason, choose methods, challenge each other and explain.
Tiny deterministic Python tools do the arithmetic. The dashboard renders agent outputs as structured cards.
No ML training is required — the "model" is agents + comparable-promotion analogs + basket statistics.

---

## 1. CLAUDE.md
Created at [CLAUDE.md](CLAUDE.md). Key rule: *Claude decides, tools compute; every major decision is logged.*

## 2. Agent structure

Two planes (important for judges and for your own sanity):

| Plane | What | Tech |
|---|---|---|
| Build-time | Claude Code + `.claude/agents/*` build the repo | Claude Code sub-agents |
| Run-time | Orchestrator + specialists run when a user clicks Analyze | Python + Claude API/Agent SDK + MCP tools |

```
                        ┌──────────────────────┐
   Streamlit  ───────►  │     ORCHESTRATOR     │  ◄── scheduler / dashboard load
                        └─────────┬────────────┘
        ┌──────────┬──────────────┼───────────────┬──────────────┐
     INTAKE     CONTEXT          LIFT         CANNIBALIZATION  FINANCIAL      (evaluation path)
        └──────────┴──────────────┴───────────────┴──────────────┘
                                  │
                           RISK CRITIC (independent, different model/prompt)
                                  │ revise?
                           RECOMMENDER ──► re-evaluates alternatives via Orchestrator
   OPPORTUNITY SCOUT ──► Recommender ──► evaluated proposals          (proactive path)
                                  │
                   decision_log + evaluations  ──► Dashboard cards
```

## 3. Agent responsibilities

| Agent | Model tier | Decides | Tools | Output |
|---|---|---|---|---|
| Orchestrator | top | step routing, retry/degrade, loop vs stop | all agents | `EvaluationBundle` |
| Intake | fast | column mapping, SKU resolution, blocking issues | lookup_products | `PromotionBatch` |
| Context | mid | which events/weather/trends matter and their direction | signals MCP | `ContextReport` |
| Lift | mid | which past promos are valid analogs, baseline-buyer share | retail_data MCP, calc/lift | `LiftForecast` |
| Cannibalization | mid | substitute & complement sets | basket MCP, calc/cannibalization | `CannibalizationReport` |
| Financial | mid | assumptions on funding/cost, interpretation | costs MCP, calc/roi | `FinancialReport` |
| Risk Critic | top | verdict approve / approve_with_changes / revise | none (JSON only) | `RiskAssessment` |
| Recommender | top | which fixes, which 3 alternatives, ranking | orchestrator, MCP | `RecommendationSet` |
| Opportunity Scout | mid | which signal intersections are worth acting on | signals + inventory MCP | `OpportunityList` |

Why this satisfies "Claude in every major decision": analog selection, substitute set, risk verdict, alternative design,
and opportunity ranking are all LLM judgments recorded with rationale — numbers are never LLM-generated.

## 4. Sub-agent definitions
Already created in `.claude/agents/`: `promo-orchestrator`, `intake-agent`, `context-agent`, `lift-agent`,
`cannibalization-agent`, `financial-agent`, `risk-critic-agent`, `recommender-agent`, `opportunity-scout-agent`.

Add these **build-time-only** sub-agents when you start coding:
- `data-engineer` — generates synthetic data with *planted patterns* (see §13), builds DuckDB.
- `dashboard-builder` — Streamlit pages from schemas.
- `qa-reviewer` — validates contracts, runs the demo script, checks every number traces to a tool call.

Run-time execution: the Python orchestrator loads each `.claude/agents/*.md` (frontmatter = model/tools, body = system prompt),
so there is a single source of truth. Run-time agent = one Claude call loop with `tools=` bound to the MCP servers/calc functions.

## 5. Workflow definitions

Workflows are YAML DAGs executed by `core/orchestrator.py`. (For build-time parallel work, use Claude Code's Workflow tool.)

**workflows/evaluate_promotion.yaml**
```yaml
name: evaluate_promotion
steps:
  - id: intake        agent: intake-agent
  - id: context       agent: context-agent          needs: [intake]
  - id: lift          agent: lift-agent             needs: [intake, context]
  - id: cannibal      agent: cannibalization-agent  needs: [intake, lift]
  - id: finance       agent: financial-agent        needs: [lift, cannibal]
  - id: critic        agent: risk-critic-agent      needs: [lift, cannibal, finance]
  - id: recommend     agent: recommender-agent      needs: [critic]
                      when: critic.verdict in [revise, approve_with_changes]
                      loop: {max: 2, re_evaluate: [lift, cannibal, finance, critic]}
  - id: summarize     agent: promo-orchestrator     needs: [critic, recommend?]   # builds EvaluationBundle + exec summary
on_step_failure: retry_once_then_degrade
log: decision_log
```

**workflows/recommend_promotions.yaml**
```yaml
name: recommend_promotions
trigger: [dashboard_load, daily_schedule, manual_refresh]
steps:
  - id: scout       agent: opportunity-scout-agent
  - id: propose     agent: recommender-agent   needs: [scout]  foreach: scout.top_n(3)
  - id: evaluate    workflow: evaluate_promotion  foreach: propose.proposals   # fan-out sub-workflow
  - id: rank        agent: promo-orchestrator  needs: [evaluate]              # rank by risk-adjusted net margin
```

## 6. Folder structure
```
hackathon/
├─ CLAUDE.md  ARCHITECTURE.md  .mcp.json  .env.example  pyproject.toml
├─ .claude/
│  ├─ agents/            # 9 files already created
│  └─ settings.json      # permissions for MCP tools + bash calc scripts
├─ app/
│  ├─ Home.py            # status + "Run opportunity scan"
│  ├─ pages/1_Promotion_Upload.py
│  ├─ pages/2_Opportunity_Dashboard.py
│  ├─ pages/3_Promotion_Insights.py
│  └─ components/        # cards.py (verdict, risk, recommendation), charts.py, agent_trace.py
├─ core/
│  ├─ orchestrator.py    # DAG runner, retries, schema validation, decision logging
│  ├─ agent_runner.py    # loads .claude/agents/*.md, runs Claude tool loop
│  ├─ config.py          # model tiers per agent
│  ├─ calc/              # lift.py  cannibalization.py  roi.py  (pure functions + tests)
│  ├─ schemas/           # *.json + pydantic mirrors
│  └─ store.py           # DuckDB access, decision_log writer
├─ mcp_servers/
│  ├─ retail_data_server.py
│  └─ signals_server.py
├─ workflows/            # evaluate_promotion.yaml  recommend_promotions.yaml
├─ data/                 # generate.py, csv/, rpip.duckdb
├─ samples/              # promo_01.json … demo CSVs (one great, one trap, one marginal)
└─ tests/
```

## 7. MCP integrations

Two small custom servers (FastMCP, stdio) keep tool access auditable and demonstrate MCP properly.

| Server | Tools | Backing |
|---|---|---|
| `retail_data` | `lookup_products`, `get_product_attributes`, `get_baseline_sales`, `find_comparable_promotions`, `get_price_elasticity`, `get_basket_affinity`, `get_substitutes`, `get_inventory`, `get_costs_and_margins`, `get_seasonality` | DuckDB |
| `signals` | `get_events`, `get_weather_forecast`, `get_trends` | MVP: curated JSON fixtures. Later: Open-Meteo, Google Trends, holiday/events APIs |

`.mcp.json`:
```json
{ "mcpServers": {
  "retail_data": { "command": "python", "args": ["mcp_servers/retail_data_server.py"] },
  "signals":     { "command": "python", "args": ["mcp_servers/signals_server.py"] } } }
```
Optional extras: Open-Meteo (real weather, no key), a filesystem/Sheets connector for importing promo plans.
Every tool call is recorded into the agent trace shown on the dashboard.

## 8. Dashboard architecture (Streamlit)

- **Pages call the orchestrator, never agents directly.** `st.session_state` holds `run_id`; results read from DuckDB `evaluations`.
- Long runs: orchestrator emits progress events to a queue → `st.status` shows live agent steps ("Lift agent kept 4 of 6 analogs…"). This is your demo wow-factor.
- Cache scout results (`st.cache_data`, TTL 1 h); evaluation results persisted, not recomputed.

| Page | Components |
|---|---|
| 1 Upload | CSV uploader → Intake preview table with issue badges · manual form (SKUs, mechanic, depth, dates, stores) · **Analyze** button → run progress → link to Insights |
| 2 Opportunities | 4 panels: Upcoming events, Trending categories, High-inventory products, **Recommended promotions** (Scout+Recommender cards with score, "why now", pre-evaluated ROI, "Send to analysis") |
| 3 Insights | Header verdict badge (Critic) + confidence · KPI row (lift, incremental units, cannibalization rate, ROI, net margin) · lift low/exp/high range chart · basket waterfall (promoted + losers + halo = net) · ROI sensitivity · **Claude Recommendations** (3 alternatives side-by-side vs. original) · "How Claude decided" expander (decision log + tool trace) |

## 9. Data model (DuckDB; synthetic)

```
products(sku, name, category, brand, tier, size, price, unit_cost)
stores(store_id, region, format)
sales_daily(date, store_id, sku, units, net_price, promo_id NULL)
baskets(basket_id, date, store_id, customer_segment)     basket_items(basket_id, sku, qty, price)
inventory(sku, store_id, on_hand, weeks_cover, age_days)
promotions(promo_id, name, mechanic, depth_pct, start, end, funding_pct, status)
promotion_items(promo_id, sku, store_scope)
promotion_results(promo_id, actual_lift_pct, baseline_units, cannibalized_units, net_margin)  -- history for analogs
events(event_id, name, type, start, end, region, expected_impact_categories)
trend_signals(date, category, trend_index, source)
weather(date, region, temp_c, precip_mm)
evaluations(run_id, promo_id, bundle_json, verdict, created_at)
recommendations(rec_id, run_id|NULL, source[risk|opportunity], bundle_json, score)
decision_log(id, run_id, agent, decision, rationale, evidence_json, confidence, ts)
```

## 10. Promotion evaluation workflow (narrative)
1. **Intake** normalizes upload; errors stop here, warnings continue.
2. **Context** fetches events/weather/trends and gives a demand hint.
3. **Lift** *chooses* analogs (keeps/rejects with reasons), `calc/lift.py` produces low/exp/high, Claude estimates baseline-buyer share.
4. **Cannibalization** *chooses* substitutes/complements, `calc/cannibalization.py` quantifies basket shift.
5. **Financial** runs `calc/roi.py` → ROI, net margin, wasted discount, break-even lift.
6. **Critic** attacks the package independently → verdict + named risks.
7. If `revise`/`approve_with_changes` → Recommender (§11). Loop max 2.
8. Orchestrator assembles `EvaluationBundle`, writes `decision_log`, dashboard renders.

## 11. Promotion recommendation workflow (narrative)
**Reactive (risk-driven):** Critic risks → Recommender maps each risk to a lever (depth, mechanic, targeting, timing, bundle, exclusions)
→ 3 alternatives (conservative/balanced/aggressive) → each re-run through lift→cannibal→finance→critic → ranked by risk-adjusted net margin.

**Proactive (signal-driven):** Scout intersects events × trends × weather × inventory × basket affinity → ranked opportunities
→ Recommender drafts a promotion for the top 3 → each evaluated by the full evaluation workflow → shown as pre-validated cards.
The key differentiator: *every suggestion on the Opportunity page has already survived the Critic.*

## 12. Sample JSON contracts

Common envelope (all agents):
```json
{ "agent": "lift-agent", "run_id": "r_8f2", "step": "lift", "status": "ok|degraded|error",
  "confidence": 0.62, "assumptions": ["..."], "evidence": [{"tool":"find_comparable_promotions","ref":"call_3"}],
  "output": { } }
```

Intake → Orchestrator
```json
{ "output": { "promotions": [{ "promo_id":"P-101","name":"Summer Soda 2-for-1","mechanic":"bogo",
  "depth_pct":50,"skus":["SKU-1042","SKU-1043"],"stores":["ALL"],"start":"2026-12-01","end":"2026-12-14","funding_pct":20 }],
  "issues":[{"severity":"warn","field":"skus","message":"'Coke 12pk' matched SKU-1042 (2 candidates)"}] } }
```

Context → Lift
```json
{ "output": { "events":[{"name":"Holiday week","direction":"+","strength":"high","categories":["beverages"]}],
  "weather":{"summary":"cold snap","direction":"-","categories":["cold beverages"]},
  "trends":[{"category":"beverages","index":1.18}],
  "demand_multiplier_hint":{"low":0.95,"high":1.10,"reasoning":"Holiday demand already high; cold weather dampens cold drinks"} } }
```

Lift → Cannibalization / Financial
```json
{ "output": { "lift_pct":{"low":18,"expected":31,"high":44}, "baseline_units":12400, "incremental_units":3844,
  "baseline_buyer_share":0.58,
  "analogs_used":[{"promo_id":"P-044","why":"same mechanic & category"}],
  "analogs_rejected":[{"promo_id":"P-051","why":"overlapped Black Friday"}] }, "confidence":0.64 }
```

Cannibalization → Financial
```json
{ "output": { "substitutes":[{"sku":"SKU-2201","units_lost":900,"margin_lost_cents":41800}],
  "complements":[{"sku":"SKU-3310","units_gained":310,"margin_gained_cents":22400}],
  "cannibalization_rate":0.23, "net_basket_effect":{"units":3254,"margin_cents":-9100},
  "high_risk_skus":["SKU-2201"] }, "confidence":0.58 }
```

Financial → Critic
```json
{ "output": { "promo_cost_cents":482000, "wasted_discount_cents":279600, "incremental_margin_cents":351000,
  "cannibalized_margin_cents":118000, "net_margin_impact_cents":-249000, "roi":-0.52,
  "roi_range":{"low":-0.81,"expected":-0.52,"high":-0.10}, "break_even_lift_pct":67,
  "financial_summary":"58% of discount goes to customers who would buy anyway; break-even needs 67% lift." } }
```

Critic → Orchestrator
```json
{ "output": { "verdict":"revise",
  "risks":[{"type":"budget_waste","severity":"high","explanation":"58% baseline buyers","evidence":["lift.baseline_buyer_share"]},
           {"type":"cannibalization","severity":"med","explanation":"SKU-2201 is high margin","evidence":["cannibal.high_risk_skus"]}],
  "required_changes":["Reduce depth or target lapsed customers","Exclude or bundle SKU-2201"], "overall_confidence":0.6 } }
```

Recommender → Dashboard
```json
{ "output": { "alternatives":[
  {"id":"A1","label":"conservative","changes":{"depth_pct":25,"mechanic":"threshold"},"risks_addressed":["budget_waste"],
   "evaluation":{"lift_pct":19,"roi":0.21,"net_margin_impact_cents":64000,"verdict":"approve"}},
  {"id":"A2","label":"balanced"}, {"id":"A3","label":"aggressive"}],
  "recommended_id":"A1","why_not_others":{"A3":"ROI positive but cannibalizes SKU-2201 by 31%"} } }
```

Scout → Recommender
```json
{ "output": { "opportunities":[{ "id":"O-7","title":"Hot-drink bundle ahead of cold snap",
  "trigger_signals":["weather: -6C week of Dec 8","trend: hot beverages +34%"],
  "target_products":["SKU-5001","SKU-5002"],"window":{"start":"2026-12-06","end":"2026-12-13"},
  "why_now":"Forecast cold snap + 5.2 weeks cover on cocoa","urgency":"high","opportunity_score":0.84 }] } }
```

Decision log row
```json
{ "run_id":"r_8f2","agent":"lift-agent","decision":"Rejected analog P-051",
  "rationale":"Ran during Black Friday; lift would be overstated","evidence":["call_3"],"confidence":0.8 }
```

## 13. Hackathon MVP implementation plan

**Golden rule: build the demo path first, vertical slice, then widen.**

| Phase | Time | Deliverable |
|---|---|---|
| 0 Setup | 1 h | Repo, CLAUDE.md, agents (done), `.env`, pyproject, empty Streamlit pages |
| 1 Data | 2 h | `data/generate.py` w/ **planted patterns**: one promo that's a clear win, one with 60% baseline buyers, one with a high-margin cannibalization victim, a cold-snap event + overstocked cocoa. DuckDB loaded. |
| 2 Tools | 2 h | `calc/*` + tests; `retail_data` MCP server (stub signals from JSON) |
| 3 Agents | 4 h | `agent_runner` + Lift, Cannibalization, Financial first (hand-fed input), then Context, Critic |
| 4 Orchestrator | 2 h | DAG runner, schema validation, decision log, progress events |
| 5 Dashboard | 4 h | Insights page first (it *is* the product), then Upload, then Opportunities |
| 6 Recommender/Scout | 3 h | Reactive alternatives, then proactive opportunities |
| 7 Polish | 2 h | Agent trace UI, demo script, pre-cached runs for offline fallback |

Use Claude Code sub-agents (`data-engineer`, `dashboard-builder`) in parallel for phases 1 & 5 — and mention that in the pitch.

**Demo script (3 min):** upload a spreadsheet → watch agents work live → Critic says "revise: 58% wasted discount" → three
alternatives with ROI -52% → +21% → switch to Opportunities: cold-snap hot-drink bundle, already evaluated and approved.

**Cut list if behind:** real APIs, auth, multi-store granularity, loop-back re-evaluation (show alternatives with cached evaluation).

**Risks:** latency (parallelize, use fast model for specialists, stream progress) · hallucinated numbers (schema + "tools compute" +
QA agent checks evidence refs) · API failure on stage (cached bundles for the 3 sample promos).

## 14. Future enhancements
- Replace analog-based lift with a trained causal model (diff-in-diff / uplift); Claude keeps analog selection & explanation role.
- Real signals: Open-Meteo, Google Trends, event APIs, competitor price scraping, social trends.
- Closed learning loop: after a promo ends, an **Outcome agent** compares forecast vs. actual, updates analog weights, logs lessons to memory.
- Customer-level targeting (loyalty segments, CLV) to cut baseline-buyer waste.
- Multi-promo portfolio optimization (calendar conflicts, budget caps, vendor funding).
- Approval workflow + export to ERP/pricing systems; role-based views (category manager vs. finance).
- Scheduled agents (Claude Code routines) for daily scans with Teams/Slack alerts.
- Evaluation harness: backtest agents on historical promos; track calibration of confidence scores.
- Human-in-the-loop: planner overrides feed back as labeled decisions.
