---
description: Evaluate a retail promotion (plain-English description, CSV path or JSON path) and explain the result simply
argument-hint: <promotion description | path to .csv/.json>
---

Run this from the repo root and show me the result:

```
.venv/Scripts/python.exe evaluate.py "$ARGUMENTS"
```

Then explain the output in 4-5 short plain sentences for a non-technical retail manager: the verdict, the main reason, the expected profit or loss, and the better alternative if one was offered. Do not recompute or change any numbers; quote them from the output. If the script reports an error or a missing detail, say exactly what is missing and ask for it.
