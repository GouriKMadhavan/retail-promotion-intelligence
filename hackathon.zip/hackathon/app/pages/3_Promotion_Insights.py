import bootstrap  # noqa: F401
import json
import streamlit as st
from core.data_store import get_store
from components import charts
from components.cards import (money, pct, verdict_banner, kpi_row, risks_panel, promo_header, trace_table, decision_table,
                              agent_take, pipeline_from_bundle)
from components import theme
from core.orchestrator import backends_in_use

st.set_page_config(page_title="Promotion Insights", page_icon="📊", layout="wide")
theme.inject()
theme.nav()
store, ss = get_store(), st.session_state
names = {k: p["name"] for k, p in store.products.items()}

bundles = ss.get("bundles", [])
runs_dir = bootstrap.ROOT / "data" / "runs"
saved = sorted(runs_dir.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)[:15] if runs_dir.exists() else []
if not bundles and saved:
    st.info("No analysis in this session. Load a recent run:")
    pick = st.selectbox("Recent runs", saved, format_func=lambda p: p.stem)
    if st.button("Load run"):
        b = json.loads(pick.read_text(encoding="utf-8"))
        if b.get("workflow") == "evaluate_promotion":
            ss["bundles"] = [b]; ss["active"] = 0; st.rerun()
        else:
            st.warning("That run is an opportunity scan; open a proposal from the Opportunity Dashboard.")
if not bundles:
    st.info("Analyze a promotion first. Try one of the demo promotions on the upload page.")
    st.page_link("pages/1_Promotion_Upload.py", label="Go to upload", icon="📤")
    st.stop()

idx = st.sidebar.selectbox("Analysis", range(len(bundles)), index=min(ss.get("active", 0), len(bundles) - 1),
                           format_func=lambda i: bundles[i]["intake"]["output"]["promotions"][0]["name"])
b = bundles[idx]
if b["roi"]["status"] == "error" or b["simulate"]["status"] == "error":
    st.error("Analysis failed: " + str(b["simulate"]["output"].get("error") or b["roi"]["output"].get("error"))); st.stop()

sim, bas, roi, trend = (b[k]["output"] for k in ("simulate", "basket", "roi", "trend"))
e = roi["expected"]
rec = b.get("recommend")
ro = rec["output"] if rec else None

# 1. The story: promotion, verdict, numbers, plain-language summary
promo = b["intake"]["output"]["promotions"][0]
promo_header(promo, names)
verdict_banner(b["critic"], roi["headline"])
kpi_row(b)
theme.callout(agent_take(b))

# 2. The decision in one picture: original vs Claude's alternatives, beside the critic's risks
left, right = st.columns([3, 2], gap="large")
with left:
    if ro:
        theme.section("Original vs Claude's alternatives")
        rows = [{"option": "Original", "net": e["net_margin_impact_cents"] / 100, "recommended": ro["recommended_id"] == "original"}]
        rows += [{"option": f"{a['id']} {a['label']}", "net": a["evaluation"]["net_margin_impact_cents"] / 100,
                  "recommended": ro["recommended_id"] == a["id"]} for a in ro["alternatives"]]
        st.altair_chart(charts.compare_options(rows), use_container_width=True)
        st.caption("Net margin impact per option. The outlined bar is Claude's pick; each alternative was re-run through the full pipeline.")
    else:
        theme.section("Net margin by scenario")
        st.altair_chart(charts.scenario_net(roi), use_container_width=True)
with right:
    theme.section("What could go wrong")
    risks_panel(b["critic"])

# 3. How the agents got there
theme.section("Agent pipeline")
bk = {"intake": "intake-agent", "trend": "trend-agent", "simulate": "promotion-simulator-agent", "basket": "basket-intelligence-agent",
      "roi": "roi-agent", "critic": "risk-critic-agent", "recommend": "recommendation-agent"}
used = backends_in_use()
pipeline_from_bundle(b, {k: used.get(v, "") for k, v in bk.items()})


def describe_changes(ch: dict) -> str:
    lines = []
    for k, v in ch.items():
        if k == "skus":
            v = ", ".join(names.get(s, s) for s in v)
        lines.append(f"- **{k.replace('_', ' ')}**: {v}")
    return "\n".join(lines)


# 4. Details, one tab per question
t_lift, t_basket, t_roi, t_rec = st.tabs(["Will it lift sales?", "What does it cannibalize?", "Does it make money?", "What should we change?"])

with t_lift:
    a, c = st.columns([2, 3], gap="large")
    with a:
        st.altair_chart(charts.lift_range(sim), use_container_width=True)
        st.caption(f"Baseline {sim['baseline_units']:,} units · baseline redemption {sim['baseline_buyer_share']:.0%} · "
                   f"confidence {b['simulate']['confidence']:.0%}")
    with c:
        st.markdown("**Demand signals**")
        for s in trend["signals"]:
            if s["type"] != "seasonality":
                st.markdown(f"- {'⬆️' if s['direction'] == '+' else '⬇️'} {s['name']} ({s['strength']}) → {', '.join(s['affected_categories'])}")
        h = trend["demand_multiplier_hint"]
        st.caption(f"Demand hint ×{h['low']}–{h['high']}: {h['reasoning']}")
        for cf in trend["conflicts"]:
            st.warning(cf["description"])
    with st.expander("Which past promotions Claude used as analogs"):
        st.dataframe(sim["analogs_used"], hide_index=True, use_container_width=True)
        if sim["analogs_rejected"]:
            st.markdown("**Rejected**"); st.dataframe(sim["analogs_rejected"], hide_index=True, use_container_width=True)

with t_basket:
    l, r = st.columns([3, 2], gap="large")
    with l:
        st.altair_chart(charts.waterfall(roi), use_container_width=True)
    with r:
        if bas["high_risk_skus"]:
            st.warning("High-margin products at risk: " + ", ".join(names[s] for s in bas["high_risk_skus"]))
        for bc in bas["bundle_candidates"]:
            st.info(f"Bundle idea: {' + '.join(names[s] for s in bc['skus'])} — {bc['rationale']}")
    l, r = st.columns(2, gap="large")
    with l:
        st.markdown("**Substitutes losing sales**")
        st.dataframe([{"product": names.get(s["sku"], s["sku"]), "switch rate": pct(s["switch_rate"]), "units lost": s["units_lost"],
                       "margin lost": money(s["margin_lost_cents"])} for s in bas["substitutes"]], hide_index=True, use_container_width=True)
    with r:
        st.markdown("**Complements gaining (halo)**")
        st.dataframe([{"product": names.get(s["sku"], s["sku"]), "attach rate": pct(s["attach_rate"]), "units gained": s["units_gained"],
                       "margin gained": money(s["margin_gained_cents"])} for s in bas["complements"]], hide_index=True, use_container_width=True)

with t_roi:
    a, c = st.columns([3, 2], gap="large")
    with a:
        st.altair_chart(charts.scenario_net(roi), use_container_width=True)
    with c:
        st.metric("Promotion cost", money(e["promo_cost_cents"]))
        st.metric("Wasted discount", money(e["wasted_discount_cents"]), help="Discount paid on units that would have sold anyway")
        be = roi["break_even_lift_pct"]
        st.metric("Break-even lift", "unreachable" if be is None else f"{be:.0f}%",
                  delta=None if be is None else f"forecast {sim['lift_pct']['expected']:.0f}%", delta_color="off")
    inv = roi["inventory"]
    st.caption(f"Inventory: {inv['weeks_cover_before']} → {inv['weeks_cover_after']} weeks of cover · stock-out risk {inv['stockout_risk']} · {inv['note']}")
    st.dataframe([{"scenario": k, "lift %": sim["lift_pct"][k], "ROI": pct(v["roi"]), "net margin": money(v["net_margin_impact_cents"]),
                   "cost": money(v["promo_cost_cents"])} for k, v in roi["scenarios"].items()], hide_index=True, use_container_width=True)

with t_rec:
    if not ro:
        st.success("The critic approved this promotion as designed. No changes recommended.")
    else:
        st.markdown(f"**{len(ro['alternatives'])} alternatives**, each fully re-evaluated end to end. Claude recommends the one marked ⭐.")
        rows = [{"option": "Original", "lift %": round(sim["lift_pct"]["expected"]), "net margin": money(e["net_margin_impact_cents"]),
                 "ROI": pct(e["roi"]), "verdict": b["critic"]["output"]["verdict"].replace("_", " "),
                 "": "⭐ recommended" if ro["recommended_id"] == "original" else ""}]
        for a in ro["alternatives"]:
            ev = a["evaluation"]
            rows.append({"option": f"{a['id']} {a['label']}", "lift %": round(ev["lift_pct"] or 0), "net margin": money(ev["net_margin_impact_cents"]),
                         "ROI": pct(ev["roi"]), "verdict": ev["verdict"].replace("_", " "),
                         "": "⭐ recommended" if ro["recommended_id"] == a["id"] else ""})
        st.dataframe(rows, hide_index=True, use_container_width=True)
        if ro["recommended_id"] == "defer":
            st.error("Claude recommends deferring: no option produces positive net margin.")
        for a in ro["alternatives"]:
            with st.expander(f"{a['id']} · {a['title']}" + ("  ⭐ recommended" if ro["recommended_id"] == a["id"] else "")):
                st.write(a["rationale"])
                st.markdown("**Changes**\n" + describe_changes(a["changes"]))
                st.caption("Fixes: " + (", ".join(r.replace("_", " ") for r in a.get("risks_addressed", [])) or "n/a"))
                if ro["why_not_others"].get(a["id"]):
                    st.caption(ro["why_not_others"][a["id"]])
                if st.button("Open this alternative's full analysis", key=f"alt_{a['id']}"):
                    ss["bundles"].append(a["bundle"]); ss["active"] = len(ss["bundles"]) - 1; st.rerun()

# 5. Under the hood: for judges and auditors, not the first read
with st.expander("Under the hood: decision log, agent trace and raw evaluation"):
    st.download_button("Download evaluation JSON", json.dumps(b, indent=1, default=str),
                       file_name=f"evaluation_{b['run_id']}.json")
    st.markdown("**Decision log**"); decision_table(b)
    st.markdown("**Agent trace and contract validation**"); trace_table(b)
