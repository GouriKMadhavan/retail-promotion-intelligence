import bootstrap  # noqa: F401
import json
import streamlit as st
from core.data_store import get_store
from core.orchestrator import run_workflow, RUNS_DIR
from components import charts
from components.cards import money, pct, VERDICT
from components import theme

st.set_page_config(page_title="Opportunity Dashboard", page_icon="💡", layout="wide")
theme.inject()
theme.hero("Opportunity Dashboard", "Events, weather, trends and inventory, turned into promotions that have already been evaluated and critiqued.", ["Proactive", "Pre-evaluated", "Ranked by risk-adjusted margin"])
store, ss = get_store(), st.session_state
names = {k: p["name"] for k, p in store.products.items()}

def _last_saved_scan(h: int):
    """Most recent completed recommend_promotions run saved under data/runs for this horizon, or None."""
    best = None
    for p in RUNS_DIR.glob("*.json"):
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            continue
        if d.get("workflow") == "recommend_promotions" and d.get("horizon_days") == h and d.get("finished"):
            if best is None or d["finished"] > best["finished"]:
                best = d
    return best


horizon = st.sidebar.slider("Horizon (days)", 14, 45, 15)  # 15 days = today to ~Dec 4, fully covered by the live 16-day weather forecast
rerun = st.sidebar.button("Rerun scan")
key = f"feed_{horizon}"
if rerun or key not in ss:
    saved = None if rerun else _last_saved_scan(horizon)
    if saved:  # show the last completed scan at once; no model calls
        ss[key] = {"feed": saved, "saved": True}
    else:
        with st.status("Scanning events, trends, inventory and baskets; evaluating each proposal...", expanded=True) as status:
            feed = run_workflow("recommend_promotions", {"horizon_days": horizon, "region": "NE"}, persist=True,
                                on_event=lambda e: status.write(f"**{e['step']}** {e['status']}"))
            status.update(label="Scan complete", state="complete", expanded=False)
        ss[key] = {"feed": feed, "saved": False}
feed = ss[key]["feed"]
if ss[key].get("saved"):
    st.info(f"Showing the last completed scan for this {horizon}-day window (run {feed['run_id']}, finished {feed['finished'][:16].replace('T', ' ')} UTC). Use Rerun scan to refresh.")
trend = feed["trend"]["output"]

BADGE = {"live": "🟢 live", "cache": "🟢 live (cached)", "cache-stale": "🟡 stale cache", "mock": "⚪ mock", "mock-fallback": "🟠 mock (live unavailable)"}
srcs = trend.get("data_sources", {})
live_n = sum(v in ("live", "cache") for v in srcs.values())
st.caption(f"As of {store.as_of} · {live_n} of {len(srcs)} signal feeds live · sales, inventory and baskets are synthetic")
with st.expander("Data sources and gaps"):
    st.markdown(" · ".join(f"**{k}**: {BADGE.get(v, v)}" for k, v in srcs.items()) + " · inventory, sales and basket data: ⚪ mock")
    for g in trend.get("data_gaps", []):
        st.warning(g)

c1, c2 = st.columns(2)
with c1:
    theme.section("Upcoming events")
    ev = [x for x in trend["signals"] if x["type"] in ("event", "weather") and x["direction"] == "+"]
    st.dataframe([{"signal": x["name"], "type": x["type"], "strength": x["strength"], "categories": ", ".join(x["affected_categories"])} for x in ev],
                 hide_index=True, use_container_width=True)
with c2:
    theme.section("Trending categories")
    st.altair_chart(charts.trend_index(store.get_trends()), use_container_width=True)

c3, c4 = st.columns([2, 3])
with c3:
    theme.section("High inventory products")
    inv = sorted([i for i in store.get_inventory() if i["weeks_cover"] >= 8], key=lambda i: -i["weeks_cover"])
    if inv:
        st.altair_chart(charts.inventory_cover(inv, names), use_container_width=True)
        st.caption("Red = 8+ weeks of cover.")
    else:
        st.info("No overstock above 8 weeks of cover.")

with c4:
    theme.section("Recommended promotions")
    st.caption("Every card below has already been fully evaluated and critiqued by the agent pipeline.")
    order = {r["id"]: r["rank"] for r in feed["rank"]["output"]["ranking"]}
    items = sorted(feed["evaluate"], key=lambda a: order.get(a["id"], 99))
    good = [a for a in items if a["evaluation"]["net_margin_impact_cents"] > 0 and a["evaluation"]["verdict"] != "revise"]
    bad = [a for a in items if a not in good]

    def card(a, rejected=False):
        ev, ch = a["evaluation"], a["changes"]
        with st.container(border=True):
            tone = {"approve": "good", "approve_with_changes": "warn", "revise": "bad"}.get(ev["verdict"], "info")
            verdict_label = VERDICT.get(ev.get("verdict") or "", ("", "no verdict"))[1].title()
            st.markdown(f"**{theme.esc(a['title'])}**  " + theme.pills([(verdict_label, tone),
                        (f"urgency: {a.get('urgency', 'med')}", "warn" if a.get("urgency") == "high" else "muted")]), unsafe_allow_html=True)
            score = a.get("opportunity_score")
            if score is not None:
                st.markdown(theme.score_bar(score, "good") + f"<div style='font-size:.72rem;opacity:.65'>Opportunity score {score:.2f}</div>", unsafe_allow_html=True)
            st.caption(f"{ch.get('mechanic', '')} {ch.get('depth_pct', 0):.0f}% · {ch.get('start', '')} → {ch.get('end', '')} · "
                       + ", ".join(names.get(s, s) for s in ch.get("skus", [])))
            if a.get("why_now"):
                st.write(a["why_now"])
            elif a.get("rationale"):
                st.write(a["rationale"])
            k = st.columns(4)
            lift = ev.get("lift_pct")
            k[0].metric("Lift", "n/a" if lift is None else f"{lift:.0f}%"); k[1].metric("ROI", pct(ev.get("roi"))); k[2].metric("Net margin", money(ev.get("net_margin_impact_cents")))
            k[3].metric("Cannibalization", pct(ev["cannibalization_rate"]))
            if ev["risks"]:
                st.caption("Risks: " + ", ".join(ev["risks"]))
            if st.button("Open full analysis", key=f"open_{a['id']}"):
                ss.setdefault("bundles", []).append(a["bundle"]); ss["active"] = len(ss["bundles"]) - 1
                st.switch_page("pages/3_Promotion_Insights.py")

    if not good:
        st.info("No proposals cleared the critic this scan.")
    grid = st.columns(2, gap="medium")
    for i, a in enumerate(good):
        with grid[i % 2]:
            card(a)
    if bad:
        with st.expander(f"Evaluated and not recommended ({len(bad)})"):
            for a in bad:
                card(a, rejected=True)
    if feed["scout"]["output"].get("skipped"):
        st.caption("Skipped: " + "; ".join(f"{s.get('category') or s.get('sku') or 'item'} ({s.get('reason', '')})" for s in feed["scout"]["output"]["skipped"]))

with st.expander("How Claude decided"):
    for d in feed["decision_log"]:
        st.markdown(f"- **{d['agent']}**: {d['decision']} — _{d.get('rationale', '')}_")
