import bootstrap  # noqa: F401
import csv, io, json
from datetime import date
from pathlib import Path
import streamlit as st
from core import registry, progress
from streamlit.runtime.scriptrunner import get_script_run_ctx
from core.data_store import get_store
from core.orchestrator import run_workflow
from components.cards import STATUS_ICON
from components import theme

st.set_page_config(page_title="Promotion Upload", page_icon="📤", layout="wide")
theme.inject()
theme.hero("Promotion Upload", "Pick a demo promotion, describe one in words, or upload a file. Claude reads it, you check it, then the agents evaluate it.",
           ["1 Provide", "2 Check", "3 Analyze"])
store = get_store()
SAMPLES = Path(bootstrap.ROOT, "samples")
ss = st.session_state
ss.setdefault("pending", [])           # normalized promotions awaiting analysis
ss.setdefault("bundles", [])           # completed evaluation bundles


STEP_NAMES = {"intake": "Reading the promotion", "trend": "Checking demand signals", "simulate": "Forecasting the lift",
              "basket": "Checking substitutes and extra sales", "roi": "Working out the money", "critic": "Independent risk review",
              "recommend": "Designing better options"}
STEP_PROGRESS = {"started": ("⏳", "in progress"), "ok": ("✅", "done"), "degraded": ("✅", "done"),
                 "error": ("❌", "could not finish"), "skipped": ("⏭️", "not needed")}


def preview(raw):
    env = registry.call("intake-agent", {"raw": raw})
    out = env["output"]
    if env.get("status") == "error" or not out.get("promotions") and not out.get("issues"):
        st.error(f"The intake step could not read this promotion: {out.get('error', 'no promotion found')}")
    for i in out.get("issues", []):
        if i["severity"] == "error":          # only blocking problems are shown; default-value notes stay out of the user's way
            st.error(f"Please check: {i['message']}")
    ss["pending"] = out.get("promotions", [])
    ss["run_now"] = bool(ss["pending"])   # evaluate straight away, no separate step


DEMOS = [("promo_01.json", "Soda 2-for-1", "Trap", "bad",
          "Buy-one-get-one on soda, 50% off, 20% vendor funded. Looks generous on paper; the agents check whether it pays for itself."),
         ("promo_02.json", "Cocoa 20% off", "Marginal", "warn",
          "20% off two cocoa products, no vendor funding. A plain discount the agents have to weigh carefully."),
         ("promo_03.json", "Cocoa bundle", "Winner", "good",
          "Three cocoa products sold as a bundle at 20% off. A basket-building promotion.")]

theme.section("1 · Provide a promotion")
tab_demo, tab_text, tab_csv, tab_manual = st.tabs(["Demo promotions", "Describe in words", "Upload CSV", "Create manually"])

with tab_demo:
    st.caption("Three promotions, each designed to show a different verdict. Start here.")
    cols = st.columns(3, gap="medium")
    for col, (fn, title, tag, tone, desc) in zip(cols, DEMOS):
        with col:
            theme.card(title, desc, "🏷️")
            st.markdown(theme.pills([(tag, tone)]), unsafe_allow_html=True)
            if st.button(f"Load: {title}", key=fn, use_container_width=True):
                preview(json.loads((SAMPLES / fn).read_text(encoding="utf-8")))

with tab_text:
    st.caption("Describe the promotion the way you would to a colleague. Mention the product, the offer, the dates and any vendor funding.")
    desc = st.text_area("Your promotion", height=130, key="nl_text",
                        placeholder="e.g. 20% off all cocoa products from Dec 6 to Dec 13, 10% vendor funded, loyalty members only")
    if st.button("Evaluate this promotion", type="primary", disabled=not desc.strip()):
        from core.nl_parse import parse_promotion_text
        with st.spinner("Reading your description…"):
            raw, how = parse_promotion_text(desc)
        st.caption("Interpreted by Claude" if how in ("litellm", "claude-code") else "Interpreted with simple rules (Claude was unavailable), so please check the details below")
        with st.expander("Technical details", expanded=False):
            st.json(raw)
        preview(raw)

with tab_csv:
    f = st.file_uploader("Promotion CSV (any column naming; Claude's intake agent maps it)", type="csv")
    use_sample = st.button("Use sample CSV")
    text = f.getvalue().decode("utf-8-sig") if f else (SAMPLES / "promo_upload.csv").read_text(encoding="utf-8") if use_sample else None
    if text:
        rows = list(csv.DictReader(io.StringIO(text)))
        st.dataframe(rows, use_container_width=True, hide_index=True)
        if use_sample or st.button("Evaluate this file", type="primary"):   # never re-evaluate on unrelated reruns
            preview({"rows": rows})

with tab_manual:
    names = {k: f"{k} · {p['name']}" for k, p in store.products.items()}
    with st.form("manual"):
        name = st.text_input("Promotion name", "My promotion")
        a, b, c = st.columns(3)
        mech = a.selectbox("Mechanic", ["pct_off", "bogo", "multibuy", "threshold", "bundle"])
        depth = b.slider("Discount depth %", 5, 70, 20)
        funding = c.slider("Vendor funding %", 0, 60, 0)
        skus = st.multiselect("Products", list(names), format_func=names.get)
        d1, d2, d3 = st.columns(3)
        start = d1.date_input("Start", date(2026, 12, 6)); end = d2.date_input("End", date(2026, 12, 13))
        targeting = d3.selectbox("Targeting", ["all", "loyalty", "lapsed"])
        if st.form_submit_button("Validate promotion"):
            preview({"name": name, "mechanic": mech, "depth_pct": depth, "skus": skus, "start": str(start), "end": str(end),
                     "funding_pct": funding, "targeting": targeting})

pending = ss["pending"]
if pending:
    theme.section("2 · Check: how Claude understood it")
    st.dataframe([{"name": p["name"], "mechanic": p["mechanic"], "depth %": p["depth_pct"],
                   "products": ", ".join(store.products[s]["name"] for s in p["skus"]), "window": f"{p['start']} → {p['end']}",
                   "targeting": p["targeting"]} for p in pending], use_container_width=True, hide_index=True)
    ss_alt = st.checkbox("Also suggest better options if the critic is not satisfied (adds about 3 minutes)", value=False)
    if ss.pop("run_now", False):   # one step: the draft is evaluated as soon as it is understood
        for i in range(len(pending)):
            with st.status(f"Claude agents analysing '{pending[i]['name']}'", expanded=True) as status:
                log, box = [], st.empty()
                def show(e):
                    if e.get("step") == "detail":
                        log.append(f"&nbsp;&nbsp;&nbsp;&nbsp;↳ {e['detail']}")
                    else:
                        icon, label = STEP_PROGRESS.get(e["status"], ("", e["status"]))
                        log.append(f"{icon} {STEP_NAMES.get(e['step'], e['step'])} {label}")
                    for d in progress.drain():
                        log.append(f"&nbsp;&nbsp;&nbsp;&nbsp;↳ {d['detail']}")
                    box.markdown("  \n".join(log))
                progress.set_hook(show, get_script_run_ctx())
                try:
                    bundle = run_workflow("evaluate_promotion", {"promotion": pending[i], "alternatives": ss_alt}, on_event=show, persist=True)
                finally:
                    progress.clear_hook()
                status.update(label=f"Done: {pending[i]['name']}", state="complete", expanded=False)
            ss["bundles"].append(bundle)
        ss["active"] = len(ss["bundles"]) - 1
        st.success(f"Evaluation complete for {len(pending)} promotion(s).")
        st.page_link("pages/3_Promotion_Insights.py", label="View promotion insights →", icon="📊")
