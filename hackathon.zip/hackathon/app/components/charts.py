"""Altair charts. Inputs are agent output dicts."""
from __future__ import annotations
import altair as alt

GOOD, BAD, NEUTRAL = "#2e7d6b", "#c0504d", "#4a6fa5"


def lift_range(sim: dict):
    rows = [{"scenario": k, "lift": sim["lift_pct"][k]} for k in ("low", "expected", "high")]
    base = alt.Chart(alt.Data(values=rows)).encode(x=alt.X("scenario:N", sort=["low", "expected", "high"], title=None),
                                                   y=alt.Y("lift:Q", title="Lift %"))
    return (base.mark_bar(color=NEUTRAL, size=46) + base.mark_text(dy=-8).encode(text=alt.Text("lift:Q", format=".0f"))).properties(height=240)


def waterfall(roi: dict):
    e = roi["expected"]
    steps = [("Incremental margin", e["incremental_margin_cents"]), ("Wasted discount", -e["wasted_discount_cents"]),
             ("Cannibalized margin", -e["cannibalized_margin_cents"]), ("Halo margin", e["halo_margin_cents"])]
    rows, run = [], 0
    for name, v in steps:
        rows.append({"step": name, "start": run / 100, "end": (run + v) / 100, "value": v / 100}); run += v
    rows.append({"step": "Net margin impact", "start": 0, "end": run / 100, "value": run / 100})
    order = [r["step"] for r in rows]
    ch = alt.Chart(alt.Data(values=rows)).encode(x=alt.X("step:N", sort=order, title=None, axis=alt.Axis(labelAngle=-20)))
    bars = ch.mark_bar(size=44).encode(y=alt.Y("start:Q", title="$"), y2="end:Q",
                                       color=alt.condition("datum.value >= 0", alt.value(GOOD), alt.value(BAD)),
                                       tooltip=["step:N", alt.Tooltip("value:Q", format="$,.0f")])
    return bars.properties(height=300)


def scenario_net(roi: dict):
    rows = [{"scenario": k, "net": roi["scenarios"][k]["net_margin_impact_cents"] / 100} for k in ("low", "expected", "high")]
    base = alt.Chart(alt.Data(values=rows)).encode(x=alt.X("scenario:N", sort=["low", "expected", "high"], title=None),
                                                   y=alt.Y("net:Q", title="Net margin $"))
    return (base.mark_bar(size=46).encode(color=alt.condition("datum.net >= 0", alt.value(GOOD), alt.value(BAD)))
            + base.mark_text(dy=-8).encode(text=alt.Text("net:Q", format="$,.0f"))).properties(height=240)


def inventory_cover(items: list[dict], names: dict[str, str]):
    rows = [{"product": names.get(i["sku"], i["sku"]), "weeks_cover": i["weeks_cover"]} for i in items]
    base = alt.Chart(alt.Data(values=rows)).encode(y=alt.Y("product:N", sort="-x", title=None), x=alt.X("weeks_cover:Q", title="Weeks of cover"))
    return (base.mark_bar().encode(color=alt.condition("datum.weeks_cover >= 8", alt.value(BAD), alt.value(NEUTRAL)))).properties(height=max(120, 26 * len(rows)))


def trend_index(items: list[dict]):
    rows = [{"category": t["category"], "index": t["trend_index"]} for t in items]
    base = alt.Chart(alt.Data(values=rows)).encode(y=alt.Y("category:N", sort="-x", title=None), x=alt.X("index:Q", scale=alt.Scale(domain=[0.6, 1.5]), title="Trend index (1.0 = flat)"))
    rule = alt.Chart(alt.Data(values=[{"x": 1.0}])).mark_rule(strokeDash=[4, 4]).encode(x="x:Q")
    return (base.mark_bar().encode(color=alt.condition("datum.index >= 1", alt.value(GOOD), alt.value(BAD))) + rule).properties(height=180)


def compare_options(rows: list[dict]):
    """rows: [{option, net (dollars), recommended (bool)}] - original vs alternatives, recommended outlined."""
    base = alt.Chart(alt.Data(values=rows)).encode(x=alt.X("option:N", sort=[r["option"] for r in rows], title=None, axis=alt.Axis(labelAngle=0)),
                                                   y=alt.Y("net:Q", title="Net margin impact ($)"))
    bars = base.mark_bar(size=54, cornerRadiusTopLeft=6, cornerRadiusTopRight=6).encode(
        color=alt.condition("datum.net >= 0", alt.value(GOOD), alt.value(BAD)),
        stroke=alt.condition("datum.recommended", alt.value("#0f172a"), alt.value("transparent")), strokeWidth=alt.value(3),
        tooltip=["option:N", alt.Tooltip("net:Q", format="$,.0f")])
    labels = base.mark_text(dy=-9, fontWeight="bold").encode(text=alt.Text("net:Q", format="$,.0f"))
    zero = alt.Chart(alt.Data(values=[{"y": 0}])).mark_rule(color="#64748b").encode(y="y:Q")
    return (bars + labels + zero).properties(height=280)
