"""Dashboard cards built on components/theme.py. Pure presentation: every number shown comes from agent outputs."""
from __future__ import annotations
import streamlit as st
from . import theme


def money(c) -> str:
    if c is None:
        return "n/a"
    return f"{'-' if c < 0 else ''}${abs(c) / 100:,.0f}"


def pct(x, digits=0) -> str:
    return "n/a" if x is None else f"{x:.{digits}%}"


VERDICT = {
    "approve": ("good", "APPROVE"),
    "approve_with_changes": ("warn", "APPROVE WITH CHANGES"),
    "revise": ("bad", "REVISE BEFORE LAUNCH"),
}
VERDICT_TEXT = {"approve": "Safe to launch as designed.", "approve_with_changes": "Viable, but the risks below should be addressed first.",
                "revise": "Do not launch as designed: the independent critic found high-severity risks."}
SEV_TONE = {"high": "bad", "med": "warn", "low": "info"}
STATUS_ICON = {"ok": "✅", "degraded": "⚠️", "error": "❌", "skipped": "⏭️", "started": "⏳"}


def verdict_banner(critic_env: dict, headline: str | None = None):
    out = critic_env.get("output") or {}
    if "verdict" not in out:
        reason = "; ".join(critic_env.get("assumptions") or [])[:300] or "an upstream agent did not return a result"
        st.warning(f"No verdict: the risk critic did not produce one ({critic_env.get('status', 'unknown')}). {reason}")
        return
    tone, label = VERDICT.get(out["verdict"], ("info", out["verdict"]))
    body = VERDICT_TEXT.get(out["verdict"], "") + (f" Financial outlook: {headline.replace('_', ' ')}." if headline else "")
    theme.verdict_card(label, tone, out["overall_confidence"], body)


def kpi_row(bundle: dict):
    sim, bas, roi = (bundle[k]["output"] for k in ("simulate", "basket", "roi"))
    e = roi["expected"]
    net = e["net_margin_impact_cents"]
    cr = bas["cannibalization_rate"]
    items = [
        ("Expected lift", f"{sim['lift_pct']['expected']:.0f}%", f"range {sim['lift_pct']['low']:.0f}–{sim['lift_pct']['high']:.0f}%", "info"),
        ("Incremental units", f"{sim['incremental_units']['expected']:,}", f"on {sim['baseline_units']:,} baseline", "info"),
        ("Cannibalization", pct(cr), "of incremental units", "bad" if cr >= .25 else "warn" if cr >= .12 else "good"),
        ("ROI", pct(e["roi"]) if e["roi"] is not None else "n/a", f"cost {money(e['promo_cost_cents'])}", "good" if (e["roi"] or 0) > 0 else "bad"),
        ("Net margin impact", money(net), f"wasted discount {money(e['wasted_discount_cents'])}", "good" if net > 0 else "bad"),
    ]
    for col, (l, v, x, tone) in zip(st.columns(5), items):
        with col:
            theme.kpi(l, v, x, tone)
    st.write("")


def risks_panel(critic_env: dict):
    out = critic_env.get("output") or {}
    if not out.get("risks"):
        st.success("No risks above threshold.")
    for r, fix in zip(out.get("risks") or [], out.get("required_changes") or []):
        sev = r.get("severity", "low")
        st.markdown(theme.pill(sev.upper(), SEV_TONE.get(sev, "info")) + f" **{theme.esc(r.get('type', 'risk').replace('_', ' ').title())}** — "
                    + theme.esc(r.get("explanation", "")), unsafe_allow_html=True)
        st.caption(f"→ Suggested fix: {fix}")
    for s in out.get("strengths", []):
        st.markdown(theme.pill("STRENGTH", "good") + " " + theme.esc(s), unsafe_allow_html=True)


def promo_header(p: dict, names: dict[str, str]):
    chips = [p["mechanic"].replace("_", " ").title(), f"{p['depth_pct']:.0f}% depth", f"{p['window']['start']} → {p['window']['end']}",
             f"targeting: {p.get('targeting', 'all')}"]
    theme.hero(p["name"], ", ".join(names.get(s, s) for s in p["skus"]), chips, with_nav=False)


def agent_take(b: dict) -> str:
    """Plain-language summary assembled from agent outputs (no new numbers)."""
    roi, critic = b["roi"]["output"], b["critic"]["output"]
    parts = [roi.get("financial_summary", "")]
    if critic.get("risks"):
        top = max(critic["risks"], key=lambda r: {"high": 3, "med": 2, "low": 1}.get(r.get("severity"), 0))
        parts.append(f"Biggest risk: {top['type'].replace('_', ' ')} — {top['explanation']}")
    rec = b.get("recommend")
    if rec:
        rid = rec["output"]["recommended_id"]
        alt = next((a for a in rec["output"]["alternatives"] if a["id"] == rid), None)
        if alt:
            parts.append(f"Recommended instead: {alt['title']} (net {money(alt['evaluation']['net_margin_impact_cents'])}).")
        elif rid == "defer":
            parts.append("Recommendation: defer, since no alternative produces positive net margin.")
    return " ".join(parts)


def pipeline_from_bundle(b: dict, backends: dict[str, str] | None = None):
    status = {t["step"]: t["status"] for t in b["trace"]}
    status["recommend"] = status.get("rank", "ok") if b.get("recommend") else "skipped"
    theme.pipeline(status, backends)


def trace_table(bundle: dict):
    rows = []
    for t in bundle["trace"]:
        env = bundle["recommend"] if t["step"] == "rank" else bundle.get(t["step"], {})
        rows.append({"step": t["step"], "agent": t["agent"], "backend": t["backend"], "status": STATUS_ICON.get(t["status"], t["status"]),
                     "ms": t["ms"], "contract": "valid" if not env.get("contract_errors") else "; ".join(env["contract_errors"][:2])})
    st.dataframe(rows, use_container_width=True, hide_index=True)


def decision_table(bundle: dict):
    rows = [{"step": d["step"], "agent": d["agent"], "decision": d.get("decision"), "rationale": d.get("rationale"),
             "confidence": d.get("confidence")} for d in bundle["decision_log"]]
    st.dataframe(rows, use_container_width=True, hide_index=True)
