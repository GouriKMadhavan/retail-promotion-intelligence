"""Visual layer: one CSS block + small HTML component helpers.
Rules: every dynamic string passes through esc(); HTML is built without newlines or leading spaces (Streamlit's markdown parser
treats indented or blank-line-separated HTML as code). The app is pinned to a light theme in .streamlit/config.toml."""
from __future__ import annotations
import html
import streamlit as st

TONE = {"good": "#16a34a", "warn": "#d97706", "bad": "#dc2626", "info": "#2563eb", "muted": "#64748b"}
PIPELINE = [("intake", "Intake"), ("trend", "Trends"), ("simulate", "Simulator"), ("basket", "Basket"),
            ("roi", "ROI"), ("critic", "Critic"), ("recommend", "Recommend")]

CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
:root{--rp-ink:#0f172a;--rp-muted:#64748b;--rp-line:#e3e9f2;--rp-teal:#0f766e;--rp-teal-2:#14b8a6}
html,body,p,li,td,th,label,button,input,textarea,.stMarkdown{font-family:'Inter','Segoe UI',system-ui,sans-serif}
[data-testid="stIconMaterial"],.material-icons,[class*="material-symbols"]{font-family:'Material Symbols Rounded','Material Icons' !important}
.stApp{background:#f5f8fb;color:var(--rp-ink)}
.block-container{padding-top:2.4rem;padding-bottom:4rem;max-width:1180px}
#MainMenu,footer,.stDeployButton,[data-testid="stToolbar"],[data-testid="stDecoration"]{display:none}
header[data-testid="stHeader"]{background:transparent}
h1,h2,h3{letter-spacing:-.01em;color:var(--rp-ink)}

/* sidebar */
section[data-testid="stSidebar"]{background:linear-gradient(180deg,#0b2b3a 0%,#0f3d4a 55%,#115e59 100%)}
section[data-testid="stSidebar"] *{color:#e6f4f1 !important}
section[data-testid="stSidebar"] [data-testid="stSidebarNav"]::before{content:"🏷️  RPIP";display:block;font-weight:800;font-size:1.25rem;letter-spacing:.04em;padding:22px 20px 14px;color:#fff}
section[data-testid="stSidebar"] a[data-testid="stSidebarNavLink"]{border-radius:10px;margin:2px 10px;padding:8px 12px}
section[data-testid="stSidebar"] a[data-testid="stSidebarNavLink"]:hover{background:rgba(255,255,255,.12)}
section[data-testid="stSidebar"] a[aria-current="page"]{background:rgba(255,255,255,.2) !important;font-weight:700}

/* hero */
.rp-hero{background:linear-gradient(115deg,#0b2b3a 0%,#0f766e 58%,#14b8a6 125%);color:#fff;border-radius:20px;padding:28px 32px;margin:0 0 20px 0;box-shadow:0 14px 34px rgba(11,43,58,.25);position:relative;overflow:hidden}
.rp-hero::after{content:"";position:absolute;right:-60px;top:-70px;width:260px;height:260px;border-radius:50%;background:radial-gradient(circle,rgba(255,255,255,.2),transparent 70%)}
.rp-hero .t{font-size:2rem;font-weight:800;letter-spacing:-.02em;line-height:1.15}
.rp-hero .s{color:rgba(255,255,255,.9);margin-top:6px;font-size:1rem;max-width:760px;line-height:1.5}
.rp-chip{display:inline-block;padding:3px 11px;border-radius:999px;font-size:.74rem;font-weight:600;margin:12px 6px 0 0;background:rgba(255,255,255,.18);color:#fff;border:1px solid rgba(255,255,255,.28)}

/* pills */
.rp-pill{display:inline-block;padding:2px 10px;border-radius:999px;font-size:.72rem;font-weight:650;margin:2px 6px 2px 0;border:1px solid;white-space:nowrap}

/* cards + KPIs */
.rp-card,.rp-kpi{background:#fff;color:var(--rp-ink);border:1px solid var(--rp-line);box-shadow:0 2px 10px rgba(15,23,42,.06);transition:transform .15s ease,box-shadow .15s ease}
.rp-card:hover,.rp-kpi:hover{transform:translateY(-3px);box-shadow:0 12px 26px rgba(15,23,42,.12)}
.rp-card{padding:20px 22px;border-radius:16px;min-height:200px;height:100%;box-sizing:border-box}
.rp-card .ic{width:44px;height:44px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.4rem;margin-bottom:12px;background:linear-gradient(135deg,#ccfbf1,#dbeafe)}
.rp-card .h{font-weight:700;font-size:1.08rem;margin-bottom:6px}
.rp-card .d{color:#475569;line-height:1.5;font-size:.93rem}
.rp-kpi{border-radius:16px;padding:16px 18px;border-top:4px solid var(--tone)}
.rp-kpi .l{font-size:.7rem;text-transform:uppercase;letter-spacing:.07em;color:var(--rp-muted);font-weight:700}
.rp-kpi .v{font-size:2rem;font-weight:800;line-height:1.15;color:var(--tone);margin-top:2px}
.rp-kpi .x{font-size:.8rem;color:var(--rp-muted);margin-top:2px}

/* verdict + callout */
.rp-verdict{background:#fff;color:var(--rp-ink);border-radius:16px;padding:20px 24px;border:1px solid var(--tone);border-left:10px solid var(--tone);box-shadow:0 4px 18px rgba(15,23,42,.08);margin-bottom:16px}
.rp-verdict .k{font-size:.72rem;text-transform:uppercase;letter-spacing:.08em;color:var(--rp-muted);font-weight:700}
.rp-verdict .v{font-size:1.8rem;font-weight:800;color:var(--tone);line-height:1.2}
.rp-verdict .b{margin-top:8px;font-size:1rem;line-height:1.5}
.rp-bar{height:8px;border-radius:99px;background:#e2e8f0;overflow:hidden;margin-top:10px}
.rp-bar>div{height:100%;border-radius:99px;background:var(--tone,#0f766e)}
.rp-callout{background:#fff;border:1px solid var(--rp-line);border-left:5px solid var(--rp-teal);border-radius:12px;padding:14px 18px;margin:4px 0 6px 0;line-height:1.6;color:#1e293b}

/* pipeline */
.rp-steps{display:flex;gap:0;align-items:flex-start;margin:8px 0 6px 0;overflow-x:auto}
.rp-step{flex:1;min-width:92px;text-align:center;position:relative}
.rp-step .c{width:34px;height:34px;border-radius:50%;margin:0 auto;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.9rem;color:#fff;background:var(--tone);position:relative;z-index:2;box-shadow:0 4px 10px rgba(15,23,42,.18)}
.rp-step .n{font-size:.78rem;font-weight:650;margin-top:6px}
.rp-step .m{font-size:.68rem;color:var(--rp-muted)}
.rp-step:not(:last-child)::after{content:"";position:absolute;top:16px;left:calc(50% + 17px);width:calc(100% - 34px);height:3px;background:#cbd5e1;z-index:1}

/* section labels */
.rp-section{font-size:.8rem;text-transform:uppercase;letter-spacing:.09em;font-weight:750;color:var(--rp-teal);margin:28px 0 10px 0}

/* tabs, metrics, buttons, links, expanders, bordered containers */
.stTabs [data-baseweb="tab-list"]{background:#fff;border-radius:12px;padding:5px;border:1px solid var(--rp-line);gap:4px}
.stTabs [data-baseweb="tab"]{border-radius:9px;padding:9px 16px;height:auto;font-weight:600}
.stTabs [aria-selected="true"]{background:#e6f6f4;color:var(--rp-teal)}
.stTabs [data-baseweb="tab-highlight"],.stTabs [data-baseweb="tab-border"]{display:none}
div[data-testid="stMetric"]{background:#fff;box-shadow:0 2px 10px rgba(15,23,42,.06);border:1px solid var(--rp-line);border-radius:12px;padding:10px 14px}
.stButton>button{border-radius:10px;border:1px solid #cbd5e1;background:#fff;font-weight:600}
.stButton>button[kind="primary"]{background:linear-gradient(135deg,#0f766e,#0e9f8e);border:0;color:#fff;box-shadow:0 6px 16px rgba(15,118,110,.3)}
.stButton>button[kind="primary"]:hover{filter:brightness(1.08);transform:translateY(-1px);color:#fff}
a[data-testid="stPageLink-NavLink"]{display:inline-flex;margin-top:10px;padding:7px 14px;border-radius:999px;background:#e6f6f4;font-weight:650;color:var(--rp-teal) !important;border:1px solid #b7e4de}
a[data-testid="stPageLink-NavLink"]:hover{background:var(--rp-teal);color:#fff !important}
a[data-testid="stPageLink-NavLink"]:hover *{color:#fff !important}
div[data-testid="stExpander"]{background:#fff;border:1px solid var(--rp-line);border-radius:14px;box-shadow:0 2px 8px rgba(15,23,42,.04)}
div[data-testid="stVerticalBlockBorderWrapper"]:has(> div > div > div[data-testid="stVerticalBlock"]){background:#fff}
textarea,input{border-radius:10px !important}
div[data-testid="stAlert"]{border-radius:12px}
</style>
"""


def esc(x) -> str:
    return html.escape(str(x), quote=True)


def inject():
    st.markdown(CSS, unsafe_allow_html=True)


PAGES = [("Home.py", "🏠 Home"), ("pages/1_Promotion_Upload.py", "Promotion Upload"),
         ("pages/2_Opportunity_Dashboard.py", "Opportunities"), ("pages/3_Promotion_Insights.py", "Promotion Insights")]


def nav() -> None:
    """Visible navigation row: the sidebar's open button is hidden by the theme, so every page links to the others here."""
    cols = st.columns(len(PAGES))
    for col, (path, label) in zip(cols, PAGES):
        with col:
            st.page_link(path, label=label, use_container_width=True)


def hero(title: str, subtitle: str = "", chips=(), with_nav: bool = True):
    if with_nav:   # pages that already draw the navigation row pass with_nav=False
        nav()
    c = "".join(f'<span class="rp-chip">{esc(x)}</span>' for x in chips)
    st.markdown(f'<div class="rp-hero"><div class="t">{esc(title)}</div><div class="s">{esc(subtitle)}</div>{c}</div>', unsafe_allow_html=True)


def section(text: str):
    st.markdown(f'<div class="rp-section">{esc(text)}</div>', unsafe_allow_html=True)


def callout(text: str):
    st.markdown(f'<div class="rp-callout">{esc(text)}</div>', unsafe_allow_html=True)


def pill(text: str, tone: str = "muted") -> str:
    col = TONE[tone]
    return f'<span class="rp-pill" style="color:{col};border-color:{col};background:{col}1a">{esc(text)}</span>'


def pills(items) -> str:
    return "".join(pill(t, tone) for t, tone in items)


def card(title: str, body: str, icon: str = ""):
    ic = f'<div class="ic">{esc(icon)}</div>' if icon else ""
    st.markdown(f'<div class="rp-card">{ic}<div class="h">{esc(title)}</div><div class="d">{esc(body)}</div></div>', unsafe_allow_html=True)


def kpi(label: str, value: str, sub: str = "", tone: str = "info"):
    st.markdown(f'<div class="rp-kpi" style="--tone:{TONE[tone]}"><div class="l">{esc(label)}</div><div class="v">{esc(value)}</div>'
                f'<div class="x">{esc(sub)}</div></div>', unsafe_allow_html=True)


def verdict_card(label: str, tone: str, confidence: float, body: str = ""):
    st.markdown(f'<div class="rp-verdict" style="--tone:{TONE[tone]}"><div class="k">Claude verdict · confidence {confidence:.0%}</div>'
                f'<div class="v">{esc(label)}</div><div class="b">{esc(body)}</div>'
                f'<div class="rp-bar"><div style="width:{int(confidence * 100)}%"></div></div></div>', unsafe_allow_html=True)


def score_bar(score: float, tone: str = "good") -> str:
    return f'<div class="rp-bar" style="--tone:{TONE[tone]}"><div style="width:{int(max(0, min(1, score)) * 100)}%"></div></div>'


def pipeline(status: dict[str, str], backends: dict[str, str] | None = None):
    """status: step -> ok|degraded|error|skipped|pending."""
    col = {"ok": TONE["good"], "degraded": TONE["warn"], "error": TONE["bad"], "skipped": TONE["muted"], "pending": "#94a3b8"}
    icon = {"ok": "✓", "degraded": "!", "error": "✕", "skipped": "–", "pending": ""}
    out = []
    for i, (k, name) in enumerate(PIPELINE):
        s = status.get(k, "pending")
        out.append(f'<div class="rp-step" style="--tone:{col[s]}"><div class="c">{icon[s] or i + 1}</div><div class="n">{esc(name)}</div>'
                   f'<div class="m">{esc((backends or {}).get(k, ""))}</div></div>')
    st.markdown(f'<div class="rp-steps">{"".join(out)}</div>', unsafe_allow_html=True)
