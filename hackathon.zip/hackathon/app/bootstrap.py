"""Import first in every page: makes the repo root importable (so `import core` works under `streamlit run app/Home.py`)."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
