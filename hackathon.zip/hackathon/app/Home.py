import bootstrap  # noqa: F401  (adds repo root to sys.path)
import streamlit as st
from core.data_store import get_store
from core.orchestrator import backends_in_use
from components import theme

st.set_page_config(page_title="Retail Promotion Intelligence", page_icon="🏷️", layout="wide")
theme.inject()

try:
    store = get_store()
except FileNotFoundError as e:
    st.error(f"{e}"); st.stop()

backends = backends_in_use()
theme.hero("Retail Promotion Intelligence",
           "Know whether a promotion will make money before it launches. A team of Claude agents forecasts lift, cannibalization and ROI, "
           "challenges its own work, and proposes better promotions.",
           ["Lift forecast", "Basket cannibalization", "ROI & margin", "Independent risk critic", "Proactive opportunities"])

if not any(b in ("litellm", "claude", "claude-code") for b in backends.values()):
    st.info("No LLM configured (set LITELLM_BASE_URL and LITELLM_API_KEY): running the deterministic local agents.")
elif any(b == "litellm" for b in backends.values()):
    from core.agents.litellm_backend import is_configured
    if not is_configured():
        st.warning("Backend is `litellm` but LITELLM_BASE_URL / LITELLM_API_KEY are missing: agents will fall back to local.")

theme.section("Start here")
c = st.columns(3)
nav = [("📤", "Upload & analyze", "Drop in a CSV or build a promotion by hand. Agents normalise it and run the full evaluation.", "pages/1_Promotion_Upload.py", "Open upload"),
       ("💡", "Opportunities", "Events, weather, trends and overstock turned into promotions that were already evaluated and critiqued.", "pages/2_Opportunity_Dashboard.py", "Open opportunities"),
       ("📊", "Insights", "Verdict, lift, cannibalization, ROI and Claude's recommended fixes, with every decision explained.", "pages/3_Promotion_Insights.py", "Open insights")]
for col, (icon, title, desc, page, label) in zip(c, nav):
    with col:
        theme.card(title, desc, icon)
        st.page_link(page, label=label + " →")

theme.section("How the agents work together")
theme.pipeline({}, {"intake": "normalise", "trend": "signals", "simulate": "lift", "basket": "substitutes", "roi": "margin", "critic": "challenge", "recommend": "fix"})
st.caption("Independent steps run in parallel. If the critic says *revise*, the recommendation agent designs three alternatives, "
           "each is re-evaluated end to end, and the best is ranked. Every decision is logged.")

with st.expander("Technical details: agent backends and data sources"):
    left, right = st.columns(2)
    with left:
        st.markdown("**Agent backends**<br>" + theme.pills([(f"{a.replace('-agent', '')}: {b}", "good" if b.startswith("claude") or b == "litellm" else "info") for a, b in backends.items()]),
                    unsafe_allow_html=True)
        st.caption("`local` = deterministic offline agents. `litellm` = agents run via your LiteLLM proxy (automatic when LITELLM_* env is set). `claude-code` = local dev only. Override with RPIP_BACKEND.")
    with right:
        st.markdown("**Data**<br>" + theme.pills([(f"as-of {store.as_of}", "muted"), (f"{len(store.products)} products", "muted"),
                                                   (f"{len(store._promos())} past promotions", "muted")]), unsafe_allow_html=True)
        st.caption("Weather, holidays and trends are live when available; sales, inventory and baskets are synthetic.")
