"""Generate the synthetic retail dataset (stdlib only, deterministic).   python -m data.generate

Planted patterns for the demo (see ARCHITECTURE.md section 13):
  * Soft Drinks BOGO 50% on Coke/Sprite is a money loser at ANY lift (unit cost 63% of price).
  * Craft Root Beer (SKU-2201) is a high-margin substitute that gets cannibalized by cola promos.
  * Hot Cocoa / Marshmallows are overstocked while a cold snap + hot-beverage trend arrives (Dec 6-13).
  * Thanksgiving / Black Friday / Christmas events boost Baking and Snacks.
  * Past promotions that overlapped Black Friday show inflated lift (an analog the simulator should reject).
"""
from __future__ import annotations
import csv, math, random
from datetime import date, timedelta
from pathlib import Path

OUT = Path(__file__).parent / "csv"
AS_OF = date(2026, 11, 17)          # "today" for the mock world
rng = random.Random(42)

# sku, name, category, subcategory, brand, tier, size, price_cents, cost_cents, weekly_base_units (NE chain-wide)
PRODUCTS = [
    ("SKU-1042", "Coke 12pk", "Soft Drinks", "Cola", "Coca-Cola", "national", "12x12oz", 599, 380, 5200),
    ("SKU-1043", "Sprite 12pk", "Soft Drinks", "Lemon-Lime", "Coca-Cola", "national", "12x12oz", 599, 380, 3100),
    ("SKU-1044", "Pepsi 12pk", "Soft Drinks", "Cola", "Pepsi", "national", "12x12oz", 579, 370, 4800),
    ("SKU-1045", "Diet Coke 12pk", "Soft Drinks", "Cola", "Coca-Cola", "national", "12x12oz", 599, 380, 2900),
    ("SKU-1046", "Store Brand Cola 12pk", "Soft Drinks", "Cola", "Store", "private", "12x12oz", 399, 300, 2400),
    ("SKU-2201", "Craft Root Beer 6pk", "Soft Drinks", "Craft", "Barq's Reserve", "premium", "6x12oz", 799, 380, 900),
    ("SKU-3001", "Lays Classic 10oz", "Snacks", "Chips", "Lays", "national", "10oz", 449, 270, 3600),
    ("SKU-3002", "Doritos Nacho 9.75oz", "Snacks", "Chips", "Doritos", "national", "9.75oz", 449, 270, 3300),
    ("SKU-3003", "Pringles Original 5.5oz", "Snacks", "Chips", "Pringles", "national", "5.5oz", 249, 150, 2800),
    ("SKU-3005", "Tostitos Scoops 13oz", "Snacks", "Chips", "Tostitos", "national", "13oz", 449, 280, 2100),
    ("SKU-3004", "Tostitos Salsa 15oz", "Snacks", "Dips", "Tostitos", "national", "15oz", 399, 250, 1300),
    ("SKU-3310", "French Onion Dip 16oz", "Snacks", "Dips", "Lays", "national", "16oz", 349, 180, 1100),
    ("SKU-5001", "Hot Cocoa Mix 10ct", "Hot Beverages", "Cocoa", "Swiss Miss", "national", "10ct", 399, 190, 1500),
    ("SKU-5002", "Mini Marshmallows 10oz", "Hot Beverages", "Cocoa Add-ons", "Jet-Puffed", "national", "10oz", 249, 110, 1200),
    ("SKU-5003", "Folgers Classic Coffee 22oz", "Hot Beverages", "Coffee", "Folgers", "national", "22oz", 999, 650, 2600),
    ("SKU-5004", "Black Tea Bags 40ct", "Hot Beverages", "Tea", "Lipton", "national", "40ct", 449, 220, 1400),
    ("SKU-5005", "Cocoa Bombs 6ct", "Hot Beverages", "Cocoa", "Hot Cocoa Co", "premium", "6ct", 899, 380, 500),
    ("SKU-4001", "Dasani Water 24pk", "Water & Juice", "Water", "Dasani", "national", "24x16.9oz", 549, 330, 2700),
    ("SKU-4002", "Tropicana OJ 52oz", "Water & Juice", "Juice", "Tropicana", "national", "52oz", 449, 300, 2300),
    ("SKU-6001", "All-Purpose Flour 5lb", "Baking", "Staples", "Gold Medal", "national", "5lb", 399, 260, 1800),
    ("SKU-6002", "Granulated Sugar 4lb", "Baking", "Staples", "Domino", "national", "4lb", 349, 230, 1900),
    ("SKU-6003", "Chocolate Chips 12oz", "Baking", "Add-ins", "Nestle", "national", "12oz", 429, 230, 1600),
    ("SKU-6004", "Butter 1lb", "Baking", "Dairy", "Land O Lakes", "national", "1lb", 549, 380, 2200),
]
# category -> (lift coefficient e, seasonality by month Jan..Dec)
CATS = {
    "Soft Drinks":   (2.6, [.90, .90, .95, 1.0, 1.1, 1.15, 1.2, 1.15, 1.0, .95, .95, 1.05]),
    "Snacks":        (2.3, [1.1, .95, .95, 1.0, 1.0, 1.05, 1.0, .95, 1.0, 1.0, 1.1, 1.15]),
    "Hot Beverages": (2.4, [1.3, 1.15, .95, .85, .75, .7, .7, .7, .85, 1.0, 1.2, 1.35]),
    "Water & Juice": (1.6, [.9, .9, .95, 1.0, 1.1, 1.2, 1.25, 1.2, 1.05, .95, .9, .9]),
    "Baking":        (2.1, [1.0, .95, 1.0, 1.05, .95, .9, .85, .85, .95, 1.1, 1.5, 1.6]),
}
MECH_MULT = {"pct_off": 1.0, "bogo": 1.2, "multibuy": 1.1, "threshold": 0.85, "bundle": 0.95}

# substitutes: sku -> [(substitute, switch_rate: share of the sku's INCREMENTAL units that come from it)]
SUBSTITUTES = {
    "SKU-1042": [("SKU-1044", .08), ("SKU-1046", .05), ("SKU-2201", .09), ("SKU-1045", .04)],
    "SKU-1043": [("SKU-2201", .07), ("SKU-1046", .04)],
    "SKU-1044": [("SKU-1042", .12), ("SKU-1046", .06), ("SKU-2201", .10)],
    "SKU-3001": [("SKU-3002", .14), ("SKU-3003", .10)],
    "SKU-3002": [("SKU-3001", .14), ("SKU-3003", .08)],
    "SKU-5001": [("SKU-5005", .08), ("SKU-5003", .03)],
    "SKU-5005": [("SKU-5001", .20)],
    "SKU-4001": [("SKU-4002", .05)],
}
# complements: sku -> [(complement, affinity_lift, attach_rate: extra complement units per incremental unit)]
COMPLEMENTS = {
    "SKU-3001": [("SKU-3310", 2.1, .12)], "SKU-3002": [("SKU-3004", 1.7, .08)],
    "SKU-3005": [("SKU-3004", 3.2, .35)], "SKU-3004": [("SKU-3005", 3.2, .30)],
    "SKU-5001": [("SKU-5002", 3.8, .55)], "SKU-5002": [("SKU-5001", 3.8, .60)],
    "SKU-1042": [("SKU-3001", 1.4, .06)], "SKU-1044": [("SKU-3001", 1.4, .06)],
    "SKU-6003": [("SKU-6004", 2.2, .20), ("SKU-6001", 2.0, .18)], "SKU-6001": [("SKU-6002", 2.4, .25)],
    "SKU-5003": [("SKU-5002", 1.3, .05)],
}
# sku -> (on_hand, weeks_cover_hint, age_days)   weeks cover is recomputed from on_hand / base
INVENTORY_COVER = {"SKU-5001": 9.5, "SKU-5002": 11.0, "SKU-5005": 14.0, "SKU-4001": 8.5, "SKU-6004": 1.8,
                   "SKU-5003": 3.0, "SKU-1042": 2.8, "SKU-3001": 3.2}

EVENTS = [
    ("E-01", "Thanksgiving", "holiday", "2026-11-26", "2026-11-26", "NE", "Baking;Snacks", "+", "high"),
    ("E-02", "Black Friday weekend", "retail", "2026-11-27", "2026-11-30", "NE", "Snacks;Soft Drinks", "+", "high"),
    ("E-03", "Winter cold snap (forecast)", "weather", "2026-12-06", "2026-12-13", "NE", "Hot Beverages", "+", "high"),
    ("E-04", "Winter Solstice / holiday parties", "holiday", "2026-12-18", "2026-12-24", "NE", "Snacks;Soft Drinks;Baking", "+", "med"),
    ("E-05", "Christmas", "holiday", "2026-12-25", "2026-12-25", "NE", "Baking;Hot Beverages", "+", "high"),
    ("E-06", "NFL Playoffs Weekend", "sports", "2027-01-09", "2027-01-11", "NE", "Snacks;Soft Drinks", "+", "med"),
    ("E-07", "Black Friday 2025", "retail", "2025-11-28", "2025-12-01", "NE", "Snacks;Soft Drinks", "+", "high"),
]
TREND_INDEX_NOW = {"Hot Beverages": 1.34, "Snacks": 1.08, "Soft Drinks": 0.93, "Baking": 1.22, "Water & Juice": 0.9}


def w(name, header, rows):
    OUT.mkdir(parents=True, exist_ok=True)
    with open(OUT / name, "w", newline="", encoding="utf-8") as f:
        wr = csv.writer(f); wr.writerow(header); wr.writerows(rows)


def season(cat, d):  # smooth interpolation between month indices
    idx = CATS[cat][1]; m = d.month - 1; nxt = idx[(m + 1) % 12]
    frac = (d.day - 1) / 30
    return idx[m] * (1 - frac) + nxt * frac


def main():
    w("products.csv", "sku,name,category,subcategory,brand,tier,size,price_cents,unit_cost_cents".split(","),
      [p[:9] for p in PRODUCTS])
    w("seasonality.csv", ["category"] + [f"m{i}" for i in range(1, 13)], [[c, *v[1]] for c, v in CATS.items()])
    w("elasticity.csv", ["category", "lift_coefficient"], [[c, round(v[0] * rng.uniform(.93, 1.07), 2)] for c, v in CATS.items()])
    w("substitutes.csv", ["sku", "substitute_sku", "switch_rate", "basis"],
      [[a, b, r, "observed"] for a, lst in SUBSTITUTES.items() for b, r in lst])
    w("affinity.csv", ["sku", "complement_sku", "affinity_lift", "attach_rate", "basis"],
      [[a, b, l, r, "observed"] for a, lst in COMPLEMENTS.items() for b, l, r in lst])

    # weekly sales history (52 weeks ending AS_OF), seasonality + noise; promo weeks flagged
    cat_of = {p[0]: p[2] for p in PRODUCTS}
    sales, start = [], AS_OF - timedelta(weeks=52)
    for sku, *_rest in PRODUCTS:
        base = [p[9] for p in PRODUCTS if p[0] == sku][0]
        for k in range(52):
            d = start + timedelta(weeks=k)
            sales.append(["NE", sku, d.isoformat(), round(base * season(cat_of[sku], d) * rng.uniform(.93, 1.07))])
    w("sales_weekly.csv", ["region", "sku", "week_start", "units"], sales)

    # inventory (NE chain-wide)
    inv = []
    for sku, base in [(p[0], p[9]) for p in PRODUCTS]:
        cover = INVENTORY_COVER.get(sku, rng.uniform(3.5, 6.0))
        inv.append([sku, "NE", round(base * cover), round(cover, 1), int(cover * 7 * rng.uniform(.8, 1.4))])
    w("inventory.csv", ["sku", "region", "on_hand_units", "weeks_cover", "age_days"], inv)

    w("events.csv", "event_id,name,type,start,end,region,categories,direction,strength".split(","), EVENTS)
    w("trends.csv", ["category", "trend_index", "change_30d_pct", "source"],
      [[c, i, round((i - 1) * 100, 1), "search+social (mock)"] for c, i in TREND_INDEX_NOW.items()])

    # weather: next 30 days forecast with a cold snap Dec 6-13
    wx = []
    for k in range(0, 45):
        d = AS_OF + timedelta(days=k)
        t = 6 - 8 * math.sin((d - date(2026, 11, 1)).days / 60) + rng.uniform(-2, 2)
        if date(2026, 12, 6) <= d <= date(2026, 12, 13):
            t = rng.uniform(-8, -3)
        wx.append(["NE", d.isoformat(), round(t, 1), round(max(0, rng.gauss(2, 3)), 1)])
    w("weather_forecast.csv", ["region", "date", "temp_c", "precip_mm"], wx)

    # promotion history: 56 completed promotions (+1 active) with realised lift
    promos, pid = [], 30
    price = {p[0]: p[7] for p in PRODUCTS}; cost = {p[0]: p[8] for p in PRODUCTS}
    by_cat = {c: [p[0] for p in PRODUCTS if p[2] == c] for c in CATS}
    bf25 = (date(2025, 11, 28), date(2025, 12, 1))
    for i in range(56):
        cat = rng.choice(list(CATS)); mech = rng.choice(list(MECH_MULT)); depth = rng.choice([10, 15, 20, 25, 30, 35, 40, 50])
        if mech == "bogo": depth = 50
        skus = rng.sample(by_cat[cat], k=min(len(by_cat[cat]), rng.choice([1, 2])))
        st = start + timedelta(days=rng.randint(0, 340)); dur = rng.choice([7, 7, 14, 14, 21])
        en = st + timedelta(days=dur - 1)
        overlap = "Black Friday 2025" if (st <= bf25[1] and en >= bf25[0]) else ""
        if i in (3, 11, 25):    # force a few Black Friday overlaps with inflated lift
            st, en = date(2025, 11, 24), date(2025, 12, 7); overlap = "Black Friday 2025"; dur = 14
        stockout = rng.random() < .07
        lift = CATS[cat][0] * depth ** 1.1 * MECH_MULT[mech] * (1.55 if overlap else 1.0) * rng.uniform(.88, 1.12)
        lift *= 0.6 if stockout else 1.0
        base_units = sum(p[9] for p in PRODUCTS if p[0] in skus) * dur / 7
        promos.append([f"P-{pid + i:03d}", f"{cat} {mech} {depth}%", mech, depth, cat, ";".join(skus), st.isoformat(), en.isoformat(),
                       dur, round(base_units), round(lift, 1), overlap, int(stockout), "completed"])
    promos.append(["P-900", "Active: Lays Family Size", "pct_off", 15, "Snacks", "SKU-3001", "2026-11-10", "2026-11-23", 14,
                   round(3600 * 2), 40.0, "", 0, "active"])
    w("promotions_history.csv", "promo_id,name,mechanic,depth_pct,category,skus,start,end,duration_days,baseline_units,actual_lift_pct,event_overlap,stockout,status".split(","), promos)
    print(f"wrote dataset to {OUT} ({len(PRODUCTS)} products, {len(sales)} weekly sales rows, {len(promos)} promotions)")


if __name__ == "__main__":
    main()
