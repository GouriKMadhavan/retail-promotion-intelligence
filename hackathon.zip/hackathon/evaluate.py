"""Evaluate promotion(s) and print a short plain-English result.

  python evaluate.py "20% off cocoa from Dec 6 to Dec 13, 10% vendor funded"      # natural language
  python evaluate.py samples/promo_upload.csv                                       # CSV (any column names)
  python evaluate.py samples/promo_01.json                                          # JSON promotion

This is the Claude Code entry point: agents run through headless Claude Code (no LiteLLM, no API key) unless RPIP_BACKEND
or RPIP_BACKEND_<AGENT> is set (e.g. RPIP_BACKEND=local for a fast offline run). The dashboard uses LiteLLM when its key is set."""
from __future__ import annotations
import csv, io, json, os, sys
from pathlib import Path

os.environ.setdefault("RPIP_BACKEND", "claude-code")

sys.stdout.reconfigure(encoding="utf-8")
from core import registry
from core.nl_parse import parse_promotion_text
from core.orchestrator import run_workflow
from core.summary import summarize


def money(cents) -> str:
    return f"-${abs(cents) / 100:,.0f}" if cents < 0 else f"${cents / 100:,.0f}"


def load_input(arg: str):
    p = Path(arg)
    if p.exists():
        text = p.read_text(encoding="utf-8-sig")
        if p.suffix.lower() == ".json":
            return json.loads(text), "file"
        return {"rows": list(csv.DictReader(io.StringIO(text)))}, "file"
    raw, how = parse_promotion_text(arg)
    print(f"(read your description using: {how})")
    return raw, how


def show(bundle: dict) -> None:
    s, p = summarize(bundle), bundle["promotion"]
    crit = bundle["critic"]["output"]
    print("=" * 64)
    print(f"{p['name']}  [{p['mechanic']}, {p['depth_pct']:.0f}% off, {p['start']} to {p['end']}]")
    verdict = {"approve": "APPROVE", "approve_with_changes": "APPROVE WITH CHANGES", "revise": "REVISE (do not run as designed)"}.get(s["verdict"], s["verdict"])
    print(f"\nVERDICT: {verdict}   (confidence {s['confidence']:.0%})" if s["confidence"] is not None else f"\nVERDICT: {verdict}")
    print(f"  Expected sales lift:   {s['lift_pct']:.0f}%")
    print(f"  Net margin impact:     {money(s['net_margin_impact_cents'])}   (ROI {s['roi']:.0%})")
    if s.get("cannibalization_rate") is not None:
        print(f"  Cannibalization:       {s['cannibalization_rate']:.0%} of extra units come from your other products")
    if s.get("wasted_discount_pct_of_cost") is not None:
        print(f"  Wasted discount:       {s['wasted_discount_pct_of_cost']:.0f}% of the discount goes to people who would have bought anyway")
    if crit.get("risks"):
        print("\nWHY:")
        for r in crit["risks"][:3]:
            print(f"  - [{r['severity']}] {r['explanation']}")
    rec = (bundle.get("recommend") or {}).get("output") or {}
    alts = {a["id"]: a for a in rec.get("alternatives", [])}
    if rec.get("recommended_id") in alts:
        a, ev = alts[rec["recommended_id"]], alts[rec["recommended_id"]]["evaluation"]
        print(f"\nBETTER OPTION: {a['title']}")
        print(f"  {a['rationale']}")
        print(f"  Result: net margin {money(ev['net_margin_impact_cents'])}, ROI {ev['roi']:.0%}, verdict {ev['verdict'].replace('_', ' ')}")
        for aid, why in (rec.get("why_not_others") or {}).items():
            print(f"  Not chosen ({alts[aid]['label']}): {why}")
    print()


def main() -> int:
    if len(sys.argv) < 2:
        print(__doc__); return 1
    raw, _ = load_input(" ".join(sys.argv[1:]))
    env = registry.call("intake-agent", {"raw": raw})
    out = env["output"]
    for i in out.get("issues", []):
        print(f"{'ERROR' if i['severity'] == 'error' else 'note'}: {i['field']}: {i['message']}")
    if not out.get("promotions"):
        print("Could not read a valid promotion. Please add the missing details above."); return 2
    for promo in out["promotions"]:
        show(run_workflow("evaluate_promotion", {"promotion": promo}, persist=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
