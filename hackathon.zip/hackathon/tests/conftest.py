import os
os.environ.setdefault("RPIP_SIGNALS", "mock")      # tests are deterministic and offline; live signals are tested separately
# .env may set RPIP_BACKEND=claude-code (live, slow, non-deterministic). Tests run the deterministic local agents unless
# a test sets a backend itself via monkeypatch. Must be set before core.config loads .env.
os.environ["RPIP_BACKEND"] = "local"
