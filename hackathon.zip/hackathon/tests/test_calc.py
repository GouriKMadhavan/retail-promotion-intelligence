import pytest
from core.calc.lift import forecast_lift
from core.calc.basket import basket_effect
from core.calc.roi import promo_roi


def test_lift_ordering_and_units():
    r = forecast_lift([{"lift_pct": 20, "weight": 1}, {"lift_pct": 40, "weight": 1}], 0.95, 1.10, 10000)
    assert r["lift_pct"]["low"] <= r["lift_pct"]["expected"] <= r["lift_pct"]["high"]
    # units use unrounded lift; displayed lift is rounded to 0.1pt => <= 5 units apart on 10k baseline
    assert abs(r["incremental_units"]["expected"] - 10000 * r["lift_pct"]["expected"] / 100) <= 5


def test_lift_requires_analogs():
    with pytest.raises(ValueError):
        forecast_lift([], 1, 1, 100)


def test_basket_switch_rates_validated():
    with pytest.raises(ValueError):
        basket_effect(100, [{"sku": "a", "switch_rate": 0.7, "unit_margin_cents": 1},
                            {"sku": "b", "switch_rate": 0.5, "unit_margin_cents": 1}], [])


def test_basket_math():
    r = basket_effect(1000, [{"sku": "s", "switch_rate": 0.2, "unit_margin_cents": 100}],
                      [{"sku": "c", "attach_rate": 0.1, "unit_margin_cents": 50}])
    assert r["cannibalization_rate"] == 0.2
    assert r["net_basket_effect"]["margin_cents"] == 5000 - 20000


def test_roi_break_even_is_zero_net():
    kw = dict(baseline_units=10000, price_cents=300, unit_cost_cents=180, depth_pct=25, funding_pct=20)
    be = promo_roi(lift_pct=0, **kw)["break_even_lift_pct"]
    assert abs(promo_roi(lift_pct=be, **kw)["net_margin_impact_cents"]) <= 2


def test_roi_zero_lift_loses_money():
    r = promo_roi(10000, 0, 300, 180, 25)
    assert r["net_margin_impact_cents"] < 0 and r["wasted_discount_cents"] == r["promo_cost_cents"]
