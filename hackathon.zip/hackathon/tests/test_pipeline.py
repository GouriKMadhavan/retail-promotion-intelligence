import json, pathlib, pytest
from core import registry
from core.contracts import validate_envelope
from core.orchestrator import run_workflow, _resolve
from core.summary import summarize

S = pathlib.Path(__file__).resolve().parent.parent / "samples"
load = lambda n: json.loads((S / n).read_text(encoding="utf-8"))
ev = lambda p, **kw: run_workflow("evaluate_promotion", {"promotion": p}, **kw)


def test_resolver_paths():
    assert _resolve("$.a.b[0].c", {"a": {"b": [{"c": 5}]}}) == 5
    assert _resolve("$.x[:2]", {"x": [1, 2, 3]}) == [1, 2]
    assert _resolve("$.missing.y", {}) is None


def test_trap_promotion_is_flagged_and_repaired():
    b = run_workflow("evaluate_promotion", {"promotion": load("promo_01.json"), "alternatives": True})  # opt-in: user asked for better options
    assert b["critic"]["output"]["verdict"] == "revise"
    assert summarize(b)["net_margin_impact_cents"] < 0
    rec = b["recommend"]["output"]
    assert len(rec["alternatives"]) == 3 and all("evaluation" in a for a in rec["alternatives"])
    assert rec["recommended_id"] in {"A1", "A2", "A3", "defer", "original"}


def test_winner_is_approved_without_recommendations():
    b = ev(load("promo_03.json"))
    assert b["critic"]["output"]["verdict"] == "approve" and "recommend" not in b


def test_every_hop_satisfies_contract_and_is_logged():
    b = ev(load("promo_02.json"))
    for t in b["trace"]:
        env = b["recommend"] if t["step"] == "rank" else b[t["step"]]      # rank replaces the recommend envelope
        assert not env.get("contract_errors"), t
        assert env["assumptions"] and env["evidence"], t
    assert b["decision_log"]


def test_intake_resolves_messy_csv_and_flags_bad_rows():
    rows = [{"Promo Name": "x", "Type": "2-for-1", "Discount %": "50", "Products": "coke 12 pk; sprite", "Start": "12/01/2026", "End": "12/14/2026"},
            {"Promo Name": "bad", "Type": "% off", "Discount %": "20", "Products": "unobtainium", "Start": "2026-12-01", "End": "2026-12-05"}]
    out = registry.call("intake-agent", {"raw": {"rows": rows}})["output"]
    assert out["promotions"][0]["mechanic"] == "bogo" and out["promotions"][0]["skus"] == ["SKU-1042", "SKU-1043"]
    assert any(i["severity"] == "error" for i in out["issues"])


def test_opportunity_feed_is_pre_evaluated_and_ranked():
    f = run_workflow("recommend_promotions", {"horizon_days": 30, "region": "NE"})
    assert f["evaluate"] and all("evaluation" in a and "bundle" in a for a in f["evaluate"])
    assert {r["id"] for r in f["rank"]["output"]["ranking"]} == {a["id"] for a in f["evaluate"]}
    assert f["scout"]["output"]["skipped"]          # Snacks skipped: active promotion P-900


def test_contract_violation_is_detected():
    bad = {"agent": "roi-agent", "status": "ok", "confidence": 0.5, "output": {"headline": "great"}}
    assert validate_envelope("roi-agent", bad)


def test_backend_override(monkeypatch):
    monkeypatch.setenv("RPIP_BACKEND_ROI_AGENT", "claude")
    assert registry.get_agent("roi-agent").backend == "claude" and registry.get_agent("trend-agent").backend == "local"
