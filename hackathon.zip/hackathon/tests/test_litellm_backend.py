import json
from core import registry
from core.agents import litellm_backend as lb


def _env(monkeypatch, on=True):
    for k in ("RPIP_BACKEND", "RPIP_BACKEND_TREND_AGENT", "LITELLM_MODEL"):
        monkeypatch.delenv(k, raising=False)
    if on:
        monkeypatch.setenv("LITELLM_BASE_URL", "http://proxy.test")
        monkeypatch.setenv("LITELLM_API_KEY", "sk-test")
    else:
        monkeypatch.delenv("LITELLM_BASE_URL", raising=False); monkeypatch.delenv("LITELLM_API_KEY", raising=False)


def test_default_backend_switches_on_litellm_env(monkeypatch):
    _env(monkeypatch, on=False)
    assert registry.backend_for("trend-agent") == "local"
    _env(monkeypatch, on=True)
    assert registry.backend_for("trend-agent") == "litellm"
    monkeypatch.setenv("RPIP_BACKEND", "local")
    assert registry.backend_for("trend-agent") == "local"


def test_tool_loop_then_envelope(monkeypatch):
    _env(monkeypatch)
    replies = iter([
        {"content": None, "tool_calls": [{"id": "c1", "type": "function", "function": {"name": "get_trends", "arguments": "{}"}}]},
        {"content": '```json\n{"agent":"trend-agent","status":"ok","confidence":0.7,"output":{"demand_hint":1.1}}\n```'},
    ])
    seen = []
    monkeypatch.setattr(lb, "_chat", lambda model, messages, tools: (seen.append(messages[-1]), next(replies))[1])
    out = lb.run_agent("trend-agent", {"window": {"start": "2026-11-20", "end": "2026-11-27"}})
    assert out["output"]["demand_hint"] == 1.1 and out["status"] == "ok"
    assert seen[1]["role"] == "tool" and json.loads(seen[1]["content"])  # tool result was fed back


def test_failure_falls_back_to_local_degraded(monkeypatch):
    _env(monkeypatch)
    monkeypatch.setattr(lb, "_chat", lambda *a, **k: (_ for _ in ()).throw(RuntimeError("proxy down")))
    assert registry.backend_for("risk-critic-agent") == "litellm"
    agent = registry.get_agent("trend-agent")
    out = agent.run({"window": {"start": "2026-11-20", "end": "2026-11-27"}, "region": "NE"})
    assert out["status"] in ("degraded", "error")
