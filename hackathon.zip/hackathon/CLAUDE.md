# Retail Promotion Intelligence Platform (RPIP)

Dashboard-first platform that predicts promotion lift, basket-level cannibalization, ROI and margin impact BEFORE launch,
and proactively recommends better promotions. Claude is the decision-maker; small Python tools are the calculators.
Full design: `ARCHITECTURE.md`. Invocation examples: `samples/invocations.md`.

## Core principles (non-negotiable)
1. **Claude decides, tools compute.** Agents never do arithmetic or invent numbers. Every figure comes from an MCP tool
   (`mcp__retail_data__*`, `mcp__signals__*`) or `core/calc/*.py`. If unavailable: "unknown" + lower confidence.
2. **Every major decision is made by an agent and logged** (agent, decision, rationale, evidence, confidence).
   Major decisions: analog selection, substitute/complement sets, risk verdict, alternative design, opportunity ranking.
3. **Dashboard is the product.** No chat UI. Claude output renders as structured cards.
4. **Agents exchange JSON only**, in the common envelope:
   `{agent, status: ok|degraded|error, confidence, assumptions[], evidence[], output{}}`. Validate each hop; retry once with the error.
5. **Independence:** risk-critic sees outputs only, never other agents' reasoning.
6. **Synthetic data only.** No real customer data or PII in the repo.

## Agents (`.claude/agents/`)
| Agent | Job |
|---|---|
| promo-orchestrator | routes workflow steps, retries, loops |
| intake-agent | normalizes uploads/forms into Promotion objects |
| trend-agent | events, weather, trends, seasonality -> demand hint |
| promotion-simulator-agent | lift forecast, baseline-buyer share (analog reasoning) |
| basket-intelligence-agent | substitutes, complements, net basket effect |
| roi-agent | ROI, margin impact, wasted discount, break-even |
| risk-critic-agent | independent verdict: approve / approve_with_changes / revise |
| recommendation-agent | designs/ranks alternatives (reactive) and proposals (proactive) |
| opportunity-scout-agent | scans signals + inventory + baskets for opportunities |

Order: intake -> trend -> simulate -> basket -> roi -> critic -> (recommendation -> re-evaluate -> rank). See `workflows/`.

## Two planes
- **Build-time:** Claude Code + these sub-agents build the repo (parallelize with the Workflow tool when asked).
- **Run-time:** `core/orchestrator.py` runs the same agent files via the Claude API (`core/agent_runner.py`). One source of truth: edit the `.md`.

## Layout
`app/` Streamlit (Home + 3 pages) · `core/` orchestrator, agent_runner, config, `calc/` math, `schemas/` contracts ·
`mcp_servers/` retail_data + signals (TODO) · `workflows/*.yaml` · `samples/` · `data/` synthetic · `tests/`

## Commands
- `pip install -r requirements.txt` (Python 3.10+); core engine + tests need only pydantic + pyyaml
- `python -m data.generate` rebuild the synthetic dataset in `data/csv/`
- `python -m pytest tests` (14 tests: calc, contracts, full workflows, intake, backend override)
- `python -m core.orchestrator evaluate samples/promo_01.json` / `recommend samples/scan.json` (CLI, persists to `data/runs/`)
- `streamlit run app/Home.py` dashboard
- `python -m core.contracts` re-export JSON Schemas to `core/schemas/`

## Live vs mock signals
`RPIP_SIGNALS=live` (default) pulls weather (Open-Meteo, 16-day), holidays (Nager.Date, + derived Black Friday / Super Bowl) and trends
(Google Trends via optional `pytrends`) through `core/live_signals.py`, cached in `data/cache/`. Any failure falls back to stale cache, then to
mock CSVs, and the source is reported in `trend.output.data_sources` and on the dashboard. `RPIP_SIGNALS=mock` = fixed demo world
(as-of 2026-11-17, planted cold snap); tests force this. Sales, inventory, baskets and promo history are always mock.

## Agent backends (modularity seam)
`core/registry.py` picks the implementation per agent. Default `local` = deterministic agents in `core/agents/local/` over `core/data_store.py`.
`RPIP_BACKEND=claude` or `RPIP_BACKEND_ROI_AGENT=claude` swaps in `core/agents/claude_backend.py` (uses `.claude/agents/<name>.md`).
Same payload, same envelope, validated by `core/contracts.py` on every hop. Claude backend has no tool loop yet.

## Conventions
- Python 3.11, type hints. Money = integer cents; percentages 0-100 unless a field says fraction.
- Prompts live in markdown, not Python. Keep each under ~150 lines. Model tiers in `core/config.py`.
- Adding an agent = prompt file + contract + workflow step + dashboard card + decision_log entry.
- The demo path (upload -> insights) must always work; prefer vertical slices.

## Status
Done: dataset + generator, data_store (MCP-shaped API), local agents, contracts + schemas, orchestrator (foreach, hooks, validation, decision log, trace),
Streamlit Home + 3 pages. Verified: tests pass. NOT verified: Streamlit pages (compile-checked only), Claude backend.
TODO: tool-use loop for Claude backend / real MCP servers + `.mcp.json`, real signal APIs, charts polish.

## Testing-only TLS switch
`RPIP_INSECURE_TLS=1` disables certificate verification for the Google Trends (pytrends) call only, for proxy environments. Off by default; a
warning appears on the dashboard and in `python -m core.live_signals` whenever it is on. Prefer `pip install truststore` or the corporate CA bundle.
Unset it before submission.
