"""JSON contracts between agents (pydantic v2). Models are permissive (extra="allow") so a Claude-backed agent may add
fields, but required fields must be present and correctly typed. `validate_envelope` is called by the orchestrator on every hop.
Export JSON Schemas for the prompts / Claude tool definitions:  python -m core.contracts"""
from __future__ import annotations
import json
from pathlib import Path
from typing import Any, Literal, Optional
from pydantic import BaseModel, ConfigDict, Field, ValidationError


class C(BaseModel):
    model_config = ConfigDict(extra="allow")


class Envelope(C):
    agent: str
    status: Literal["ok", "degraded", "error"]
    confidence: float = Field(0, ge=0, le=1)
    assumptions: list[str] = []
    evidence: list[dict[str, Any]] = []
    decisions: list[dict[str, Any]] = []      # major decisions: {decision, rationale, confidence}
    output: dict[str, Any]


class Window(C):
    start: str
    end: str


class Promotion(C):
    promo_id: str
    name: str
    mechanic: Literal["pct_off", "bogo", "multibuy", "threshold", "bundle"]
    depth_pct: float = Field(ge=0, lt=100)
    skus: list[str] = Field(min_length=1)
    stores: list[str] = ["ALL"]
    region: str = "NE"
    start: str
    end: str
    window: Window
    categories: list[str]
    funding_pct: float = Field(0, ge=0, le=100)
    targeting: Literal["all", "loyalty", "lapsed"] = "all"


class Issue(C):
    severity: Literal["error", "warn"]
    field: str
    message: str


class PromotionBatch(C):
    promotions: list[Promotion]
    issues: list[Issue] = []


class Hint(C):
    low: float
    high: float
    reasoning: str = ""


class TrendReport(C):
    signals: list[dict[str, Any]] = []
    conflicts: list[dict[str, Any]] = []
    demand_multiplier_hint: Hint
    emerging_opportunities: list[dict[str, Any]] = []
    data_gaps: list[str] = []


class Range(C):
    low: float
    expected: float
    high: float


class Simulation(C):
    promo_id: str
    baseline_units: int
    lift_pct: Range
    incremental_units: Range
    baseline_buyer_share: float = Field(ge=0, le=1)   # share of would-buy-anyway units that redeem the discount
    analogs_used: list[dict[str, Any]]
    analogs_rejected: list[dict[str, Any]] = []
    elasticity_cross_check: dict[str, Any] = {}


class Basket(C):
    substitutes: list[dict[str, Any]] = []
    complements: list[dict[str, Any]] = []
    cannibalization_rate: float
    net_basket_effect: dict[str, Any]
    scenarios: dict[str, dict[str, Any]]
    high_risk_skus: list[str] = []
    bundle_candidates: list[dict[str, Any]] = []


class Roi(C):
    headline: Literal["profitable", "fragile", "loses_money"]
    scenarios: dict[str, dict[str, Any]]
    expected: dict[str, Any]
    break_even_lift_pct: Optional[float] = None
    clears_break_even: bool
    inventory: dict[str, Any] = {}
    financial_summary: str


class Risk(C):
    type: str
    severity: Literal["low", "med", "high"]
    explanation: str
    evidence: list[str] = []


class RiskAssessment(C):
    verdict: Literal["approve", "approve_with_changes", "revise"]
    risks: list[Risk] = []
    required_changes: list[str] = []
    overall_confidence: float = Field(ge=0, le=1)


class Alternative(C):
    id: str
    label: str = ""
    changes: dict[str, Any] = {}
    rationale: str = ""


class Recommendation(C):
    mode: Literal["reactive", "proactive", "rank"]
    alternatives: list[Alternative] = []
    recommended_id: Optional[str] = None
    ranking: list[dict[str, Any]] = []
    why_not_others: dict[str, str] = {}


class Opportunity(C):
    id: str
    title: str
    category: str
    target_products: list[str]
    window: Window
    why_now: str
    trigger_signals: list[str] = []
    urgency: Literal["low", "med", "high"]
    opportunity_score: float = Field(ge=0, le=1)


class OpportunityList(C):
    opportunities: list[Opportunity]
    skipped: list[dict[str, Any]] = []


OUTPUT_MODELS: dict[str, type[C]] = {
    "intake-agent": PromotionBatch,
    "trend-agent": TrendReport,
    "promotion-simulator-agent": Simulation,
    "basket-intelligence-agent": Basket,
    "roi-agent": Roi,
    "risk-critic-agent": RiskAssessment,
    "recommendation-agent": Recommendation,
    "opportunity-scout-agent": OpportunityList,
}


def validate_envelope(agent: str, env: dict) -> list[str]:
    """Return a list of contract violations (empty = valid)."""
    try:
        e = Envelope.model_validate(env)
    except ValidationError as ex:
        return [f"envelope: {err['loc']}: {err['msg']}" for err in ex.errors()]
    if e.status == "error":
        return []
    model = OUTPUT_MODELS.get(agent)
    if not model:
        return []
    try:
        model.model_validate(e.output)
    except ValidationError as ex:
        return [f"output.{'.'.join(map(str, err['loc']))}: {err['msg']}" for err in ex.errors()]
    return []


def export_schemas(out_dir: Path | None = None) -> list[Path]:
    out_dir = out_dir or Path(__file__).parent / "schemas"
    out_dir.mkdir(exist_ok=True)
    paths = []
    for name, model in {"envelope": Envelope, **{k.replace("-agent", ""): v for k, v in OUTPUT_MODELS.items()}}.items():
        p = out_dir / f"{name}.schema.json"
        p.write_text(json.dumps(model.model_json_schema(), indent=2), encoding="utf-8")
        paths.append(p)
    return paths


if __name__ == "__main__":
    for p in export_schemas():
        print("wrote", p)
