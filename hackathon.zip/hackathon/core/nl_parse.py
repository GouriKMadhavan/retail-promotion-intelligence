"""Natural-language promotion description -> raw fields for the intake agent.

parse_promotion_text(text) tries headless Claude Code (`claude -p`, no API key) first, then falls back to simple rules.
Returns (raw_dict, method) where method is 'claude-code' or 'rules'. The result is only a *draft*: it still goes through
intake-agent (SKU resolution, validation) and the user's review before anything is analyzed."""
from __future__ import annotations
import json, os, re, shutil, subprocess, tempfile
from datetime import date, datetime, timedelta
from . import config
from .data_store import get_store

MONTHS = {m: i for i, m in enumerate(["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}
SYSTEM = """You extract a retail promotion from a user's plain-English description. Reply with ONE JSON object only, no prose:
{"name": str, "mechanic": "pct_off|bogo|multibuy|threshold|bundle", "depth_pct": number, "skus": [str], "start": "YYYY-MM-DD",
 "end": "YYYY-MM-DD", "funding_pct": number, "targeting": "all|loyalty|lapsed"}
Rules: "2-for-1"/"buy one get one" = bogo with depth_pct 50. "Black Friday" = the Friday after Thanksgiving, and "Black Friday weekend"
(also the default for "black friday" with no other dates) runs from that Friday through the following Monday. Thanksgiving = 4th Thursday of November.
Choose skus ONLY from the catalog given (use the exact SKU codes);
if a product is not in the catalog put the user's words in skus anyway. Dates: use the reference date to infer the year (next upcoming
occurrence). Use null for anything the user did not say; never invent values."""


def _catalog_text(store) -> str:
    return "\n".join(f"{s}: {p['name']} ({p['category']})" for s, p in store.products.items())


def _via_litellm(text: str, store) -> dict | None:
    """Same model and proxy as the agents (LITELLM_BASE_URL / LITELLM_API_KEY / LITELLM_MODEL). None if not configured or it fails."""
    from .agents.litellm_backend import _chat, is_configured
    if not is_configured():
        return None
    model = os.getenv("LITELLM_MODEL") or config.TIERS["fast"]
    prompt = f"Reference date: {store.as_of}\n\nCatalog:\n{_catalog_text(store)}\n\nDescription:\n{text}\n\nReturn ONLY the JSON object."
    try:
        msg = _chat(model, [{"role": "system", "content": SYSTEM}, {"role": "user", "content": prompt}], [])
        out = msg.get("content") or ""
        return json.loads(out[out.index("{"): out.rindex("}") + 1])
    except Exception:
        return None


def _via_claude_code(text: str, store) -> dict | None:
    exe = shutil.which("claude")
    if not exe:
        return None
    sp = os.path.join(tempfile.gettempdir(), "rpip_nl_system.md")
    open(sp, "w", encoding="utf-8").write(SYSTEM)
    prompt = f"Reference date: {store.as_of}\n\nCatalog:\n{_catalog_text(store)}\n\nDescription:\n{text}\n\nReturn ONLY the JSON object."
    try:
        r = subprocess.run([exe, "-p", "--system-prompt-file", sp, "--tools", "", "--model", "haiku", "--permission-mode", "dontAsk"],
                           input=prompt, capture_output=True, text=True, encoding="utf-8", timeout=90, cwd=tempfile.gettempdir())
        if r.returncode != 0:
            return None
        out = r.stdout
        return json.loads(out[out.index("{"): out.rindex("}") + 1])
    except Exception:
        return None


def _parse_date(m, ref: date) -> date | None:
    """m = (month_name, day) -> next occurrence on/after ref - 30d."""
    mon = MONTHS.get(m[0][:3].lower())
    if not mon:
        return None
    for yr in (ref.year, ref.year + 1):
        try:
            d = date(yr, mon, int(m[1]))
        except ValueError:
            return None
        if d >= ref - timedelta(days=30):
            return d
    return None


def _via_rules(text: str, store) -> dict:
    t = text.lower()
    raw: dict = {"name": text.strip().split(".")[0][:60] or "My promotion"}
    if re.search(r"bogo|2[- ]?for[- ]?1|buy one,? get one|b1g1", t):
        raw["mechanic"], raw["depth_pct"] = "bogo", 50
    elif "bundle" in t:
        raw["mechanic"] = "bundle"
    elif re.search(r"spend|threshold", t):
        raw["mechanic"] = "threshold"
    elif re.search(r"multi|\d\s*for\s*\$", t):
        raw["mechanic"] = "multibuy"
    else:
        raw["mechanic"] = "pct_off"
    m = re.search(r"(\d{1,2}(?:\.\d+)?)\s*(?:%|percent|pct)\s*(?:off|discount)?", t)
    if m and "funding" not in t[m.end(): m.end() + 12]:
        raw.setdefault("depth_pct", float(m.group(1)))
    f = re.search(r"(\d{1,2})\s*%\s*(?:vendor\s*)?funded|funding\s*(?:of\s*)?(\d{1,2})\s*%|vendor funding\s*(\d{1,2})", t)
    if f:
        raw["funding_pct"] = float(next(g for g in f.groups() if g))
        if raw.get("depth_pct") == raw["funding_pct"] and re.search(r"(\d+)\s*%\s*off", t):
            raw["depth_pct"] = float(re.search(r"(\d+)\s*%\s*off", t).group(1))
    raw["targeting"] = "loyalty" if "loyal" in t else "lapsed" if "lapsed" in t else "all"
    ds = re.findall(r"(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+(\d{1,2})", t)
    if len(ds) >= 2:
        a, b = _parse_date(ds[0], store.as_of), _parse_date(ds[1], store.as_of)
        if a and b:
            raw["start"], raw["end"] = a.isoformat(), b.isoformat()
    else:
        iso = re.findall(r"\d{4}-\d{2}-\d{2}", t)
        if len(iso) >= 2:
            raw["start"], raw["end"] = iso[0], iso[1]
    found = [s for s, p in store.products.items()
             if s.lower() in t or p["name"].lower() in t or (p["name"].lower().split()[0] in t and len(p["name"].split()[0]) > 3 and p["name"].lower() in t)]
    if not found:  # fall back to category words / partial name words
        words = set(re.findall(r"[a-z]{4,}", t))
        found = [s for s, p in store.products.items() if words & set(re.findall(r"[a-z]{4,}", p["name"].lower()))][:6]
    raw["skus"] = found
    return raw


def parse_promotion_text(text: str) -> tuple[dict, str]:
    store = get_store()
    # Same backend as the agents: RPIP_BACKEND=claude-code tries Claude Code first, otherwise LiteLLM first. Rules are the last resort.
    if os.getenv("RPIP_BACKEND") == "claude-code":
        tries = [("claude-code", _via_claude_code), ("litellm", _via_litellm)]
    else:
        tries = [("litellm", _via_litellm), ("claude-code", _via_claude_code)]
    raw, how = None, "rules"
    for name, fn in tries:
        raw = fn(text, store)
        if raw:
            how = name
            break
    if raw:
        raw = {k: v for k, v in raw.items() if v is not None}
    else:
        raw, how = _via_rules(text, store), "rules"
    if not str(raw.get("name") or "").strip() or raw.get("name") == text.strip()[:60]:
        names = [store.products[s]["name"] for s in raw.get("skus", []) if s in store.products][:2]
        offer = {"bogo": "BOGO", "bundle": "Bundle", "threshold": "Spend deal", "multibuy": "Multi-buy"}.get(raw.get("mechanic"), f"{raw.get('depth_pct', '')}% off".strip())
        raw["name"] = f"{offer}: {', '.join(names)}" if names else offer
    return raw, how
