"""Model tiers per agent. Override with env vars, e.g. RPIP_MODEL_TOP=claude-opus-5-5."""
import os
from pathlib import Path


def _load_dotenv() -> None:
    """Minimal .env loader (no extra dependency). Real environment variables win over the file."""
    p = Path(__file__).resolve().parent.parent / ".env"
    if not p.is_file():
        return
    for line in p.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            if v.strip().strip("\"'"):
                os.environ.setdefault(k.strip(), v.strip().strip("\"'"))


_load_dotenv()

TIERS = {
    "top": os.getenv("RPIP_MODEL_TOP", "claude-fable-5-2"),
    "mid": os.getenv("RPIP_MODEL_MID", "claude-sonnet-5-5"),
    "fast": os.getenv("RPIP_MODEL_FAST", "claude-haiku-5-5"),
}
# frontmatter aliases in .claude/agents/*.md -> tier
ALIAS = {"opus": "top", "sonnet": "mid", "haiku": "fast"}

AGENTS_DIR = ".claude/agents"
WORKFLOWS_DIR = "workflows"
MAX_TOKENS = 4096
