"""Runs one agent: loads .claude/agents/<name>.md (frontmatter + system prompt), calls Claude, returns validated JSON.

SKELETON: tool use is not wired yet. TODO(phase 3): bind mcp_servers/* tools + calc scripts via the Anthropic tool-use loop
(or Claude Agent SDK `query()` with mcp_servers from .mcp.json) using the `tools:` frontmatter list as an allowlist.
"""
from __future__ import annotations
import json, re
from pathlib import Path
import yaml
from . import config

_client = None


def _load(name: str) -> tuple[dict, str]:
    text = Path(config.AGENTS_DIR, f"{name}.md").read_text(encoding="utf-8")
    m = re.match(r"^---\n(.*?)\n---\n(.*)$", text, re.S)
    if not m:
        raise ValueError(f"{name}: missing frontmatter")
    return yaml.safe_load(m.group(1)), m.group(2).strip()


def _extract_json(text: str) -> dict:
    text = text.strip()
    fence = re.search(r"```(?:json)?\s*(\{.*\})\s*```", text, re.S)
    return json.loads(fence.group(1) if fence else text[text.index("{"): text.rindex("}") + 1])


def run_agent(name: str, payload: dict, retries: int = 1) -> dict:
    global _client
    if _client is None:
        import anthropic  # lazy: lets the orchestrator be imported/tested without the SDK
        _client = anthropic.Anthropic()
    meta, system = _load(name)
    model = config.TIERS[config.ALIAS.get(meta.get("model", "sonnet"), "mid")]
    messages = [{"role": "user", "content": json.dumps(payload, ensure_ascii=False)}]
    last_err = None
    for _ in range(retries + 1):
        resp = _client.messages.create(model=model, max_tokens=config.MAX_TOKENS, system=system, messages=messages)
        text = "".join(b.text for b in resp.content if b.type == "text")
        try:
            out = _extract_json(text)
            for k in ("agent", "status", "output"):
                if k not in out:
                    raise ValueError(f"missing envelope key '{k}'")
            return out
        except Exception as e:  # invalid JSON / envelope: feed the error back once
            last_err = e
            messages += [{"role": "assistant", "content": text},
                         {"role": "user", "content": f"Invalid output: {e}. Return only the corrected JSON."}]
    return {"agent": name, "status": "error", "confidence": 0, "assumptions": [], "evidence": [],
            "output": {"error": str(last_err)}}
