"""Claude-API backend: runs .claude/agents/<name>.md as the system prompt via core/agent_runner.py.
Drop-in replacement for a local agent: same name, same payload, same envelope.

LIMITATION (documented, next step): tool use is not wired yet, so the model cannot call the data tools. Until DataStore methods are
exposed as MCP tools / Anthropic tools, set RPIP_BACKEND_<AGENT> to `claude` only for agents whose payload already carries the data they need
(e.g. risk-critic-agent and the `rank` mode of recommendation-agent)."""
from __future__ import annotations
from .base import Agent, error_envelope


class ClaudeAgent(Agent):
    backend = "claude"

    def __init__(self, name: str):
        self.name = name

    def run(self, payload: dict) -> dict:
        from ..agent_runner import run_agent  # lazy: needs `anthropic` + ANTHROPIC_API_KEY
        try:
            return run_agent(self.name, payload)
        except Exception as e:
            return error_envelope(self.name, f"claude backend failed: {e}")
