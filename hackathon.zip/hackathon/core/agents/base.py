"""Agent interface. An agent is anything with a name and run(payload) -> envelope dict (see core/contracts.py).
Backends: `local` (deterministic, data-driven, offline), `claude` (Claude API using .claude/agents/<name>.md),
and later `claude-code` (sub-agent via the Agent SDK). Select per agent in core/registry.py."""
from __future__ import annotations
from abc import ABC, abstractmethod


class Agent(ABC):
    name: str = ""
    backend: str = "local"

    @abstractmethod
    def run(self, payload: dict) -> dict: ...


def envelope(agent: str, output: dict, confidence: float, assumptions=(), evidence=(), decisions=(), status="ok") -> dict:
    return {"agent": agent, "status": status, "confidence": round(max(0.0, min(1.0, confidence)), 2),
            "assumptions": list(assumptions), "evidence": list(evidence), "decisions": list(decisions), "output": output}


def error_envelope(agent: str, message: str) -> dict:
    return envelope(agent, {"error": message}, 0, status="error")
