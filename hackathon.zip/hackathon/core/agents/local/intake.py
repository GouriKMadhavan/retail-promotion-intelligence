"""Intake: maps messy upload columns / form values to normalized Promotion objects, resolves SKUs, flags issues."""
from __future__ import annotations
import hashlib, re
from datetime import datetime
from ..base import Agent, envelope
from ...data_store import get_store

ALIASES = {
    "name": ["name", "promo name", "promotion name", "promotion", "promo"],
    "mechanic": ["mechanic", "type", "promo type", "offer type", "offer"],
    "depth_pct": ["depth_pct", "discount %", "discount", "depth", "depth %", "percent off", "pct"],
    "skus": ["skus", "products", "sku", "items", "product"],
    "start": ["start", "start date", "start_date", "begin"],
    "end": ["end", "end date", "end_date", "finish"],
    "stores": ["stores", "store", "store scope"],
    "funding_pct": ["funding_pct", "vendor funding %", "vendor funding", "funding", "funding %"],
    "region": ["region"],
    "targeting": ["targeting", "audience", "segment"],
    "promo_id": ["promo_id", "id"],
}
_ALIAS_LOOKUP = {a: canon for canon, al in ALIASES.items() for a in al}


def _mechanic(text: str):
    t = str(text or "").lower()
    if any(k in t for k in ("bogo", "2-for-1", "2 for 1", "buy one", "b1g1")): return "bogo", None
    if "bundle" in t: return "bundle", None
    if any(k in t for k in ("thresh", "spend")): return "threshold", None
    if "multi" in t or "for $" in t: return "multibuy", None
    if any(k in t for k in ("pct", "percent", "%", "off")): return "pct_off", None
    return "pct_off", f"Unrecognised mechanic '{text}', assumed pct_off" if t else "No mechanic given, assumed pct_off"


def _date(v):
    for fmt in ("%Y-%m-%d", "%m/%d/%Y", "%d-%b-%Y", "%m/%d/%y"):
        try:
            return datetime.strptime(str(v).strip(), fmt).date().isoformat()
        except ValueError:
            pass
    return None


def _float(v, default=None):
    try:
        return float(str(v).replace("%", "").replace("$", "").strip())
    except (TypeError, ValueError):
        return default


class IntakeAgent(Agent):
    name = "intake-agent"

    def run(self, payload: dict) -> dict:
        store, raw = get_store(), payload.get("raw", payload)
        rows = raw.get("rows") if isinstance(raw, dict) and "rows" in raw else raw
        rows = rows if isinstance(rows, list) else [rows]
        promos, issues, decisions, mapping = [], [], [], {}
        for i, row in enumerate(rows):
            r = {}
            for k, v in (row or {}).items():
                canon = _ALIAS_LOOKUP.get(str(k).strip().lower())
                if canon:
                    r[canon] = v
                    mapping[k] = canon
            if "window" in (row or {}):                       # already-normalized promotion
                r.setdefault("start", row["window"].get("start")); r.setdefault("end", row["window"].get("end"))
            tag = f"row {i + 1}"
            def issue(sev, field, msg): issues.append({"severity": sev, "field": field, "message": f"{tag}: {msg}"})

            name = str(r.get("name") or "").strip() or f"Promotion {i + 1}"
            mech, warn = _mechanic(r.get("mechanic"))
            if warn: issue("warn", "mechanic", warn)
            depth = _float(r.get("depth_pct"), 50.0 if mech == "bogo" else None)
            if depth is None or not (0 < depth < 100):
                issue("error", "depth_pct", f"invalid or missing discount depth '{r.get('depth_pct')}'"); continue
            start, end = _date(r.get("start")), _date(r.get("end"))
            if not start or not end:
                issue("error", "dates", f"unparseable dates start='{r.get('start')}' end='{r.get('end')}'"); continue
            if end < start:
                issue("error", "dates", "end date is before start date"); continue

            toks = r.get("skus") or []
            toks = [t.strip() for t in re.split(r"[;|,]", toks) if t.strip()] if isinstance(toks, str) else list(toks)
            skus, bad = [], False
            for t in toks:
                c = store.lookup_products(t)
                if not c:
                    issue("error", "skus", f"could not resolve product '{t}'"); bad = True; continue
                top = c[0]
                if top["score"] < 0.85 or (len(c) > 1 and c[1]["score"] >= top["score"] - 0.05 and top["score"] < 1.0):
                    issue("warn", "skus", f"'{t}' matched {top['sku']} ({top['name']}); other candidates: "
                          + ", ".join(f"{x['sku']} {x['name']}" for x in c[1:]))
                    decisions.append({"decision": f"Resolved '{t}' -> {top['sku']}", "rationale": f"best fuzzy match score {top['score']}",
                                      "confidence": top["score"]})
                if top["sku"] not in skus: skus.append(top["sku"])
            if bad or not skus:
                if not skus: issue("error", "skus", "no valid products")
                continue

            region = str(r.get("region") or "NE").strip().upper() or "NE"
            if region != "NE":
                issue("warn", "region", f"region '{region}' has no data in the mock dataset; using NE"); region = "NE"
            stores = [s.strip() for s in re.split(r"[;|,]", str(r.get("stores") or "ALL")) if s.strip()] or ["ALL"]
            tg = str(r.get("targeting") or "all").lower()
            targeting = "loyalty" if "loyal" in tg else "lapsed" if "lapsed" in tg else "all"
            pid = r.get("promo_id") or "P-" + hashlib.sha1(f"{name}{start}{skus}".encode()).hexdigest()[:5].upper()
            cats = sorted({store.get_product_attributes(s)["category"] for s in skus})
            promos.append({"promo_id": str(pid), "name": name, "mechanic": mech, "depth_pct": depth, "skus": skus, "stores": stores,
                           "region": region, "start": start, "end": end, "window": {"start": start, "end": end},
                           "categories": cats, "funding_pct": _float(r.get("funding_pct"), 0.0) or 0.0, "targeting": targeting})
        errors = sum(1 for x in issues if x["severity"] == "error")
        return envelope(self.name, {"promotions": promos, "issues": issues, "column_mapping": mapping},
                        confidence=0.95 if not issues else 0.8 if not errors else 0.4,
                        assumptions=["Header aliases and SKU fuzzy matching are heuristic; review warnings before trusting results."],
                        evidence=[{"tool": "lookup_products", "ref": "catalog"}], decisions=decisions,
                        status="ok" if promos else "error")
