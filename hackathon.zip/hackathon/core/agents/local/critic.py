"""Risk critic: independent rule-based reviewer. Sees upstream OUTPUTS only (never the producing agent's reasoning)."""
from __future__ import annotations
from ..base import Agent, envelope
from .common import money, result

SEV = {"low": 1, "med": 2, "high": 3}


class CriticAgent(Agent):
    name = "risk-critic-agent"

    def run(self, payload: dict) -> dict:
        sim_env, bas_env, roi_env = payload["simulation"], payload["basket"], payload["roi"]
        sim, bas, roi = result(sim_env, "simulation"), result(bas_env, "basket"), result(roi_env, "roi")
        e = roi["expected"]
        risks, changes = [], []

        def add(t, sev, msg, ev, fix):
            risks.append({"type": t, "severity": sev, "explanation": msg, "evidence": ev}); changes.append(fix)

        # internal consistency (reject malformed analysis early)
        l = sim["lift_pct"]
        if not (l["low"] <= l["expected"] <= l["high"]):
            add("inconsistent_forecast", "high", "Lift range is not ordered low <= expected <= high.", ["simulate.lift_pct"], "Re-run the simulation")
        for env, nm in ((sim_env, "simulation"), (bas_env, "basket"), (roi_env, "roi")):
            if isinstance(env, dict) and "output" in env and (not env.get("assumptions") or not env.get("evidence")):
                add("missing_support", "med", f"{nm} output lacks assumptions or evidence.", [f"{nm}.assumptions"], f"Regenerate {nm} with citations")

        if e["net_margin_impact_cents"] <= 0:
            add("margin_erosion", "high", f"Expected net margin impact is {money(e['net_margin_impact_cents'])} (ROI {e['roi']:.0%}); "
                f"break-even lift is {roi['break_even_lift_pct']}% vs {l['expected']}% forecast"
                if roi["break_even_lift_pct"] is not None else
                f"Expected net margin impact is {money(e['net_margin_impact_cents'])}: discount exceeds unit margin, no lift can recover it.",
                ["roi.expected.net_margin_impact_cents"], "Cut depth below the unit-margin level or change mechanic/targeting")
        elif roi["headline"] == "fragile":
            add("fragile_roi", "med", "ROI turns negative in the low-lift scenario.", ["roi.scenarios.low"], "Reduce depth or narrow targeting to protect the downside")

        wp = e["wasted_discount_pct_of_cost"]
        if wp >= 55:
            add("budget_waste", "high" if wp >= 75 else "med", f"{wp:.0f}% of promotion cost is discount given to customers who would buy at full price "
                f"({sim['baseline_buyer_share']:.0%} baseline redemption).", ["simulate.baseline_buyer_share", "roi.expected.wasted_discount_cents"],
                "Use threshold or loyalty/lapsed targeting to limit discount leakage")

        cr = bas["cannibalization_rate"]
        if cr >= 0.25 or bas["high_risk_skus"]:
            add("cannibalization", "high" if cr >= 0.25 else "med", f"{cr:.0%} of incremental units come from substitutes"
                + (f"; high-margin victim(s): {', '.join(bas['high_risk_skus'])}" if bas["high_risk_skus"] else ""),
                ["basket.cannibalization_rate", "basket.high_risk_skus"], "Bundle with complements and/or lower depth to reduce switching from high-margin SKUs")

        inv = roi["inventory"]
        if inv["stockout_risk"] != "low":
            add("stockout", "high" if inv["stockout_risk"] == "high" else "med", f"Inventory covers {inv['weeks_cover_before']} weeks; high-lift demand may exceed stock.",
                ["roi.inventory"], "Cap promoted volume or shorten the window")
        if sim.get("elasticity_cross_check") and not sim["elasticity_cross_check"].get("agrees", True):
            add("forecast_disagreement", "med", f"Analog forecast differs from the elasticity cross-check ({sim['elasticity_cross_check']['implied_lift_pct']}% implied).",
                ["simulate.elasticity_cross_check"], "Treat the lift range as uncertain")
        conf = min(sim_env.get("confidence", .6), bas_env.get("confidence", .6), roi_env.get("confidence", .6))
        if conf < 0.5:
            add("low_confidence", "med", f"Overall confidence {conf:.2f} is below 0.5.", ["simulate.confidence"], "Gather more analog history before committing")
        sev = max((SEV[r["severity"]] for r in risks), default=0)
        verdict = "revise" if sev == 3 else "approve_with_changes" if sev == 2 else "approve"
        out = {"verdict": verdict, "risks": risks, "required_changes": changes, "overall_confidence": round(conf, 2),
               "strengths": ([f"Positive net margin {money(e['net_margin_impact_cents'])}"] if e["net_margin_impact_cents"] > 0 else [])
               + ([f"Overstock clearance benefit"] if inv["weeks_cover_before"] > 8 else [])}
        return envelope(self.name, out, conf, ["Rule-based thresholds: waste>=55%, cannibalization>=25%, net margin<=0."],
                        [{"tool": "inputs", "ref": "simulation,basket,roi"}],
                        [{"decision": f"Verdict: {verdict}", "rationale": "; ".join(f"{r['type']}({r['severity']})" for r in risks) or "no risks above threshold",
                          "confidence": conf}])
