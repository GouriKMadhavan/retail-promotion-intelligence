"""Basket intelligence: chooses substitute / complement sets from basket data and quantifies the net basket effect."""
from __future__ import annotations
from ..base import Agent, envelope
from ...calc.basket import basket_effect
from ...data_store import get_store
from .common import SCENARIOS, effective_depth, result

SUB_MATERIALITY, ATTACH_MATERIALITY = 0.04, 0.05


class BasketAgent(Agent):
    name = "basket-intelligence-agent"

    def run(self, payload: dict) -> dict:
        s, p = get_store(), payload["promotion"]
        sim = result(payload.get("simulation"), "simulation")
        by_sku, total_base = sim["baseline_by_sku"], max(1, sum(sim["baseline_by_sku"].values()))
        promoted, decisions, evidence = set(p["skus"]), [], []
        sub_rate, comp_rate, comp_aff, basis = {}, {}, {}, {}
        for sku in p["skus"]:
            share = by_sku.get(sku, 0) / total_base
            for x in s.get_substitutes(sku):
                evidence.append({"tool": "get_substitutes", "ref": sku})
                if x["sku"] in promoted:
                    continue
                sub_rate[x["sku"]] = sub_rate.get(x["sku"], 0) + share * x["switch_rate"]; basis[x["sku"]] = x["basis"]
            for x in s.get_basket_affinity(sku):
                evidence.append({"tool": "get_basket_affinity", "ref": sku})
                if x["sku"] in promoted:
                    continue
                comp_rate[x["sku"]] = comp_rate.get(x["sku"], 0) + share * x["attach_rate"]
                comp_aff[x["sku"]] = max(comp_aff.get(x["sku"], 0), x["affinity_lift"]); basis[x["sku"]] = x["basis"]

        excl = [k for k, v in sub_rate.items() if v < SUB_MATERIALITY]
        sub_rate = {k: v for k, v in sub_rate.items() if v >= SUB_MATERIALITY}
        tot = sum(sub_rate.values())
        if tot > 1:
            sub_rate = {k: v / tot for k, v in sub_rate.items()}
        comp_rate = {k: v for k, v in comp_rate.items() if v >= ATTACH_MATERIALITY and comp_aff[k] >= 1.2}
        decisions.append({"decision": f"Substitute set: {sorted(sub_rate) or 'none'}; complements: {sorted(comp_rate) or 'none'}",
                          "confidence": 0.75, "rationale": (f"Excluded immaterial substitutes {excl} (<{SUB_MATERIALITY:.0%} switch rate). " if excl else "")
                          + "Rates are observed basket switching / attach rates."})
        m = lambda sku: s.get_costs_and_margins(sku)["unit_margin_cents"]
        subs_in = [{"sku": k, "switch_rate": v, "unit_margin_cents": m(k)} for k, v in sub_rate.items()]
        comps_in = [{"sku": k, "attach_rate": v, "unit_margin_cents": m(k)} for k, v in comp_rate.items()]

        scen, res = {}, {}
        for n in SCENARIOS:
            r = basket_effect(sim["incremental_units"][n], subs_in, comps_in)
            res[n] = r
            scen[n] = {"margin_cents": r["net_basket_effect"]["margin_cents"], "cannibalized_margin_cents": r["cannibalized_margin_cents"],
                       "halo_margin_cents": r["halo_margin_cents"]}
        e = res["expected"]
        # a victim is high-risk if its full-price unit margin beats the promoted SKUs' discounted unit margin
        prom_margin = sum((s.products[k]["price_cents"] * (1 - effective_depth(p) / 100) - s.products[k]["unit_cost_cents"]) * by_sku.get(k, 0)
                          for k in p["skus"]) / total_base
        hr = [x["sku"] for x in e["substitutes"] if x["margin_lost_cents"] > 0 and m(x["sku"]) > prom_margin and sub_rate[x["sku"]] >= 0.06]
        for x in e["substitutes"]:
            x.update(basis=basis.get(x["sku"], "estimated"), why="same need, observed switching", switch_rate=round(sub_rate[x["sku"]], 3),
                     name=s.products[x["sku"]]["name"])
        for x in e["complements"]:
            x.update(basis=basis.get(x["sku"], "estimated"), why=f"affinity lift {comp_aff[x['sku']]}", attach_rate=round(comp_rate[x["sku"]], 3),
                     name=s.products[x["sku"]]["name"])
        bundles = [{"skus": [*p["skus"][:1], k], "affinity_lift": comp_aff[k], "rationale": f"{s.products[k]['name']} attaches at {comp_rate[k]:.0%}"}
                   for k in comp_rate if comp_aff[k] >= 2.5]
        out = {"substitutes": e["substitutes"], "complements": e["complements"], "cannibalization_rate": e["cannibalization_rate"],
               "net_basket_effect": e["net_basket_effect"], "scenarios": scen, "high_risk_skus": hr, "bundle_candidates": bundles}
        return envelope(self.name, out, 0.75 if all(v == "observed" for v in basis.values()) else 0.55,
                        ["Switch/attach rates are scaled by each promoted SKU's share of baseline volume.",
                         f"Materiality thresholds: substitutes {SUB_MATERIALITY:.0%}, complements {ATTACH_MATERIALITY:.0%}."],
                        evidence + [{"tool": "calc.basket", "ref": "basket_effect"}], decisions)
