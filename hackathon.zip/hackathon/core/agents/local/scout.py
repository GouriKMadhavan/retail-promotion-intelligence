"""Opportunity scout: intersects trend signals, inventory pressure and basket affinity to rank promotion opportunities."""
from __future__ import annotations
from ..base import Agent, envelope
from ...data_store import get_store, d, overlap_days
from .common import result

URG = {"high": 0.75, "med": 0.5}


class ScoutAgent(Agent):
    name = "opportunity-scout-agent"

    def run(self, payload: dict) -> dict:
        s = get_store()
        trend = result(payload["trend_report"], "trend_report")
        active = s.active_promotions()
        inv = {i["sku"]: i for i in s.get_inventory()}
        opps, skipped, decisions = [], [], []
        by_cat: dict[str, list[dict]] = {}
        for o in trend["emerging_opportunities"]:
            for c in o["categories"]:
                by_cat.setdefault(c, []).append(o)
        n = 0
        for cat, sigs in by_cat.items():
            skus = [k for k, p in s.products.items() if p["category"] == cat]
            over = sorted([k for k in skus if inv[k]["weeks_cover"] >= 8], key=lambda k: -inv[k]["weeks_cover"])
            targets = over[:3]
            if not targets:                                           # signal but no overstock: promote the volume leaders in the category
                targets = sorted(skus, key=lambda k: -inv[k]["on_hand_units"])[:2]
            sig = max(sigs, key=lambda o: len(o["trigger_signals"]))
            window = sig["window"]
            clash = [a for a in active if a["category"] == cat and overlap_days(d(a["start"]), d(a["end"]), d(window["start"]), d(window["end"]))]
            if clash:
                skipped.append({"category": cat, "reason": f"Active promotion {clash[0]['promo_id']} already covers this window"}); continue
            strength = min(1.0, 0.5 + 0.2 * len(sigs) + 0.1 * len(sig["trigger_signals"]))
            pressure = max(0.0, min(1.0, (max(inv[k]["weeks_cover"] for k in targets) - 6) / 8))
            fit = min(1.0, max((a["affinity_lift"] for k in targets for a in s.get_basket_affinity(k)), default=1.0) / 4)
            score = round(0.45 * strength + 0.35 * pressure + 0.20 * fit, 2)
            cover = max(inv[k]["weeks_cover"] for k in targets)
            n += 1
            why = f"{'; '.join(sig['trigger_signals'][:2])}." + (f" {cover:.1f} weeks of cover on {s.products[targets[0]]['name']}." if cover >= 8 else "")
            opps.append({"id": f"O-{n}", "title": sig["title"], "category": cat, "target_products": targets, "window": window,
                         "why_now": why, "trigger_signals": sig["trigger_signals"],
                         "urgency": "high" if (d(window["start"]) - s.as_of).days <= 21 or pressure > .6 else "med",
                         "opportunity_score": score, "inventory_weeks_cover": round(cover, 1),
                         "score_parts": {"signal": round(strength, 2), "inventory": round(pressure, 2), "basket_fit": round(fit, 2)}})
        opps.sort(key=lambda o: -o["opportunity_score"])
        for i, o in enumerate(opps):
            o["id"] = f"O-{i + 1}"
        decisions.append({"decision": f"Ranked {len(opps)} opportunities; top: {opps[0]['title'] if opps else 'none'}",
                          "rationale": "score = 0.45 signal strength + 0.35 inventory pressure + 0.20 basket fit", "confidence": 0.7})
        return envelope(self.name, {"opportunities": opps, "skipped": skipped}, 0.7,
                        ["Opportunity score weights are heuristic and tunable."],
                        [{"tool": "get_inventory", "ref": "all"}, {"tool": "get_basket_affinity", "ref": "targets"}], decisions)
