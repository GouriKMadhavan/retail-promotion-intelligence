"""Recommendation agent: designs 3 alternatives (reactive), turns opportunities into proposals (proactive), and ranks evaluated options.
It never scores its own proposals: evaluation always comes back from the orchestrator."""
from __future__ import annotations
from ..base import Agent, envelope
from ...data_store import get_store
from .common import effective_depth, money, result, shift, days


def _depth_cap(promo: dict) -> float:
    """Deepest discount that keeps promo unit margin comfortably positive (<= 60% of average margin %), rounded to 5."""
    s = get_store()
    m = sum((s.products[k]["price_cents"] - s.products[k]["unit_cost_cents"]) / s.products[k]["price_cents"] for k in promo["skus"]) / len(promo["skus"])
    return max(10.0, 5 * int(m * 100 * 0.6 / 5))


class RecommendationAgent(Agent):
    name = "recommendation-agent"

    def run(self, payload: dict) -> dict:
        mode = payload.get("mode", "reactive")
        return {"reactive": self._reactive, "proactive": self._proactive, "rank": self._rank}[mode](payload)

    # ---------------------------------------------------------------- reactive
    def _reactive(self, pl):
        p, risk = pl["promotion"], result(pl["risk_assessment"], "risk_assessment")
        bas = result(pl["basket"], "basket")
        kinds = {r["type"] for r in risk["risks"]}
        cap, depth = _depth_cap(p), effective_depth(p)
        safe = min(depth, cap)
        bundle = (bas.get("bundle_candidates") or [None])[0]
        short_end = shift(p["start"], min(days(p), 7) - 1)
        alts = [
            {"id": "A1", "label": "conservative", "title": f"Loyalty-only {safe:.0f}% spend threshold",
             "changes": {"mechanic": "threshold", "depth_pct": safe, "targeting": "loyalty"},
             "risks_addressed": sorted(kinds & {"budget_waste", "margin_erosion", "fragile_roi"}),
             "rationale": "Limits the discount to loyalty members above a spend threshold, so baseline buyers rarely redeem; depth is capped below the margin-safe level."},
            {"id": "A2", "label": "balanced",
             "title": "Bundle with complement" if bundle else f"Public {safe:.0f}% threshold offer",
             "changes": {"mechanic": "bundle" if bundle else "threshold", "depth_pct": safe, "targeting": "all",
                         **({"add_skus": [bundle["skus"][1]]} if bundle else {})},
             "risks_addressed": sorted(kinds & {"budget_waste", "cannibalization", "margin_erosion"}),
             "rationale": ("Pairs the promoted item with its strongest complement so incremental baskets carry extra margin, " if bundle else
                           "Spend threshold cuts casual redemption, ") + f"at a margin-safe {safe:.0f}% depth."},
            {"id": "A3", "label": "aggressive", "title": f"Short {min(safe + 5, depth):.0f}% flash sale",
             "changes": {"mechanic": "pct_off", "depth_pct": min(safe + 5, depth), "targeting": "all", "end": short_end},
             "risks_addressed": sorted(kinds & {"margin_erosion", "stockout", "fragile_roi"}),
             "rationale": "Keeps full reach for volume but shortens the window and trims depth to limit the total discount bill."},
        ]
        dec = [{"decision": f"Margin-safe depth cap {cap:.0f}%", "rationale": f"Keeps unit margin positive; original effective depth {depth:.0f}%", "confidence": 0.7},
               {"decision": "Designed 3 alternatives", "rationale": f"Mapped risks {sorted(kinds) or ['none']} to levers: mechanic, targeting, depth, scope, timing", "confidence": 0.7}]
        return envelope(self.name, {"mode": "reactive", "alternatives": alts}, 0.7,
                        ["Alternatives are designs only; numbers come from re-evaluation by the orchestrator."],
                        [{"tool": "get_costs_and_margins", "ref": ",".join(p["skus"])}], dec)

    # --------------------------------------------------------------- proactive
    def _proactive(self, pl):
        s, alts, dec = get_store(), [], []
        for o in pl["opportunities"]:
            o = o if "output" not in o else o["output"]
            inv = [s.get_inventory(k)["weeks_cover"] for k in o["target_products"]]
            cover = max(inv) if inv else 4
            depth = 25 if cover >= 10 else 20 if cover >= 8 else 15
            multi = len(o["target_products"]) > 1 and any(s.get_basket_affinity(k) for k in o["target_products"])
            alts.append({"id": o["id"], "label": "proposal", "title": o["title"], "opportunity_id": o["id"],
                         "changes": {"name": o["title"], "mechanic": "bundle" if multi else "pct_off", "depth_pct": depth, "skus": o["target_products"],
                                     "stores": ["ALL"], "region": "NE", "start": o["window"]["start"], "end": o["window"]["end"],
                                     "funding_pct": 0, "targeting": "all"},
                         "rationale": f"{o['why_now']} Depth {depth}% chosen from {cover:.1f} weeks of cover.",
                         "trigger_signals": o["trigger_signals"], "why_now": o["why_now"], "opportunity_score": o["opportunity_score"],
                         "urgency": o.get("urgency", "med")})
            dec.append({"decision": f"Proposal for {o['id']}: {depth}% {'bundle' if multi else 'off'}", "rationale": f"{cover:.1f} weeks cover; signals {o['trigger_signals'][:2]}", "confidence": 0.65})
        return envelope(self.name, {"mode": "proactive", "alternatives": alts}, 0.65,
                        ["Proposals are drafts; each is fully evaluated by the evaluate_promotion workflow before display."],
                        [{"tool": "get_inventory", "ref": "targets"}], dec)

    # -------------------------------------------------------------------- rank
    def _rank(self, pl):
        alts, orig = pl["alternatives"], pl.get("original")
        score = lambda a: a["evaluation"]["net_margin_impact_cents"] * max(0.3, a["evaluation"].get("confidence") or 0.6) \
            * (0.5 if a["evaluation"].get("verdict") == "revise" else 1.0)
        ranked = sorted(alts, key=score, reverse=True)
        ranking = [{"id": a["id"], "rank": i + 1, "score": round(score(a)), "net_margin_impact_cents": a["evaluation"]["net_margin_impact_cents"],
                    "reason": f"net {money(a['evaluation']['net_margin_impact_cents'])}, verdict {a['evaluation'].get('verdict')}"} for i, a in enumerate(ranked)]
        best = ranked[0] if ranked else None
        if orig is not None:
            orig_net = orig["net_margin_impact_cents"]
            if not best or (best["evaluation"]["net_margin_impact_cents"] <= max(orig_net, 0)):
                rec = "original" if orig_net > 0 else "defer"
            else:
                rec = best["id"]
        else:
            rec = best["id"] if best and best["evaluation"]["net_margin_impact_cents"] > 0 else "defer"
        why = {}
        for a in ranked:
            if a["id"] == rec:
                continue
            net = a["evaluation"]["net_margin_impact_cents"]
            why[a["id"]] = (f"Net {money(net)}" + (f" vs {money(best['evaluation']['net_margin_impact_cents'])} for {best['id']}" if a is not best else "")
                            + (", still negative" if net <= 0 else ""))
        if rec == "defer":
            why["defer"] = "No option produces positive net margin; recommend not running this promotion as designed."
        dec = [{"decision": f"Recommend {rec}", "rationale": "Ranked by net margin x confidence, penalising 'revise' verdicts"
                + (f"; original net {money(orig['net_margin_impact_cents'])}" if orig else ""), "confidence": 0.7}]
        return envelope(self.name, {"mode": "rank", "recommended_id": rec, "ranking": ranking, "why_not_others": why, "alternatives": []},
                        0.7, ["Quoted evaluation values verbatim; ranking by risk-adjusted net margin."],
                        [{"tool": "orchestrator.evaluation", "ref": ",".join(a["id"] for a in alts)}], dec)
