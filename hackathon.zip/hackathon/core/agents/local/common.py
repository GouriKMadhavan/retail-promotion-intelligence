"""Shared constants and helpers for the local (deterministic) agents.

The lever tables below are the local engine's stand-in for judgment a Claude agent would make from analogs; they are surfaced
as `assumptions` in every output so they stay visible and replaceable."""
from __future__ import annotations
from datetime import timedelta
from ...data_store import d

MECH_MULT = {"pct_off": 1.0, "bogo": 1.2, "multibuy": 1.1, "threshold": 0.85, "bundle": 0.95}   # lift vs. plain % off
REDEMPTION = {"pct_off": 0.90, "bogo": 0.95, "multibuy": 0.90, "threshold": 0.70, "bundle": 0.75}  # share of baseline units redeeming
TARGETING = {"all": (1.0, 1.0), "loyalty": (0.75, 0.40), "lapsed": (0.55, 0.15)}                  # (lift mult, redemption mult)
DEPTH_EXP = 1.1
SCENARIOS = ("low", "expected", "high")


def effective_depth(p: dict) -> float:
    return 50.0 if p["mechanic"] == "bogo" else float(p["depth_pct"])


def money(cents: float) -> str:
    sign = "-" if cents < 0 else ""
    return f"{sign}${abs(cents) / 100:,.0f}"


def days(p: dict) -> int:
    return (d(p["end"]) - d(p["start"])).days + 1


def shift(date_str: str, n: int) -> str:
    return (d(date_str) + timedelta(days=n)).isoformat()


def result(env: dict, key: str) -> dict:
    """Unwrap an upstream envelope (or accept a bare output dict)."""
    if env is None:
        raise ValueError(f"missing upstream input '{key}'")
    return env.get("output", env) if isinstance(env, dict) else env
