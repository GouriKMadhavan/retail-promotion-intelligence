"""ROI agent: runs core/calc/roi.py for low/expected/high and tells the financial story."""
from __future__ import annotations
from ..base import Agent, envelope
from ...calc.roi import promo_roi
from ...data_store import get_store
from .common import SCENARIOS, effective_depth, money, result


class RoiAgent(Agent):
    name = "roi-agent"

    def run(self, payload: dict) -> dict:
        s, p = get_store(), payload["promotion"]
        sim, basket = result(payload.get("simulation"), "simulation"), result(payload.get("basket"), "basket")
        by_sku, B = sim["baseline_by_sku"], max(1, sim["baseline_units"])
        price = sum(s.products[k]["price_cents"] * v for k, v in by_sku.items()) / B           # volume-weighted (exact: model is linear in p, c)
        cost = sum(s.products[k]["unit_cost_cents"] * v for k, v in by_sku.items()) / B
        depth, red = effective_depth(p), sim["baseline_buyer_share"]
        scen = {}
        for n in SCENARIOS:
            b = basket["scenarios"][n]
            scen[n] = promo_roi(B, sim["lift_pct"][n], price, cost, depth, p.get("funding_pct", 0),
                                b["cannibalized_margin_cents"], b["halo_margin_cents"], red)
        e = scen["expected"]
        be, lift = e["break_even_lift_pct"], sim["lift_pct"]["expected"]
        clears = be is not None and lift >= be
        headline = "loses_money" if e["net_margin_impact_cents"] <= 0 else "fragile" if scen["low"]["net_margin_impact_cents"] < 0 else "profitable"

        inv = [s.get_inventory(k) for k in p["skus"]]
        on_hand = sum(i["on_hand_units"] for i in inv)
        run = max(1, sim["weekly_run_rate"])
        need_hi = B + sim["incremental_units"]["high"]
        before, after = on_hand / run, on_hand / (run * (1 + lift / 100))
        risk = "high" if need_hi > on_hand else "med" if need_hi > 0.8 * on_hand else "low"
        note = ("Overstocked: promotion helps clear inventory." if before > 8 else
                "Stock-out risk in the high-lift case." if risk != "low" else "Inventory comfortably covers the promotion.")

        if headline == "loses_money":
            driver = ("the discount is deeper than the unit margin, so every promoted unit loses money" if depth / 100 * price - (price - cost) > 0 else
                      f"{e['wasted_discount_pct_of_cost']:.0f}% of the discount goes to customers who would buy anyway")
            summary = f"Loses {money(-e['net_margin_impact_cents'])} at expected lift: {driver}."
        else:
            summary = (f"Adds {money(e['net_margin_impact_cents'])} net margin (ROI {e['roi']:.0%}) at expected lift; "
                       f"break-even is {be}% lift vs {lift}% forecast."
                       + (" Fragile: negative in the low scenario." if headline == "fragile" else ""))
        out = {"headline": headline, "scenarios": scen, "expected": e, "break_even_lift_pct": be, "clears_break_even": clears,
               "inventory": {"on_hand_units": on_hand, "weeks_cover_before": round(before, 1), "weeks_cover_after": round(after, 1),
                             "stockout_risk": risk, "note": note},
               "financial_summary": summary, "price_cents_avg": round(price), "unit_cost_cents_avg": round(cost)}
        assumptions = [f"Discount applies to all in-scope units; baseline redemption {red:.0%}.", f"Vendor funding {p.get('funding_pct', 0):.0f}% of discount.",
                       "Break-even holds cannibalization/halo at the forecast value.",
                       *([f"BOGO treated as 50% effective depth."] if p["mechanic"] == "bogo" else [])]
        decisions = [{"decision": f"Headline: {headline}", "rationale": summary, "confidence": 0.75}]
        return envelope(self.name, out, 0.75, assumptions,
                        [{"tool": "get_costs_and_margins", "ref": ",".join(p["skus"])}, {"tool": "get_inventory", "ref": ",".join(p["skus"])},
                         {"tool": "calc.roi", "ref": "promo_roi"}], decisions)
