from .intake import IntakeAgent
from .trend import TrendAgent
from .simulator import SimulatorAgent
from .basket import BasketAgent
from .roi import RoiAgent
from .critic import CriticAgent
from .recommendation import RecommendationAgent
from .scout import ScoutAgent

LOCAL_AGENTS = {c.name: c for c in (IntakeAgent, TrendAgent, SimulatorAgent, BasketAgent, RoiAgent, CriticAgent,
                                     RecommendationAgent, ScoutAgent)}
