"""Trend agent: turns events / weather / trend indices into direction, strength and a demand-multiplier hint range."""
from __future__ import annotations
from datetime import timedelta
from ..base import Agent, envelope
from ...data_store import get_store, d

W = {"low": 0.02, "med": 0.04, "high": 0.07}      # strength -> multiplier weight


class TrendAgent(Agent):
    name = "trend-agent"

    def run(self, payload: dict) -> dict:
        s, mode = get_store(), payload.get("mode", "evaluate")
        win, region = payload["window"], payload.get("region", "NE")
        cats = payload.get("categories")
        cats = s.categories() if not cats or cats == "ALL" else list(cats)
        signals, evidence, gaps, assumptions, decisions = [], [], [], [], []

        s.notes.clear()
        wx = s.get_weather_forecast(win["start"], win["end"], region)
        evidence.append({"tool": "get_weather_forecast", "ref": f"{win['start']}..{win['end']}"})
        cold = wx.get("freezing_days", 0) >= 2
        if wx.get("days", 0) == 0:
            gaps.append("No weather forecast available for the window")
        elif cold:
            strength = "high" if wx["freezing_days"] >= 4 else "med"
            signals += [
                {"type": "weather", "name": f"Cold snap: {wx['freezing_days']} freezing days (min {wx['min_temp_c']}C)", "direction": "+",
                 "strength": strength, "affected_categories": ["Hot Beverages"], "rationale": "Cold weather lifts hot beverage demand"},
                {"type": "weather", "name": "Cold snap dampens cold drinks", "direction": "-", "strength": "low",
                 "affected_categories": ["Soft Drinks", "Water & Juice"], "rationale": "Cold weather suppresses cold beverage demand"}]

        for e in s.get_events(win["start"], win["end"], region):
            evidence.append({"tool": "get_events", "ref": e["event_id"]})
            if e["type"] == "weather" and cold:
                assumptions.append(f"Event '{e['name']}' is the same signal as the weather forecast; counted once.")
                continue
            signals.append({"type": "event", "name": e["name"], "direction": e["direction"], "strength": e["strength"],
                            "affected_categories": e["categories"], "rationale": f"{e['type']} event {e['start']}..{e['end']}"})

        trends = s.get_trends(); evidence.append({"tool": "get_trends", "ref": "category index"})
        for t in trends:
            i = t["trend_index"]
            if i >= 1.10 or i <= 0.92:
                signals.append({"type": "trend", "name": f"{t['category']} trend index {i}", "direction": "+" if i > 1 else "-",
                                "strength": "high" if abs(i - 1) >= .25 else "med" if abs(i - 1) >= .12 else "low",
                                "affected_categories": [t["category"]], "rationale": f"{t['change_30d_pct']:+.0f}% 30-day demand signal"})
        for c in cats:
            si = s.get_seasonality(c, win["start"], win["end"])
            evidence.append({"tool": "get_seasonality", "ref": c})
            if abs(si["window_index"] - 1) >= .1:
                signals.append({"type": "seasonality", "name": f"{c} seasonal index {si['window_index']}",
                                "direction": "+" if si["window_index"] > 1 else "-", "strength": "med",
                                "affected_categories": [c], "rationale": "Already embedded in the baseline forecast"})
        assumptions.append("Seasonality is already in the baseline units, so it is excluded from the demand hint to avoid double counting.")

        relevant = [x for x in signals if set(x["affected_categories"]) & set(cats) and x["type"] != "seasonality"]
        net = 0.0
        for x in relevant:
            w = W[x["strength"]] * (1 if x["direction"] == "+" else -1 if x["direction"] == "-" else 0)
            net += w * (0.5 if x["type"] == "trend" else 1.0)     # trend indices are partly in the baseline already
        net = max(-0.15, min(0.2, net))
        conf = 0.75 - 0.1 * len(gaps)
        half = 0.05 + 0.05 * (1 - conf)
        hint = {"low": round(max(0.7, 1 + net - half), 3), "high": round(1 + net + half, 3),
                "reasoning": (f"{len(relevant)} relevant signal(s) net {net:+.0%}; " if relevant else "No relevant signals; ")
                             + "band widened for uncertainty."}
        decisions.append({"decision": f"Demand hint {hint['low']}-{hint['high']}", "rationale": hint["reasoning"], "confidence": conf})

        conflicts = []
        for c in cats:
            pos = [x for x in relevant if c in x["affected_categories"] and x["direction"] == "+"]
            neg = [x for x in relevant if c in x["affected_categories"] and x["direction"] == "-"]
            if pos and neg:
                conflicts.append({"description": f"{c}: {pos[0]['name']} vs {neg[0]['name']}", "resolution": "Net effect used in hint"})
            peak = [x for x in pos if x["type"] == "event" and x["strength"] == "high"]
            if peak:
                conflicts.append({"description": f"{c}: promotion overlaps '{peak[0]['name']}', demand is already high",
                                  "resolution": "Promotion may be unnecessary; lift analogs from comparable peaks are used"})

        opps = []
        if mode == "scout":
            h0, h1 = d(win["start"]), d(win["end"])
            if cold:
                opps.append({"title": "Cold snap hot-beverage demand", "categories": ["Hot Beverages"],
                             "trigger_signals": [f"weather: {wx['freezing_days']} freezing days from {wx['cold_start']}",
                                                 *[x["name"] for x in signals if x["type"] == "trend" and "Hot Beverages" in x["affected_categories"]]],
                             "window": {"start": wx["cold_start"], "end": wx["cold_end"]}})
            for e in s.get_events(win["start"], win["end"], region):
                if e["type"] == "weather":
                    continue
                es = max(d(e["start"]), h0)
                opps.append({"title": f"{e['name']} demand", "categories": e["categories"], "trigger_signals": [f"event: {e['name']} ({e['strength']})"],
                             "window": {"start": (es - timedelta(days=3)).isoformat() if es - timedelta(days=3) > s.as_of else es.isoformat(),
                                        "end": d(e["end"]).isoformat()}})
            for t in trends:
                if t["trend_index"] >= 1.15 and not any(t["category"] in o["categories"] and "trend" in " ".join(o["trigger_signals"]) for o in opps):
                    opps.append({"title": f"{t['category']} trending up", "categories": [t["category"]],
                                 "trigger_signals": [f"trend: {t['category']} index {t['trend_index']} ({t['change_30d_pct']:+.0f}% 30d)"],
                                 "window": {"start": win["start"], "end": (d(win["start"]) + timedelta(days=13)).isoformat()}})
        gaps += s.notes
        out = {"signals": signals, "conflicts": conflicts, "demand_multiplier_hint": hint,
               "emerging_opportunities": opps, "data_gaps": gaps, "data_sources": dict(s.sources)}
        return envelope(self.name, out, conf, assumptions, evidence, decisions)
