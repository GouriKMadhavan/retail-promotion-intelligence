"""Promotion simulator: analog-based lift forecast. Chooses valid analogs (with reasons), delegates the math to core/calc/lift.py."""
from __future__ import annotations
from ..base import Agent, envelope
from ...calc.lift import forecast_lift
from ...data_store import get_store, d
from .common import MECH_MULT, REDEMPTION, TARGETING, DEPTH_EXP, effective_depth, result


class SimulatorAgent(Agent):
    name = "promotion-simulator-agent"

    def run(self, payload: dict) -> dict:
        s, p = get_store(), payload["promotion"]
        trend = result(payload.get("trend_report"), "trend_report")
        base = {sku: s.get_baseline_sales(sku, p["start"], p["end"], p.get("region", "NE")) for sku in p["skus"]}
        B = sum(b["baseline_units"] for b in base.values())
        if B <= 0:
            return envelope(self.name, {"error": "no baseline available"}, 0, status="error")
        cat = max(p["categories"], key=lambda c: sum(base[k]["baseline_units"] for k in p["skus"] if s.products[k]["category"] == c))
        depth, mech = effective_depth(p), p["mechanic"]
        target_events = {x["name"] for x in trend.get("signals", []) if x["type"] == "event"}
        hint = trend["demand_multiplier_hint"]

        used, rejected = [], []
        for a in s.find_comparable_promotions(cat):
            why = None
            if a["stockout"]: why = "stock-out depressed realised lift"
            elif a["event_overlap"] and a["event_overlap"].replace(" 2025", "") not in " ".join(target_events):
                why = f"ran during {a['event_overlap']}; target window has no comparable event, lift would be overstated"
            elif abs(a["depth_pct"] - depth) > 25: why = f"depth {a['depth_pct']:.0f}% too far from {depth:.0f}%"
            elif (s.as_of - d(a["start"])).days > 730: why = "older than 24 months"
            if why:
                rejected.append({"promo_id": a["promo_id"], "why": why}); continue
            gap = abs(a["depth_pct"] - depth)
            weight = round((1 / (1 + gap / 10)) * (1.0 if a["mechanic"] == mech else 0.7), 3)
            a_depth = 50.0 if a["mechanic"] == "bogo" else a["depth_pct"]
            norm = a["actual_lift_pct"] / MECH_MULT[a["mechanic"]] * (depth / a_depth) ** DEPTH_EXP    # -> equivalent plain %-off at target depth
            used.append({"promo_id": a["promo_id"], "weight": weight, "lift_pct": round(norm, 1), "raw_lift_pct": a["actual_lift_pct"],
                         "why": f"{a['mechanic']} {a['depth_pct']:.0f}% in {cat}" + (", same mechanic" if a["mechanic"] == mech else "")})
        used = sorted(used, key=lambda x: -x["weight"])[:8]
        if not used:
            return envelope(self.name, {"error": "no valid analogs after filtering"}, 0, status="error")

        f = forecast_lift([{"lift_pct": u["lift_pct"], "weight": u["weight"]} for u in used], hint["low"], hint["high"], B)
        lift_mult, red_mult = TARGETING[p.get("targeting", "all")]
        k = MECH_MULT[mech] * lift_mult
        lift = {n: round(f["lift_pct"][n] * k, 1) for n in ("low", "expected", "high")}
        inc = {n: round(B * lift[n] / 100) for n in lift}
        share = round(REDEMPTION[mech] * red_mult, 2)

        implied = s.get_price_elasticity(cat) * depth ** DEPTH_EXP * k
        agrees = abs(lift["expected"] - implied) / max(implied, 1e-9) < 0.4
        conf = 0.8 - 0.1 * max(0, 5 - len(used)) - (0.1 if not agrees else 0) - (0.05 * len(trend.get("conflicts", [])))
        assumptions = [f"Analogs normalised to plain %-off at target depth using lift ~ depth^{DEPTH_EXP}; mechanic multiplier {MECH_MULT[mech]}.",
                       f"Targeting '{p.get('targeting', 'all')}': lift x{lift_mult}, baseline redemption x{red_mult}.",
                       f"Baseline redemption for {mech} assumed {REDEMPTION[mech]:.0%} of would-buy-anyway units before targeting."]
        if len(used) < 3:
            conf = min(conf, 0.5); assumptions.append("thin analog history")
        decisions = [{"decision": f"Kept {len(used)} of {len(used) + len(rejected)} analogs", "confidence": round(conf, 2),
                      "rationale": "; ".join(f"{r['promo_id']}: {r['why']}" for r in rejected[:3]) or "no analogs rejected"},
                     {"decision": f"Baseline redemption {share:.0%}", "confidence": 0.7,
                      "rationale": f"{mech} mechanic with '{p.get('targeting', 'all')}' targeting"}]
        out = {"promo_id": p["promo_id"], "baseline_units": B, "lift_pct": lift, "incremental_units": inc,
               "baseline_buyer_share": share, "analogs_used": used, "analogs_rejected": rejected,
               "elasticity_cross_check": {"implied_lift_pct": round(implied, 1), "agrees": agrees},
               "baseline_by_sku": {k_: v["baseline_units"] for k_, v in base.items()},
               "weekly_run_rate": sum(v["weekly_run_rate"] for v in base.values()), "category": cat}
        return envelope(self.name, out, conf, assumptions,
                        [{"tool": "find_comparable_promotions", "ref": cat}, {"tool": "get_baseline_sales", "ref": ",".join(p["skus"])},
                         {"tool": "calc.lift", "ref": "forecast_lift"}, {"tool": "get_price_elasticity", "ref": cat}], decisions)
