"""LiteLLM backend: runs .claude/agents/<name>.md through a LiteLLM proxy (OpenAI-compatible /chat/completions).
Used by the deployed dashboard, where only a LiteLLM key is available (no Claude CLI, no Anthropic key).

Env: LITELLM_BASE_URL (e.g. https://litellm.example.com), LITELLM_API_KEY, optional LITELLM_MODEL (one alias for every tier)
or RPIP_MODEL_TOP / RPIP_MODEL_MID / RPIP_MODEL_FAST (see core/config.py), RPIP_LITELLM_TIMEOUT, RPIP_LITELLM_MAX_STEPS.

Tools: the `mcp__retail_data__*` / `mcp__signals__*` names in each agent's `tools:` frontmatter are exposed as function tools and executed
in-process against core.data_store (same functions the MCP servers wrap). Bash and anything else is not exposed.
If the proxy fails or returns invalid output, the agent falls back to its deterministic `local` implementation, status=degraded."""
from __future__ import annotations
import json, os, re
from pathlib import Path
import yaml
from .base import Agent, error_envelope
from .. import config

ROOT = Path(__file__).resolve().parent.parent.parent
TIMEOUT = int(os.getenv("RPIP_LITELLM_TIMEOUT", "120"))
MAX_STEPS = int(os.getenv("RPIP_LITELLM_MAX_STEPS", "8"))


def is_configured() -> bool:
    return bool(os.getenv("LITELLM_API_KEY") and os.getenv("LITELLM_BASE_URL"))


def _s(desc: str, **props) -> dict:
    """Tiny JSON-schema helper: props are name=(type, description[, required=True])."""
    required = [k for k, v in props.items() if len(v) < 3 or v[2]]
    return {"description": desc, "parameters": {"type": "object", "required": required, "additionalProperties": False,
            "properties": {k: {"type": v[0], "description": v[1]} for k, v in props.items()}}}


def _tools() -> dict:
    """tool name -> (function spec, callable). Built lazily so importing this module needs no data."""
    from ..data_store import get_store
    st = get_store
    win = dict(start=("string", "YYYY-MM-DD"), end=("string", "YYYY-MM-DD"))
    return {
        "lookup_products": (_s("Resolve a SKU or messy product name to catalog candidates.", text=("string", "name or SKU"), limit=("integer", "max results", False)),
                            lambda a: st().lookup_products(a["text"], a.get("limit", 3))),
        "get_product_attributes": (_s("Catalog attributes for one SKU.", sku=("string", "SKU")), lambda a: st().get_product_attributes(a["sku"])),
        "get_seasonality": (_s("Seasonal demand index for a category over a window.", category=("string", "category"), **win),
                            lambda a: st().get_seasonality(a["category"], a["start"], a["end"])),
        "get_baseline_sales": (_s("Expected non-promoted units for a SKU over a window.", sku=("string", "SKU"), region=("string", "region, default NE", False), **win),
                               lambda a: st().get_baseline_sales(a["sku"], a["start"], a["end"], a.get("region", "NE"))),
        "find_comparable_promotions": (_s("Past promotions in a category with actual lift, depth, mechanic, stockout flag.", category=("string", "category"),
                                          limit=("integer", "max rows", False), completed_only=("boolean", "default true", False)),
                                       lambda a: st().find_comparable_promotions(a["category"], a.get("limit", 12), a.get("completed_only", True))),
        "get_price_elasticity": (_s("Lift coefficient per unit of discount depth for a category.", category=("string", "category")),
                                 lambda a: {"category": a["category"], "lift_coefficient": st().get_price_elasticity(a["category"])}),
        "get_substitutes": (_s("SKUs shoppers switch to/from, with switch_rate.", sku=("string", "SKU")), lambda a: st().get_substitutes(a["sku"])),
        "get_basket_affinity": (_s("Complement SKUs bought together, with affinity_lift and attach_rate.", sku=("string", "SKU")),
                                lambda a: st().get_basket_affinity(a["sku"])),
        "get_inventory": (_s("On-hand units, weeks of cover, stock age for a SKU (all SKUs if empty).", sku=("string", "SKU or empty", False)),
                          lambda a: st().get_inventory(a.get("sku") or None)),
        "get_costs_and_margins": (_s("Price, unit cost and unit margin (cents) for a SKU.", sku=("string", "SKU")), lambda a: st().get_costs_and_margins(a["sku"])),
        "get_events": (_s("Events/holidays overlapping the window with affected categories.", region=("string", "region, default NE", False), **win),
                       lambda a: st().get_events(a["start"], a["end"], a.get("region", "NE"))),
        "get_weather_forecast": (_s("Weather summary for the window.", region=("string", "region, default NE", False), **win),
                                 lambda a: st().get_weather_forecast(a["start"], a["end"], a.get("region", "NE"))),
        "get_trends": (_s("Category trend index and 30-day change."), lambda a: st().get_trends()),
        **_calc_tools(),
    }


def _calc_tools() -> dict:
    """The deterministic calculators in core/calc (same ones the `calc` MCP server exposes). Agents never do arithmetic."""
    from ..calc.lift import forecast_lift
    from ..calc.basket import basket_effect
    from ..calc.roi import promo_roi

    def spec(desc: str, props: dict, required: list) -> dict:
        return {"description": desc, "parameters": {"type": "object", "properties": props, "required": required}}
    num, arr = {"type": "number"}, {"type": "array", "items": {"type": "object"}}
    return {
        "calc_lift": (spec("Lift forecast. analogs: [{lift_pct, weight}]; hint_low/high: demand multipliers.",
                           {"analogs": arr, "baseline_units": num, "hint_low": num, "hint_high": num}, ["analogs", "baseline_units"]),
                      lambda a: forecast_lift(a["analogs"], a.get("hint_low", 1.0), a.get("hint_high", 1.0), a["baseline_units"])),
        "calc_basket": (spec("Basket effect for ONE incremental_units value. substitutes: [{sku, switch_rate, unit_margin_cents}] "
                             "complements: [{sku, attach_rate, unit_margin_cents}]",
                             {"incremental_units": num, "substitutes": arr, "complements": arr, "promoted_unit_margin_cents": num},
                             ["incremental_units", "substitutes", "complements"]),
                        lambda a: basket_effect(a["incremental_units"], a["substitutes"], a["complements"], a.get("promoted_unit_margin_cents", 0))),
        "calc_roi": (spec("ROI, net margin, wasted discount, break-even lift. Cents are integers; percentages 0-100; redemption 0-1.",
                          {k: num for k in ("baseline_units", "lift_pct", "price_cents", "unit_cost_cents", "depth_pct", "funding_pct",
                                            "cannibalized_margin_cents", "halo_margin_cents", "baseline_redemption")},
                          ["baseline_units", "lift_pct", "price_cents", "unit_cost_cents", "depth_pct"]),
                     lambda a: promo_roi(**a)),
    }


def _load(name: str) -> tuple[dict, str]:
    text = (ROOT / ".claude" / "agents" / f"{name}.md").read_text(encoding="utf-8")
    m = re.match(r"^---\r?\n(.*?)\r?\n---\r?\n(.*)$", text, re.S)
    if not m:
        raise ValueError(f"{name}: missing frontmatter")
    return yaml.safe_load(m.group(1)), m.group(2).strip()


def _extract_json(text: str) -> dict:
    text = text.strip()
    fence = re.search(r"```(?:json)?\s*(\{.*\})\s*```", text, re.S)
    return json.loads(fence.group(1) if fence else text[text.index("{"): text.rindex("}") + 1])


def _model_for(meta: dict) -> str:
    override = os.getenv("LITELLM_MODEL")
    return override or config.TIERS[config.ALIAS.get(meta.get("model", "sonnet"), "mid")]


def _chat(model: str, messages: list, tools: list) -> dict:
    import requests  # installed with streamlit; kept lazy so tests/local backend need nothing extra
    body = {"model": model, "messages": messages, "max_tokens": config.MAX_TOKENS, "temperature": 0}
    if tools:
        body["tools"] = tools
    r = requests.post(os.environ["LITELLM_BASE_URL"].rstrip("/") + "/chat/completions",
                      headers={"Authorization": f"Bearer {os.environ['LITELLM_API_KEY']}"}, json=body, timeout=TIMEOUT)
    r.raise_for_status()
    return r.json()["choices"][0]["message"]


def run_agent(name: str, payload: dict) -> dict:
    meta, system = _load(name)
    registry = _tools()
    allowed = [t.strip().split("__")[-1] for t in str(meta.get("tools", "")).split(",") if t.strip().startswith("mcp__")]  # incl. mcp__calc__*
    specs = [{"type": "function", "function": {"name": n, **registry[n][0]}} for n in allowed if n in registry]
    model = _model_for(meta)
    messages = [{"role": "system", "content": system},
                {"role": "user", "content": json.dumps(payload, ensure_ascii=False, default=str) + "\n\nReturn ONLY the final JSON envelope."}]
    last_err, repaired = None, False
    for _ in range(MAX_STEPS):
        msg = _chat(model, messages, specs)
        calls = msg.get("tool_calls") or []
        if calls:
            messages.append({"role": "assistant", "content": msg.get("content"), "tool_calls": calls})
            for c in calls:
                fn = c["function"]["name"]
                try:
                    if fn not in allowed or fn not in registry:
                        raise ValueError(f"tool '{fn}' not allowed for {name}")
                    result = registry[fn][1](json.loads(c["function"].get("arguments") or "{}"))
                    content = json.dumps(result, default=str, ensure_ascii=False)
                except Exception as e:  # report to the model so it can adapt
                    content = json.dumps({"error": str(e)})
                messages.append({"role": "tool", "tool_call_id": c["id"], "content": content})
            continue
        text = msg.get("content") or ""
        try:
            out = _extract_json(text)
            if "output" not in out:           # bare payload without the envelope: wrap it
                out = {"output": out}
            out.setdefault("agent", name); out.setdefault("status", "ok"); out.setdefault("confidence", 0.5)
            out.setdefault("assumptions", []); out.setdefault("evidence", [])
            return out
        except Exception as e:
            last_err = e
            if repaired:
                break
            repaired = True
            messages += [{"role": "assistant", "content": text},
                         {"role": "user", "content": f"Invalid output: {e}. Return only the corrected JSON envelope."}]
    raise RuntimeError(f"no valid JSON envelope after {MAX_STEPS} steps: {last_err}")


class LiteLLMAgent(Agent):
    backend = "litellm"

    def __init__(self, name: str):
        self.name = name

    def run(self, payload: dict) -> dict:
        if not is_configured():
            return self._fallback(payload, "LITELLM_BASE_URL / LITELLM_API_KEY not set")
        try:
            return run_agent(self.name, payload)
        except Exception as e:
            return self._fallback(payload, f"litellm call failed: {e}")

    def _fallback(self, payload: dict, reason: str) -> dict:
        from .local import LOCAL_AGENTS  # lazy: avoids import cycle with registry
        if self.name not in LOCAL_AGENTS:
            return error_envelope(self.name, reason)
        try:
            out = LOCAL_AGENTS[self.name]().run(payload)
        except Exception as e:
            return error_envelope(self.name, f"{reason}; local fallback also failed: {e}")
        out["status"] = "degraded" if out.get("status") == "ok" else out.get("status", "degraded")
        out.setdefault("assumptions", []).append(f"Fell back to local deterministic agent: {reason[:200]}")
        out["confidence"] = round(min(out.get("confidence", 0.5), 0.6), 2)
        return out
