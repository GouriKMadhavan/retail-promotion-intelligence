"""Claude Code backend: runs .claude/agents/<name>.md through headless Claude Code (`claude -p`). No API key needed; uses the
logged-in Claude Code session. Data tools come from the MCP servers in mcp_servers/.
Select with RPIP_BACKEND=claude-code (or RPIP_BACKEND_<AGENT>=claude-code). Slower than local: one `claude` process per agent.

Speed/safety notes:
- Each call writes its own temp files (system prompt, MCP config), so parallel agents never read each other's files.
- Only the MCP servers an agent's `tools:` allowlist names are started (the risk critic starts none).
- An invalid-JSON reply is fixed by resuming the same session, so the agent does not redo its tool calls."""
from __future__ import annotations
import json, os, re, shutil, subprocess, sys, tempfile, threading
from pathlib import Path
import yaml
from .base import Agent, error_envelope
from .. import progress
from ..contracts import OUTPUT_MODELS

ROOT = Path(__file__).resolve().parent.parent.parent
TIMEOUT = int(os.getenv("RPIP_CLAUDE_CODE_TIMEOUT", "240"))
MODELS = {"opus": "opus", "sonnet": "sonnet", "haiku": "haiku"}
SERVERS = ("retail_data", "signals", "calc")   # mcp_servers/<name>_server.py


def _load(name: str) -> tuple[dict, str]:
    text = (ROOT / ".claude" / "agents" / f"{name}.md").read_text(encoding="utf-8")
    m = re.match(r"^---\r?\n(.*?)\r?\n---\r?\n(.*)$", text, re.S)
    if not m:
        raise ValueError(f"{name}: missing frontmatter")
    return yaml.safe_load(m.group(1)), m.group(2).strip()


def _tmp_file(prefix: str, suffix: str, content: str) -> str:
    """Unique temp file per call (parallel agents must not share one)."""
    fd, path = tempfile.mkstemp(prefix=prefix, suffix=suffix)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(content)
    return path


def _mcp_config(tools: list[str]) -> str:
    """MCP config with absolute paths, limited to the servers the agent's allowlist uses. Returns the file path."""
    needed = [s for s in SERVERS if any(t.startswith(f"mcp__{s}__") for t in tools)]
    cfg = {"mcpServers": {n: {"command": sys.executable, "args": [str(ROOT / "mcp_servers" / f"{n}_server.py")]}
                          for n in needed}}
    return _tmp_file("rpip_mcp_", ".json", json.dumps(cfg))


def _extract_json(text: str) -> dict:
    text = text.strip()
    fence = re.search(r"```(?:json)?\s*(\{.*\})\s*```", text, re.S)
    return json.loads(fence.group(1) if fence else text[text.index("{"): text.rindex("}") + 1])


FRIENDLY = {"get_events": "checking the events calendar", "get_weather_forecast": "reading the weather forecast",
            "get_trends": "reading category trends", "get_seasonality": "checking seasonality",
            "lookup_products": "matching products", "get_inventory": "checking inventory",
            "get_basket_affinity": "looking at basket affinity", "get_substitutes": "finding substitute products",
            "get_baseline_sales": "reading baseline sales", "find_comparable_promotions": "finding comparable past promotions",
            "get_price_elasticity": "checking price elasticity", "get_costs_and_margins": "reading costs and margins",
            "get_product_attributes": "reading product details"}


def _run_stream(cmd: list[str], prompt: str, agent: str) -> tuple[int, str, str, str | None]:
    """Run claude with stream-json, report tool calls to the UI as they happen.
    Returns (returncode, final_text, raw_tail, session_id)."""
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                            encoding="utf-8", cwd=tempfile.gettempdir())
    timer = threading.Timer(TIMEOUT, proc.kill)
    timer.start()
    final, raw, texts, session = "", [], [], None
    try:
        proc.stdin.write(prompt); proc.stdin.close()
        progress.notify(agent, "started")
        for line in proc.stdout:
            raw.append(line)
            try:
                ev = json.loads(line)
            except ValueError:
                continue
            session = ev.get("session_id") or session
            if ev.get("type") == "assistant":
                for b in ev.get("message", {}).get("content", []):
                    if b.get("type") == "tool_use":
                        progress.notify(agent, FRIENDLY.get(b["name"].split("__")[-1], b["name"].split("__")[-1].replace("_", " ")))
                    elif b.get("type") == "text" and b.get("text", "").strip():
                        texts.append(b["text"]); progress.notify(agent, "writing its assessment")
            elif ev.get("type") == "result":
                final = ev.get("result") or ""
        proc.wait()
    finally:
        timer.cancel()
        if proc.poll() is None:
            proc.kill()
    return proc.returncode, final or " ".join(texts), "".join(raw)[-400:], session


class ClaudeCodeAgent(Agent):
    backend = "claude-code"

    def __init__(self, name: str):
        self.name = name

    def run(self, payload: dict) -> dict:
        exe = shutil.which("claude")
        if not exe:
            return error_envelope(self.name, "claude CLI not found on PATH")
        try:
            meta, system = _load(self.name)
        except Exception as e:
            return error_envelope(self.name, f"cannot load agent file: {e}")
        # Only MCP data tools are allowed; Bash/Agent/etc. are not (calc is done by the pipeline, not the model).
        tools = [t.strip() for t in str(meta.get("tools", "")).split(",") if t.strip().startswith("mcp__")]
        temps: list[str] = []
        try:
            # prompt goes via a file: multi-line args get mangled by the Windows npm `claude.cmd` shim
            sp = _tmp_file(f"rpip_sys_{self.name}_", ".md", system); temps.append(sp)
            mcp = _mcp_config(tools); temps.append(mcp)
            base = [exe, "-p", "--output-format", "stream-json", "--verbose", "--system-prompt-file", sp, "--tools", "",
                    "--model", MODELS.get(meta.get("model", "sonnet"), "sonnet"),
                    "--mcp-config", mcp, "--strict-mcp-config",
                    "--permission-mode", "dontAsk"]
            if tools:
                base += ["--allowedTools", ",".join(tools)]
            payload_text = json.dumps(payload, ensure_ascii=False)
            prompt = payload_text + "\n\nReturn ONLY the final JSON envelope."
            cmd, session, last = base, None, None
            for _ in range(2):  # one retry on invalid JSON
                rc, text, tail, sid = _run_stream(cmd, prompt, self.name)
                session = sid or session
                if rc != 0 and not text:
                    return error_envelope(self.name, f"claude exited {rc} (timeout is {TIMEOUT}s): {tail[:300]}")
                try:
                    out = _extract_json(text)
                    if "output" not in out:      # model returned the bare payload without the envelope: wrap it
                        out = {"output": out}
                    model = OUTPUT_MODELS.get(self.name)
                    inner = out.get("output")
                    if model and isinstance(inner, dict) and set(inner) == {model.__name__}:
                        out["output"] = inner[model.__name__]   # model nested its output under the contract class name
                    out.setdefault("agent", self.name)
                    out.setdefault("status", "ok")
                    out.setdefault("confidence", 0.5)
                    out.setdefault("assumptions", [])
                    out.setdefault("evidence", [])
                    return out
                except Exception as e:
                    last = e
                    fix = f"Your previous reply was invalid ({e}). Return only the corrected JSON envelope."
                    if session:   # keep the tool results already gathered; only ask for the corrected reply
                        cmd, prompt = base + ["--resume", session], fix
                    else:         # no session to resume: start over with the original request
                        cmd, prompt = base, payload_text + "\n\nReturn ONLY the final JSON envelope.\n\n" + fix
            return error_envelope(self.name, f"invalid JSON from claude: {last}")
        finally:
            for p in temps:
                try:
                    os.remove(p)
                except OSError:
                    pass
