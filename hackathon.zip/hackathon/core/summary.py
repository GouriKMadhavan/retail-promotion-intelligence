"""Compact evaluation summary used for ranking, tables and the opportunity feed."""
from __future__ import annotations


def summarize(bundle: dict) -> dict:
    g = lambda *path: _get(bundle, path)
    e = g("roi", "output", "expected") or {}
    return {
        "net_margin_impact_cents": e.get("net_margin_impact_cents", 0),
        "roi": e.get("roi"),
        "lift_pct": g("simulate", "output", "lift_pct", "expected"),
        "cannibalization_rate": g("basket", "output", "cannibalization_rate"),
        "headline": g("roi", "output", "headline"),
        "verdict": g("critic", "output", "verdict"),
        "risks": [r["type"] for r in (g("critic", "output", "risks") or [])],
        "confidence": g("critic", "output", "overall_confidence"),
        "wasted_discount_pct_of_cost": e.get("wasted_discount_pct_of_cost"),
    }


def _get(obj, path):
    for k in path:
        obj = obj.get(k) if isinstance(obj, dict) else None
        if obj is None:
            return None
    return obj
