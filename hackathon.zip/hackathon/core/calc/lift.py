"""Deterministic lift forecast from weighted analog promotions + a context hint. CLI + library."""
from __future__ import annotations
import argparse, json, math


def forecast_lift(analogs: list[dict], hint_low: float, hint_high: float, baseline_units: float) -> dict:
    """analogs: [{lift_pct, weight}]. hint_*: demand multipliers from trend-agent (1.0 = neutral)."""
    if not analogs:
        raise ValueError("at least one analog required")
    if hint_low > hint_high:
        raise ValueError("hint_low must be <= hint_high")
    tw = sum(a["weight"] for a in analogs)
    if tw <= 0:
        raise ValueError("analog weights must sum > 0")
    mean = sum(a["lift_pct"] * a["weight"] for a in analogs) / tw
    var = sum(a["weight"] * (a["lift_pct"] - mean) ** 2 for a in analogs) / tw
    sd = math.sqrt(var)
    mid = (hint_low + hint_high) / 2
    low = max(0.0, (mean - sd) * hint_low)
    exp = max(low, mean * mid)
    high = max(exp, (mean + sd) * hint_high)
    units = lambda l: round(baseline_units * l / 100)
    return {
        "lift_pct": {"low": round(low, 1), "expected": round(exp, 1), "high": round(high, 1)},
        "incremental_units": {"low": units(low), "expected": units(exp), "high": units(high)},
        "analog_count": len(analogs),
    }


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--analogs", required=True, help="JSON list of {lift_pct, weight}")
    p.add_argument("--hint-low", type=float, default=1.0)
    p.add_argument("--hint-high", type=float, default=1.0)
    p.add_argument("--baseline-units", type=float, required=True)
    a = p.parse_args()
    print(json.dumps(forecast_lift(json.loads(a.analogs), a.hint_low, a.hint_high, a.baseline_units)))
