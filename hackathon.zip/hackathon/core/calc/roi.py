"""Deterministic promotion economics. Money in integer cents; percentages 0-100.

Model, per unit-weighted aggregate (linear in price and cost, so averaged price/cost is exact):
  B  baseline units in window (would sell at full price p, unit margin m = p-c)
  I  incremental units = B * L
  r  baseline redemption: share of B that buys on-promo (discount leakage). Public promo ~0.9, threshold ~0.7, targeted far less.
  d  depth, disc = p*d, promo unit margin m_d = p*(1-d)-c, vendor funding f of the discount, g = m_d + f*disc
  net      = I*g - r*B*disc*(1-f) - cannibalized + halo
  cost     = disc*(1-f)*(r*B + I)            wasted = disc*(1-f)*r*B  (discount paid on units that would sell anyway)
  break-even lift: L* = (r*disc*(1-f) + (cannibalized-halo)/B) / g   (None if g <= 0: no lift can pay back the discount)
"""
from __future__ import annotations
import argparse, json


def promo_roi(baseline_units: float, lift_pct: float, price_cents: float, unit_cost_cents: float,
              depth_pct: float, funding_pct: float = 0, cannibalized_margin_cents: float = 0,
              halo_margin_cents: float = 0, baseline_redemption: float = 1.0) -> dict:
    B, L, p, c, r = baseline_units, lift_pct / 100, price_cents, unit_cost_cents, baseline_redemption
    d, f = depth_pct / 100, funding_pct / 100
    if not (0 <= d < 1 and 0 <= f <= 1 and 0 <= r <= 1):
        raise ValueError("depth must be in [0,100), funding in [0,100], redemption in [0,1]")
    I = B * L
    disc = p * d
    m_d = p * (1 - d) - c
    g = m_d + f * disc
    wasted = disc * (1 - f) * r * B
    cost = disc * (1 - f) * (r * B + I)
    inc_margin = I * g
    net = inc_margin - wasted - cannibalized_margin_cents + halo_margin_cents
    be = None if g <= 0 or B <= 0 else (r * disc * (1 - f) + (cannibalized_margin_cents - halo_margin_cents) / B) / g * 100
    return {
        "promo_cost_cents": round(cost),
        "incremental_margin_cents": round(inc_margin),
        "wasted_discount_cents": round(wasted),
        "wasted_discount_pct_of_cost": round(100 * wasted / cost, 1) if cost else 0.0,
        "cannibalized_margin_cents": round(cannibalized_margin_cents),
        "halo_margin_cents": round(halo_margin_cents),
        "net_margin_impact_cents": round(net),
        "roi": round(net / cost, 3) if cost else None,
        "break_even_lift_pct": None if be is None else round(max(be, 0), 1),
    }


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    for k in ("baseline-units", "lift-pct", "price-cents", "unit-cost-cents", "depth-pct"):
        p.add_argument(f"--{k}", type=float, required=True)
    for k in ("funding-pct", "cannibalized-margin-cents", "halo-margin-cents"):
        p.add_argument(f"--{k}", type=float, default=0.0)
    p.add_argument("--baseline-redemption", type=float, default=1.0)
    print(json.dumps(promo_roi(**{k.replace("-", "_"): v for k, v in vars(p.parse_args()).items()})))
