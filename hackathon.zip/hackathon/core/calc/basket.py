"""Deterministic basket effect: cannibalization of substitutes, halo on complements."""
from __future__ import annotations
import argparse, json


def basket_effect(incremental_units: float, substitutes: list[dict], complements: list[dict],
                  promoted_unit_margin_cents: float = 0) -> dict:
    """substitutes: [{sku, switch_rate, unit_margin_cents}]  complements: [{sku, attach_rate, unit_margin_cents}]"""
    if sum(s["switch_rate"] for s in substitutes) > 1.0 + 1e-9:
        raise ValueError("switch rates must sum to <= 1")
    subs, comps = [], []
    for s in substitutes:
        lost = incremental_units * s["switch_rate"]
        subs.append({"sku": s["sku"], "units_lost": round(lost),
                     "margin_lost_cents": round(lost * s["unit_margin_cents"])})
    for c in complements:
        gained = incremental_units * c["attach_rate"]
        comps.append({"sku": c["sku"], "units_gained": round(gained),
                      "margin_gained_cents": round(gained * c["unit_margin_cents"])})
    lost_u = sum(s["units_lost"] for s in subs)
    gained_u = sum(c["units_gained"] for c in comps)
    lost_m = sum(s["margin_lost_cents"] for s in subs)
    gained_m = sum(c["margin_gained_cents"] for c in comps)
    return {
        "substitutes": subs, "complements": comps,
        "cannibalization_rate": round(lost_u / incremental_units, 3) if incremental_units else 0.0,
        "net_basket_effect": {"units": round(incremental_units - lost_u + gained_u),
                              "margin_cents": round(gained_m - lost_m)},
        "cannibalized_margin_cents": lost_m, "halo_margin_cents": gained_m,
    }


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--incremental", type=float, required=True)
    p.add_argument("--substitutes", default="[]")
    p.add_argument("--complements", default="[]")
    a = p.parse_args()
    print(json.dumps(basket_effect(a.incremental, json.loads(a.substitutes), json.loads(a.complements))))
