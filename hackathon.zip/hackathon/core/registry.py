"""Agent registry: picks the backend per agent.

  RPIP_BACKEND=local|claude                 default for all agents (default: local)
  RPIP_BACKEND_TREND_AGENT=claude           per-agent override (agent name upper-cased, '-' -> '_')

To replace an agent: add a class implementing core.agents.base.Agent and register it in BACKENDS. Nothing else changes."""
from __future__ import annotations
import os
from .agents.base import Agent
from .agents.claude_backend import ClaudeAgent
from .agents.claude_code_backend import ClaudeCodeAgent
from .agents.litellm_backend import LiteLLMAgent, is_configured as litellm_configured
from .agents.local import LOCAL_AGENTS

BACKENDS = {
    "local": lambda name: LOCAL_AGENTS[name](),
    "litellm": lambda name: LiteLLMAgent(name),          # LiteLLM proxy: LITELLM_BASE_URL + LITELLM_API_KEY (deployed dashboard)
    "claude": lambda name: ClaudeAgent(name),
    "claude-code": lambda name: ClaudeCodeAgent(name),   # headless `claude -p`, no API key
}


def backend_for(name: str) -> str:
    """Per-agent env > RPIP_BACKEND > `litellm` when LITELLM_* env is set > `local`."""
    return (os.getenv("RPIP_BACKEND_" + name.upper().replace("-", "_")) or os.getenv("RPIP_BACKEND")
            or ("litellm" if litellm_configured() else "local"))


def get_agent(name: str) -> Agent:
    b = backend_for(name)
    if b not in BACKENDS:
        raise ValueError(f"unknown backend '{b}' for {name}; options: {list(BACKENDS)}")
    if b == "local" and name not in LOCAL_AGENTS:
        raise KeyError(f"no local implementation for '{name}'")
    return BACKENDS[b](name)


def call(name: str, payload: dict) -> dict:
    """Convenience: run a single agent outside a workflow (e.g. intake preview on the upload page)."""
    return get_agent(name).run(payload)
