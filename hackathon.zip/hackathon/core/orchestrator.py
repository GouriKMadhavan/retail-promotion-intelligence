"""Agent orchestration layer: runs YAML workflow DAGs against any agent backend (see core/registry.py).

  python -m core.orchestrator evaluate samples/promo_01.json
  python -m core.orchestrator recommend samples/scan.json

Features: dependency-ordered steps, parallel execution of independent steps, `when` conditions, `foreach` sub-workflows,
post hooks (alternative re-evaluation + ranking), contract validation on every hop, retry-then-degrade, decision log, trace, persistence.
`on_event` is only ever called from the calling thread (safe for Streamlit)."""
from __future__ import annotations
import copy, json, os, re, sys, time, uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, timezone
from pathlib import Path
import yaml
from . import config
from .agents.base import error_envelope
from .contracts import validate_envelope
from .data_store import get_store
from .registry import get_agent, backend_for
from .summary import summarize

ROOT = Path(__file__).resolve().parent.parent
RUNS_DIR = ROOT / "data" / "runs"
_TOK = re.compile(r"([A-Za-z_][\w-]*)|\[(-?\d*)(:)?(-?\d*)\]")


# ------------------------------------------------------------------ path resolution
def _get(path: str, ctx):
    cur = ctx
    for key, a, colon, b in _TOK.findall(path[2:]):
        if key:
            cur = cur.get(key) if isinstance(cur, dict) else None
        elif colon:
            cur = cur[int(a or 0): int(b) if b else None] if isinstance(cur, list) else None
        else:
            i = int(a) if a else 0
            cur = cur[i] if isinstance(cur, list) and -len(cur) <= i < len(cur) else None
        if cur is None:
            return None
    return cur


def _resolve(val, ctx):
    if isinstance(val, dict):
        return {k: _resolve(v, ctx) for k, v in val.items()}
    if isinstance(val, list):
        return [_resolve(v, ctx) for v in val]
    if isinstance(val, str) and val.startswith("$."):
        return _get(val, ctx)
    return val


def _should_run(step: dict, ctx: dict) -> bool:
    if step.get("requires_input") and not ctx.get(step["requires_input"]):   # opt-in step: only when the caller asked for it
        return False
    w = step.get("when")
    return True if not w else _get("$." + w["step"] + "." + w["path"], ctx) in w["in"]


def load_workflow(name: str) -> dict:
    return yaml.safe_load((ROOT / config.WORKFLOWS_DIR / f"{name}.yaml").read_text(encoding="utf-8"))


# ------------------------------------------------------------------ single agent step
def _run_step(step: dict, payload: dict, wf: dict) -> dict:
    agent = get_agent(step["agent"])
    retries = wf.get("failure_policy", {}).get("retry", 1)
    t0, res, errs = time.time(), None, []
    for _ in range(retries + 1):
        try:
            res = agent.run(payload)
            errs = validate_envelope(step["agent"], res)
            if not errs and res.get("status") != "error":
                break
        except Exception as e:                                 # agent crashed: retry, then degrade
            res, errs = error_envelope(step["agent"], f"{type(e).__name__}: {e}"), []
    if errs:
        res["status"] = "degraded" if res.get("status") == "ok" else res.get("status", "error")
        res["contract_errors"] = errs
    res["_meta"] = {"backend": agent.backend, "ms": round((time.time() - t0) * 1000), "agent": step["agent"]}
    return res


# ------------------------------------------------------------------ workflow runner
def run_workflow(name: str, inputs: dict, disable=(), on_event=None, persist: bool = False, _top: bool = True) -> dict:
    emit = on_event or (lambda e: None)
    wf, run_id = load_workflow(name), uuid.uuid4().hex[:8]
    ctx: dict = {**inputs, "run_id": run_id, "workflow": name, "decision_log": [], "trace": [], "started": datetime.now(timezone.utc).isoformat(),
                 "all_categories": sorted({p["category"] for p in get_store().products.values()}),  # real list for "ALL" scans
                 "product_catalog": [{"sku": s, "name": p["name"], "category": p["category"]} for s, p in get_store().products.items()]}
    if "horizon_days" in inputs:
        as_of = get_store().as_of
        ctx["horizon"] = {"start": as_of.isoformat(), "end": (as_of + timedelta(days=int(inputs["horizon_days"]))).isoformat()}
    steps = [s for s in wf["steps"] if s["id"] not in set(disable)]
    ids, done = {s["id"] for s in steps}, set()
    pending = list(steps)
    while pending:
        pend_ids = {s["id"] for s in pending}
        ready = [s for s in pending if all(n in done or n not in pend_ids for n in s.get("needs", []))]
        if not ready:
            raise RuntimeError(f"unsatisfiable dependencies in workflow {name}")
        for s in ready:
            pending.remove(s)
        runnable = [s for s in ready if _should_run(s, ctx)]
        for s in ready:
            if s not in runnable:
                emit({"run_id": run_id, "step": s["id"], "status": "skipped"})
        with ThreadPoolExecutor(max_workers=6) as ex:
            futs = {}
            for s in runnable:
                emit({"run_id": run_id, "step": s["id"], "status": "started", "agent": s.get("agent") or s.get("workflow")})
                payload = _resolve(s.get("input", {}), ctx)
                if "agent" in s:
                    futs[ex.submit(_run_step, s, payload, wf)] = s
                else:
                    futs[ex.submit(_run_foreach, s, ctx, inputs)] = s
            for f in as_completed(futs):
                s = futs[f]
                res = f.result()
                if "agent" in s:
                    ctx["trace"].append({"step": s["id"], **res["_meta"], "status": res["status"]})
                    for dcs in res.get("decisions", []):
                        ctx["decision_log"].append({"run_id": run_id, "step": s["id"], "agent": s["agent"], **dcs})
                ctx[s["id"]] = res
                emit({"run_id": run_id, "step": s["id"], "status": res["status"] if isinstance(res, dict) else "ok"})
        done |= {s["id"] for s in ready}
        for s in runnable:                                      # post hooks run in the calling thread
            if s.get("post") and s["id"] in ctx:
                ctx[s["id"]] = HOOKS[s["post"]](wf, ctx, emit, name)
    ctx["finished"] = datetime.now(timezone.utc).isoformat()
    if persist and _top and os.getenv("RPIP_PERSIST", "1") == "1":
        _persist(ctx)
    return ctx


def _run_foreach(step: dict, ctx: dict, top_inputs: dict) -> list:
    items = _resolve(step["foreach"], ctx) or []
    def one(item):
        sub_in = _resolve(step.get("input", {}), {**ctx, "item": item})
        b = run_workflow(step["workflow"], sub_in, disable=step.get("disable_steps", ()), _top=False)
        return {**item, "evaluation": summarize(b), "bundle": b}
    with ThreadPoolExecutor(max_workers=4) as ex:
        return list(ex.map(one, items))


# ------------------------------------------------------------------ hooks
def apply_patch(promotion: dict, changes: dict) -> dict:
    p = copy.deepcopy(promotion)
    for k, v in changes.items():
        if k in ("add_skus", "exclude_skus") or v in (None, ""):
            continue
        p[k] = v
    p["skus"] = [s for s in p.get("skus", []) + changes.get("add_skus", []) if s not in changes.get("exclude_skus", [])]
    p.pop("window", None); p.pop("categories", None)            # force intake to recompute derived fields
    return p


def evaluate_alternatives_then_rank(wf: dict, ctx: dict, emit, wf_name: str) -> dict:
    rec = ctx["recommend"]
    base = ctx["intake"]["output"]["promotions"][0]
    alts = rec["output"].get("alternatives", [])[:3]
    emit({"run_id": ctx["run_id"], "step": "re-evaluate", "status": "started", "agent": f"{len(alts)} alternatives"})
    def ev(alt):
        b = run_workflow(wf_name, {"promotion": apply_patch(base, alt["changes"])}, disable={"recommend"}, _top=False)
        return {**alt, "evaluation": summarize(b), "bundle": b}
    with ThreadPoolExecutor(max_workers=3) as ex:
        evaluated = list(ex.map(ev, alts))
    step = {"agent": "recommendation-agent"}
    ranked = _run_step(step, {"mode": "rank", "alternatives": evaluated, "original": summarize(ctx)}, wf)
    ctx["trace"].append({"step": "rank", **ranked["_meta"], "status": ranked["status"]})
    for dcs in ranked.get("decisions", []):
        ctx["decision_log"].append({"run_id": ctx["run_id"], "step": "rank", "agent": "recommendation-agent", **dcs})
    ranked["output"]["alternatives"] = evaluated
    ranked["output"]["mode"] = "rank"
    emit({"run_id": ctx["run_id"], "step": "re-evaluate", "status": "ok"})
    return ranked


HOOKS = {"evaluate_alternatives_then_rank": evaluate_alternatives_then_rank}


# ------------------------------------------------------------------ persistence
def _persist(ctx: dict) -> None:
    RUNS_DIR.mkdir(parents=True, exist_ok=True)
    (RUNS_DIR / f"{ctx['run_id']}.json").write_text(json.dumps(ctx, indent=1, default=str), encoding="utf-8")
    with open(RUNS_DIR / "decision_log.jsonl", "a", encoding="utf-8") as f:
        for row in ctx["decision_log"]:
            f.write(json.dumps(row, default=str) + "\n")


def backends_in_use() -> dict[str, str]:
    from .contracts import OUTPUT_MODELS
    return {n: backend_for(n) for n in OUTPUT_MODELS}


if __name__ == "__main__":
    cmd, path = sys.argv[1], sys.argv[2]
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    wf, inp = ("evaluate_promotion", {"promotion": data}) if cmd == "evaluate" else ("recommend_promotions", data)
    out = run_workflow(wf, inp, on_event=lambda e: print(f"[{e['step']}] {e['status']}", file=sys.stderr), persist=True)
    print(json.dumps(out, indent=2, default=str))
