"""Read-only data access layer. Every public method mirrors an MCP tool name from ARCHITECTURE.md section 7
(retail_data + signals servers), so local agents and future Claude agents see the same interface.
Stdlib only. Swap the CSV backing for DuckDB/an API without touching agents."""
from __future__ import annotations
import csv, difflib
from datetime import date, datetime, timedelta
from functools import lru_cache
from pathlib import Path
from . import live_signals as live

CSV_DIR = Path(__file__).resolve().parent.parent / "data" / "csv"
MOCK_AS_OF = date(2026, 11, 17)  # mock world date; sales/inventory CSVs are anchored here (data/generate.py)
AS_OF = MOCK_AS_OF if not live.enabled() else date.today()


def d(s: str) -> date:
    return datetime.strptime(s[:10], "%Y-%m-%d").date()


def overlap_days(a0: date, a1: date, b0: date, b1: date) -> int:
    return max(0, (min(a1, b1) - max(a0, b0)).days + 1)


class DataStore:
    def __init__(self, csv_dir: Path = CSV_DIR):
        if not (csv_dir / "products.csv").exists():
            raise FileNotFoundError(f"Dataset missing in {csv_dir}. Run: python -m data.generate")
        self.dir = csv_dir
        self.as_of = AS_OF
        self.sources: dict[str, str] = {}      # signal -> 'live' | 'cache' | 'cache-stale' | 'mock' | 'mock-fallback'
        self.notes: list[str] = []
        self.products = {r["sku"]: {**r, "price_cents": int(r["price_cents"]), "unit_cost_cents": int(r["unit_cost_cents"])}
                         for r in self._rows("products.csv")}

    def _rows(self, name):
        with open(self.dir / name, newline="", encoding="utf-8") as f:
            return list(csv.DictReader(f))

    # ---------------- catalog ----------------
    def categories(self) -> list[str]:
        return sorted({p["category"] for p in self.products.values()})

    def get_product_attributes(self, sku: str) -> dict | None:
        return self.products.get(sku)

    def lookup_products(self, text: str, limit: int = 3) -> list[dict]:
        """Resolve a SKU or messy product name. Returns candidates best-first with a score."""
        t = text.strip().lower()
        if t.upper() in self.products:
            return [{**self.products[t.upper()], "score": 1.0}]
        scored = []
        for p in self.products.values():
            name = p["name"].lower()
            s = difflib.SequenceMatcher(None, t, name).ratio()
            if t in name or name in t or all(w in name for w in t.split()):
                s = max(s, 0.9)
            scored.append((s, p))
        scored.sort(key=lambda x: -x[0])
        return [{**p, "score": round(s, 2)} for s, p in scored[:limit] if s >= 0.55]

    # ---------------- sales / baseline ----------------
    @lru_cache(maxsize=None)
    def _sales(self) -> dict:
        out: dict[str, list[tuple[date, int]]] = {}
        for r in self._rows("sales_weekly.csv"):
            out.setdefault(r["sku"], []).append((d(r["week_start"]), int(r["units"])))
        return out

    @lru_cache(maxsize=None)
    def _season(self) -> dict:
        return {r["category"]: [float(r[f"m{i}"]) for i in range(1, 13)] for r in self._rows("seasonality.csv")}

    def get_seasonality(self, category: str, start: str, end: str) -> dict:
        idx = self._season().get(category, [1.0] * 12)
        s0, s1 = d(start), d(end)
        days = (s1 - s0).days + 1
        avg = sum(idx[(s0 + timedelta(days=i)).month - 1] for i in range(days)) / days
        return {"category": category, "window_index": round(avg, 3), "peak_month_index": max(idx)}

    def get_baseline_sales(self, sku: str, start: str, end: str, region: str = "NE") -> dict:
        """Expected no-promo units for the window: de-seasonalised recent run-rate x window seasonality."""
        rows = self._sales().get(sku, [])
        if not rows:
            return {"sku": sku, "baseline_units": 0, "weekly_run_rate": 0}
        cat = self.products[sku]["category"]
        idx = self._season().get(cat, [1.0] * 12)
        recent = rows[-26:]
        run = sum(u / idx[wk.month - 1] for wk, u in recent) / len(recent)
        s0, s1 = d(start), d(end)
        days = (s1 - s0).days + 1
        seas = sum(idx[(s0 + timedelta(days=i)).month - 1] for i in range(days)) / days
        return {"sku": sku, "baseline_units": round(run * seas * days / 7), "weekly_run_rate": round(run),
                "seasonality_index": round(seas, 3), "days": days}

    # ---------------- promotions history ----------------
    @lru_cache(maxsize=None)
    def _promos(self) -> list[dict]:
        out = []
        for r in self._rows("promotions_history.csv"):
            out.append({**r, "depth_pct": float(r["depth_pct"]), "actual_lift_pct": float(r["actual_lift_pct"]),
                        "skus": r["skus"].split(";"), "stockout": r["stockout"] == "1", "duration_days": int(r["duration_days"])})
        return out

    def find_comparable_promotions(self, category: str, limit: int = 12, completed_only: bool = True) -> list[dict]:
        rows = [p for p in self._promos() if p["category"] == category and (p["status"] == "completed" or not completed_only)]
        return rows[:limit * 3]

    def active_promotions(self) -> list[dict]:
        return [p for p in self._promos() if p["status"] == "active"]

    def get_price_elasticity(self, category: str) -> float:
        for r in self._rows("elasticity.csv"):
            if r["category"] == category:
                return float(r["lift_coefficient"])
        return 1.5

    # ---------------- basket ----------------
    def get_substitutes(self, sku: str) -> list[dict]:
        return [{"sku": r["substitute_sku"], "switch_rate": float(r["switch_rate"]), "basis": r["basis"]}
                for r in self._rows("substitutes.csv") if r["sku"] == sku]

    def get_basket_affinity(self, sku: str) -> list[dict]:
        return [{"sku": r["complement_sku"], "affinity_lift": float(r["affinity_lift"]),
                 "attach_rate": float(r["attach_rate"]), "basis": r["basis"]}
                for r in self._rows("affinity.csv") if r["sku"] == sku]

    # ---------------- inventory / finance ----------------
    @lru_cache(maxsize=None)
    def _inv(self) -> dict:
        return {r["sku"]: {"sku": r["sku"], "on_hand_units": int(r["on_hand_units"]), "weeks_cover": float(r["weeks_cover"]),
                           "age_days": int(r["age_days"])} for r in self._rows("inventory.csv")}

    def get_inventory(self, sku: str | None = None):
        return self._inv().get(sku) if sku else list(self._inv().values())

    def get_costs_and_margins(self, sku: str) -> dict:
        p = self.products[sku]
        return {"sku": sku, "price_cents": p["price_cents"], "unit_cost_cents": p["unit_cost_cents"],
                "unit_margin_cents": p["price_cents"] - p["unit_cost_cents"],
                "margin_pct": round(100 * (p["price_cents"] - p["unit_cost_cents"]) / p["price_cents"], 1)}

    # ---------------- signals (mock trend data) ----------------
    def _mock_events(self, region):
        return [{**r, "categories": r["categories"].split(";")} for r in self._rows("events.csv") if r["region"] == region]

    def get_events(self, start: str, end: str, region: str = "NE") -> list[dict]:
        s0, s1 = d(start), d(end)
        rows = None
        if live.enabled():
            try:
                rows, src = live.events(sorted({s0.year, s1.year}), region)
                self.sources["events"] = src
            except live.LiveUnavailable as e:
                self.notes.append(f"events fell back to mock data ({e})")
        if rows is None:
            rows, self.sources["events"] = self._mock_events(region), "mock-fallback" if live.enabled() else "mock"
        return [r for r in rows if overlap_days(s0, s1, d(r["start"]), d(r["end"]))]

    def get_weather_forecast(self, start: str, end: str, region: str = "NE") -> dict:
        s0, s1 = d(start), d(end)
        rows = None
        if live.enabled():
            try:
                rows, src = live.weather_daily(region)
                self.sources["weather"] = src
            except live.LiveUnavailable as e:
                self.notes.append(f"weather fell back to mock data ({e})")
        if rows is None:
            rows = [{"date": r["date"], "temp_c": float(r["temp_c"])} for r in self._rows("weather_forecast.csv") if r["region"] == region]
            self.sources["weather"] = "mock-fallback" if live.enabled() else "mock"
        rows = [r for r in rows if s0 <= d(r["date"]) <= s1 and r["temp_c"] is not None]
        if not rows:
            return {"days": 0, "source": self.sources["weather"]}
        temps = [float(r["temp_c"]) for r in rows]
        cold = [r["date"] for r in rows if float(r["temp_c"]) <= 0]
        return {"days": len(rows), "avg_temp_c": round(sum(temps) / len(temps), 1), "min_temp_c": min(temps),
                "freezing_days": len(cold), "cold_start": cold[0] if cold else None, "cold_end": cold[-1] if cold else None,
                "source": self.sources["weather"], "coverage_note": "forecast covers at most 16 days ahead" if live.enabled() else "mock"}

    def get_trends(self) -> list[dict]:
        mock = [{"category": r["category"], "trend_index": float(r["trend_index"]), "change_30d_pct": float(r["change_30d_pct"]),
                 "source": r["source"]} for r in self._rows("trends.csv")]
        if live.enabled():
            if live.insecure_tls():
                self.notes.append("TLS verification is DISABLED for Google Trends (RPIP_INSECURE_TLS=1). Testing only; unset before submission.")
            try:
                rows, src = live.trends()
                have = {r["category"] for r in rows}
                self.sources["trends"] = src
                return rows + [m for m in mock if m["category"] not in have]
            except Exception as e:                                   # pytrends missing, rate-limited, offline...
                self.notes.append(f"trends fell back to mock data ({str(e)[:160]})")
        self.sources["trends"] = "mock-fallback" if live.enabled() else "mock"
        return mock


_store: DataStore | None = None


def get_store() -> DataStore:
    global _store
    if _store is None:
        _store = DataStore()
    return _store
