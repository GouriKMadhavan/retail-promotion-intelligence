"""Live external signals (no API keys): Open-Meteo weather, Nager.Date holidays (+ derived retail events), Google Trends (optional).

Every fetch is cached on disk (data/cache/) and raises LiveUnavailable on failure; DataStore then falls back to the stale cache and
finally to the mock CSVs. Each call reports its source so the dashboard can show 'live' vs 'mock'.
TLS: verifies certificates; if SSL_CERT_FILE / NODE_EXTRA_CA_CERTS is set (corporate proxy CA) it is added to the trust store."""
from __future__ import annotations
import json, os, ssl, time, urllib.parse, urllib.request
from datetime import date, timedelta
from pathlib import Path

CACHE_DIR = Path(__file__).resolve().parent.parent / "data" / "cache"
TTL = {"weather": 3600, "holidays": 86400, "trends": 6 * 3600}
REGIONS = {"NE": {"lat": 42.36, "lon": -71.06, "label": "Boston, MA"}}   # extend with more regions as data grows

# Which categories each real holiday moves (only holidays that matter to grocery promotions are kept)
HOLIDAY_IMPACT = {
    "Thanksgiving Day": (["Baking", "Snacks"], "high"), "Christmas Day": (["Baking", "Hot Beverages"], "high"),
    "New Year's Day": (["Snacks", "Soft Drinks"], "med"), "Independence Day": (["Soft Drinks", "Snacks", "Water & Juice"], "high"),
    "Memorial Day": (["Soft Drinks", "Snacks", "Water & Juice"], "med"), "Labour Day": (["Soft Drinks", "Snacks"], "med"),
    "Labor Day": (["Soft Drinks", "Snacks"], "med"), "Martin Luther King, Jr. Day": ([], "low"),
}
TREND_KEYWORDS = {"Hot Beverages": "hot chocolate", "Snacks": "potato chips", "Soft Drinks": "soda",
                  "Baking": "baking recipes", "Water & Juice": "orange juice"}


class LiveUnavailable(Exception):
    pass


def enabled() -> bool:
    return os.getenv("RPIP_SIGNALS", "live").lower() == "live"


def _ctx() -> ssl.SSLContext:
    ctx = ssl.create_default_context()
    ca = os.getenv("SSL_CERT_FILE") or os.getenv("NODE_EXTRA_CA_CERTS")
    if ca and Path(ca).exists():
        ctx.load_verify_locations(ca)
    return ctx


def insecure_tls() -> bool:
    """TESTING ONLY. RPIP_INSECURE_TLS=1 disables certificate verification for the Google Trends call (pytrends) and nothing else."""
    return os.getenv("RPIP_INSECURE_TLS", "0") == "1"


def ca_bundle() -> str | bool:
    """Trust bundle for `requests`-based libraries (pytrends): public CAs (certifi) + the corporate proxy CA, if configured.
    Certificate verification is never disabled. Returns True (requests default) when no extra CA is configured."""
    extra = os.getenv("REQUESTS_CA_BUNDLE") or os.getenv("SSL_CERT_FILE") or os.getenv("NODE_EXTRA_CA_CERTS")
    if not extra or not Path(extra).exists():
        return True
    try:
        import certifi
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        out = CACHE_DIR / "ca_bundle.pem"
        public = Path(certifi.where()).read_text(encoding="utf-8")
        corporate = Path(extra).read_text(encoding="utf-8")
        out.write_text(public + chr(10) + corporate, encoding="utf-8")
        return str(out)
    except Exception:
        return extra


def _cached(key: str, ttl: int, fetch):
    """Return (data, source) where source is 'live' | 'cache' | 'cache-stale'. Raises LiveUnavailable if nothing usable."""
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    path = CACHE_DIR / f"{key}.json"
    cached = json.loads(path.read_text(encoding="utf-8")) if path.exists() else None
    if cached and time.time() - cached["at"] < ttl:
        return cached["data"], "cache"
    try:
        data = fetch()
        path.write_text(json.dumps({"at": time.time(), "data": data}), encoding="utf-8")
        return data, "live"
    except Exception as e:
        if cached:
            return cached["data"], "cache-stale"
        raise LiveUnavailable(f"{key}: {type(e).__name__}: {e}") from e


def _get_json(url: str):
    with urllib.request.urlopen(url, timeout=8, context=_ctx()) as r:
        return json.loads(r.read())


# ---------------------------------------------------------------- weather
def weather_daily(region: str) -> tuple[list[dict], str]:
    """Daily mean temp / precip for the next 16 days -> [{date, temp_c, precip_mm}]."""
    geo = REGIONS.get(region)
    if not geo:
        raise LiveUnavailable(f"no coordinates for region {region}")
    def fetch():
        q = urllib.parse.urlencode({"latitude": geo["lat"], "longitude": geo["lon"], "forecast_days": 16, "timezone": "auto",
                                    "daily": "temperature_2m_mean,precipitation_sum"})
        j = _get_json(f"https://api.open-meteo.com/v1/forecast?{q}")["daily"]
        return [{"date": t, "temp_c": m, "precip_mm": p} for t, m, p in zip(j["time"], j["temperature_2m_mean"], j["precipitation_sum"])]
    return _cached(f"weather_{region}", TTL["weather"], fetch)


# ---------------------------------------------------------------- holidays and retail events
def _nth_weekday(year: int, month: int, weekday: int, n: int) -> date:
    d = date(year, month, 1)
    d += timedelta(days=(weekday - d.weekday()) % 7 + 7 * (n - 1))
    return d


def events(years: list[int], region: str) -> tuple[list[dict], str]:
    rows, srcs = [], []
    for y in years:
        hol, src = _cached(f"holidays_US_{y}", TTL["holidays"], lambda y=y: _get_json(f"https://date.nager.at/api/v3/PublicHolidays/{y}/US"))
        srcs.append(src)
        for h in hol:
            cats, strength = HOLIDAY_IMPACT.get(h["name"], (None, None))
            if not cats:
                continue
            rows.append({"event_id": f"H-{h['date']}", "name": h["name"], "type": "holiday", "start": h["date"], "end": h["date"],
                         "region": region, "categories": cats, "direction": "+", "strength": strength})
        tg = _nth_weekday(y, 11, 3, 4)                            # Thanksgiving = 4th Thursday of November
        rows.append({"event_id": f"R-BF-{y}", "name": "Black Friday weekend", "type": "retail", "start": (tg + timedelta(1)).isoformat(),
                     "end": (tg + timedelta(4)).isoformat(), "region": region, "categories": ["Snacks", "Soft Drinks"], "direction": "+", "strength": "high"})
        sb = _nth_weekday(y, 2, 6, 2)                              # Super Bowl ~ 2nd Sunday of February
        rows.append({"event_id": f"R-SB-{y}", "name": "Super Bowl weekend (approx.)", "type": "sports", "start": (sb - timedelta(2)).isoformat(),
                     "end": sb.isoformat(), "region": region, "categories": ["Snacks", "Soft Drinks"], "direction": "+", "strength": "high"})
    return rows, ("live" if "live" in srcs else "cache" if all(s == "cache" for s in srcs) else "cache-stale")


# ---------------------------------------------------------------- trends (optional, unofficial API)
def trends() -> tuple[list[dict], str]:
    """Google Trends interest per category. A failing/rate-limited category is skipped; only total failure raises."""
    def fetch():
        from pytrends.request import TrendReq          # optional dependency
        verify = False if insecure_tls() else ca_bundle()      # False only when explicitly opted in (testing)
        py = TrendReq(hl="en-US", tz=300, timeout=(5, 12), requests_args={"verify": verify})
        out, errors = [], []
        for cat, kw in TREND_KEYWORDS.items():
            try:
                py.build_payload([kw], timeframe="today 3-m", geo="US")
                df = py.interest_over_time()
                if df.empty or kw not in df:
                    raise RuntimeError("empty result")
                s = df[kw].astype(float)
                recent, prior = s.tail(2).mean(), s.iloc[-8:-2].mean()
                idx = round(max(0.6, min(1.6, recent / prior if prior else 1.0)), 2)
                out.append({"category": cat, "trend_index": idx, "change_30d_pct": round((idx - 1) * 100, 1),
                            "source": f"google trends: '{kw}'"})
            except Exception as e:
                errors.append(f"{cat}: {type(e).__name__}: {str(e)[:80]}")
            time.sleep(2.0)                              # be gentle: Google rate-limits aggressively (HTTP 429)
        if not out:
            raise RuntimeError("; ".join(errors) or "no trend data returned")
        return out
    return _cached("trends", TTL["trends"], fetch)


def self_check() -> None:
    """python -m core.live_signals : fetch every live signal and report source, status and the real error if any."""
    ok = True
    if insecure_tls():
        print("WARNING: RPIP_INSECURE_TLS=1 - certificate verification is DISABLED for Google Trends (testing only)\n")
    for name, call in (("weather", lambda: weather_daily("NE")),
                       ("holidays/events", lambda: events([date.today().year, date.today().year + 1], "NE")),
                       ("trends (pytrends)", trends)):
        try:
            data, src = call()
            print(f"[OK]   {name:18} source={src:12} rows={len(data)}")
            if name.startswith("trends"):
                for r in data:
                    print(f"         {r['category']:14} index={r['trend_index']:<5} {r['source']}")
        except Exception as e:
            ok = False
            print(f"[FAIL] {name:18} {e}")
    print()
    print("All live signals working." if ok else "Some signals fell back to mock data (see errors above).")


if __name__ == "__main__":
    self_check()
