"""Tiny progress channel so agent backends can report sub-step detail ("reading weather data") to the UI.
The page registers a hook with set_hook(); backends call notify(). Hook calls are made only on the registering thread
(Streamlit requirement); events from worker threads are buffered and delivered by drain()."""
from __future__ import annotations
import threading

_hook = None
_owner = None
_ctx = None
_call_lock = threading.RLock()
_buf: list[dict] = []
_lock = threading.Lock()


def set_hook(fn, ctx=None) -> None:
    """ctx: Streamlit ScriptRunContext (get_script_run_ctx()). With it, worker threads may update the page directly."""
    global _hook, _owner, _ctx
    _hook, _owner, _ctx = fn, threading.get_ident(), ctx


def clear_hook() -> None:
    global _hook, _owner, _ctx
    _hook = _owner = _ctx = None
    with _lock:
        _buf.clear()


def notify(agent: str, detail: str) -> None:
    if _hook is None:
        return
    ev = {"step": "detail", "agent": agent, "status": "working", "detail": detail}
    if threading.get_ident() == _owner or _ctx is not None:
        try:
            if threading.get_ident() != _owner:
                from streamlit.runtime.scriptrunner import add_script_run_ctx
                add_script_run_ctx(threading.current_thread(), _ctx)
            with _call_lock:
                _hook(ev)
        except Exception:
            pass
    else:
        with _lock:
            _buf.append(ev)


def drain() -> list[dict]:
    with _lock:
        out, _buf[:] = list(_buf), []
    return out
