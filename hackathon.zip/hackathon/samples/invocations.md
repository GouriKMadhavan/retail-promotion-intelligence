# Sample invocations

## A. Run-time (what the dashboard calls)

```bash
# Evaluate one promotion end-to-end (writes EvaluationBundle JSON to stdout)
python -m core.orchestrator evaluate samples/promo_01.json

# Proactive opportunity feed (input = region/horizon)
echo '{"horizon_days":30,"region":"NE","top_n":3}' > samples/scan.json
python -m core.orchestrator recommend samples/scan.json
```

From Streamlit (`app/pages/1_Promotion_Upload.py`):
```python
from core.orchestrator import run_workflow
bundle = run_workflow("evaluate_promotion", {"promotion": row}, on_event=lambda e: status.write(e))
```

## B. Build-time (Claude Code, in this repo)

Single agent, to test one prompt in isolation:
```
> Use the promotion-simulator-agent on this input and show me only the JSON:
  {"promotion": <contents of samples/promo_01.json>, "trend_report": {"output": {"demand_multiplier_hint": {"low": 0.95, "high": 1.10}}}}
```

Chain by hand (good for debugging contract mismatches):
```
> Run trend-agent in evaluate mode for samples/promo_01.json, pass its output to promotion-simulator-agent,
  then basket-intelligence-agent, then roi-agent, then risk-critic-agent. Validate each hop against core/schemas.
```

Full review loop via the orchestrator sub-agent:
```
> Use promo-orchestrator to evaluate samples/promo_01.json following workflows/evaluate_promotion.yaml
```

Parallel build (uses the Workflow tool; ask Claude Code explicitly):
```
> Use a workflow to build in parallel: (1) data/generate.py with the planted patterns from ARCHITECTURE.md §13,
  (2) the retail_data MCP server, (3) Streamlit Insights page. Then review each against CLAUDE.md.
```

## C. Calculator CLIs (what the agents invoke via Bash)

```bash
python core/calc/lift.py --analogs '[{"lift_pct":22,"weight":1},{"lift_pct":35,"weight":0.6}]' --hint-low 0.95 --hint-high 1.10 --baseline-units 12400
python core/calc/basket.py --incremental 3800 --substitutes '[{"sku":"SKU-2201","switch_rate":0.25,"unit_margin_cents":95}]' --complements '[{"sku":"SKU-3310","attach_rate":0.08,"unit_margin_cents":70}]'
python core/calc/roi.py --baseline-units 12400 --lift-pct 31 --price-cents 599 --unit-cost-cents 380 --depth-pct 50 --funding-pct 20 --cannibalized-margin-cents 41800 --halo-margin-cents 22400
```

## D. Expected shape of the final bundle

```json
{ "promotion": {}, "trend": {}, "simulate": {}, "basket": {}, "roi": {},
  "critic": {"output": {"verdict": "revise"}},
  "recommend": {"output": {"recommended_id": "A1", "alternatives": [{"id": "A1", "evaluation": {}}]}} }
```
