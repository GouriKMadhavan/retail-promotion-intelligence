"""Shared helpers for the stdio MCP servers. Run from the repo root so `core` is importable."""
from __future__ import annotations
import json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.data_store import get_store  # noqa: E402


def dump(obj) -> str:
    return json.dumps(obj, default=str, ensure_ascii=False)
