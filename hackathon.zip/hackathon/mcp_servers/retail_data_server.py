"""retail_data MCP server (stdio). Read-only tools over core.data_store.DataStore. Tool names match the agents' `mcp__retail_data__*` allowlists."""
try:
    from mcp.server.mcpserver import MCPServer as FastMCP  # mcp 2.x
except ImportError:
    from mcp.server.fastmcp import FastMCP  # mcp 1.x
from _common import get_store, dump

mcp = FastMCP("retail_data")


@mcp.tool()
def lookup_products(text: str, limit: int = 3) -> str:
    """Resolve a SKU or messy product name to catalog candidates, best match first, with a score."""
    return dump(get_store().lookup_products(text, limit))


@mcp.tool()
def get_product_attributes(sku: str) -> str:
    """Catalog attributes for one SKU (name, category, brand, price_cents, unit_cost_cents...)."""
    return dump(get_store().get_product_attributes(sku))


@mcp.tool()
def get_seasonality(category: str, start: str, end: str) -> str:
    """Seasonal demand index for a category over a window (dates YYYY-MM-DD). 1.0 = average."""
    return dump(get_store().get_seasonality(category, start, end))


@mcp.tool()
def get_baseline_sales(sku: str, start: str, end: str, region: str = "NE") -> str:
    """Expected non-promoted units for a SKU over a window."""
    return dump(get_store().get_baseline_sales(sku, start, end, region))


@mcp.tool()
def find_comparable_promotions(category: str, limit: int = 12, completed_only: bool = True) -> str:
    """Past promotions in a category with their actual lift, depth, mechanic and stockout flag (candidate analogs)."""
    return dump(get_store().find_comparable_promotions(category, limit, completed_only))


@mcp.tool()
def get_price_elasticity(category: str) -> str:
    """Lift coefficient per unit of discount depth for a category."""
    return dump({"category": category, "lift_coefficient": get_store().get_price_elasticity(category)})


@mcp.tool()
def get_substitutes(sku: str) -> str:
    """SKUs shoppers switch to/from, with switch_rate."""
    return dump(get_store().get_substitutes(sku))


@mcp.tool()
def get_basket_affinity(sku: str) -> str:
    """Complement SKUs bought together, with affinity_lift and attach_rate."""
    return dump(get_store().get_basket_affinity(sku))


@mcp.tool()
def get_inventory(sku: str = "") -> str:
    """On-hand units, weeks of cover and stock age for one SKU, or all SKUs if sku is empty."""
    return dump(get_store().get_inventory(sku or None))


@mcp.tool()
def get_costs_and_margins(sku: str) -> str:
    """Price, unit cost and unit margin (cents) for a SKU."""
    return dump(get_store().get_costs_and_margins(sku))


if __name__ == "__main__":
    mcp.run()
