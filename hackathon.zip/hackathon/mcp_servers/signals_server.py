"""signals MCP server (stdio). Events, weather, trends via core.data_store (mock CSVs by default; live if RPIP live signals enabled)."""
try:
    from mcp.server.mcpserver import MCPServer as FastMCP  # mcp 2.x
except ImportError:
    from mcp.server.fastmcp import FastMCP  # mcp 1.x
from _common import get_store, dump

mcp = FastMCP("signals")


@mcp.tool()
def get_events(start: str, end: str, region: str = "NE") -> str:
    """Events/holidays overlapping the window (dates YYYY-MM-DD) in a region, with affected categories."""
    return dump(get_store().get_events(start, end, region))


@mcp.tool()
def get_weather_forecast(start: str, end: str, region: str = "NE") -> str:
    """Weather summary for the window: avg/min temperature, freezing days."""
    return dump(get_store().get_weather_forecast(start, end, region))


@mcp.tool()
def get_trends() -> str:
    """Category trend index and 30-day change."""
    return dump(get_store().get_trends())


if __name__ == "__main__":
    mcp.run()
