"""calc MCP server (stdio). Exposes the deterministic calculators in core/calc/*.py as tools, so agents never do arithmetic."""
try:
    from mcp.server.mcpserver import MCPServer as FastMCP  # mcp 2.x
except ImportError:
    from mcp.server.fastmcp import FastMCP  # mcp 1.x
from _common import dump
from core.calc.lift import forecast_lift
from core.calc.basket import basket_effect
from core.calc.roi import promo_roi

mcp = FastMCP("calc")


@mcp.tool()
def calc_lift(analogs: list[dict], baseline_units: float, hint_low: float = 1.0, hint_high: float = 1.0) -> str:
    """Lift forecast. analogs: [{lift_pct, weight}] chosen by you; hint_low/high: demand multipliers from the trend agent."""
    return dump(forecast_lift(analogs, hint_low, hint_high, baseline_units))


@mcp.tool()
def calc_basket(incremental_units: float, substitutes: list[dict], complements: list[dict], promoted_unit_margin_cents: float = 0) -> str:
    """Basket effect for ONE incremental-units value (call once each for low/expected/high).
    substitutes: [{sku, switch_rate, unit_margin_cents}]  complements: [{sku, attach_rate, unit_margin_cents}]"""
    return dump(basket_effect(incremental_units, substitutes, complements, promoted_unit_margin_cents))


@mcp.tool()
def calc_roi(baseline_units: float, lift_pct: float, price_cents: float, unit_cost_cents: float, depth_pct: float,
             funding_pct: float = 0, cannibalized_margin_cents: float = 0, halo_margin_cents: float = 0,
             baseline_redemption: float = 1.0) -> str:
    """ROI, net margin impact, wasted discount and break-even lift. Money in integer cents; percentages 0-100; redemption 0-1."""
    return dump(promo_roi(baseline_units, lift_pct, price_cents, unit_cost_cents, depth_pct, funding_pct,
                          cannibalized_margin_cents, halo_margin_cents, baseline_redemption))


if __name__ == "__main__":
    mcp.run()
