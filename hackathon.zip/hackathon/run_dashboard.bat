@echo off
REM Starts the dashboard: Claude Code agents for judgment steps, local code for the arithmetic steps.
cd /d "%~dp0"
set RPIP_BACKEND=local
set RPIP_BACKEND_TREND_AGENT=claude-code
set RPIP_BACKEND_RISK_CRITIC_AGENT=claude-code
set RPIP_BACKEND_RECOMMENDATION_AGENT=claude-code
.venv\Scripts\python.exe -m streamlit run app/Home.py --server.port 8501
